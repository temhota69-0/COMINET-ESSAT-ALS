import { CommandPermissionLevel, CustomCommandStatus, Player, system } from "@minecraft/server";
import { openXrayLogMainMenu } from "../systems/xrayLogMenu.js";

/**
 * /sg:xraylog (kısayolu: /sg:log)
 * permissionLevel: GameDirectors -> komut sadece sunucu operatörlerine (op) görünür,
 * normal oyuncular komutu yazamaz bile (tag kontrolüne gerek yok, motor engelliyor).
 * @param {import("@minecraft/server").CustomCommandRegistry} customCommandRegistry
 */
export default function xraylog(customCommandRegistry) {
    const handler = (origin) => {
        const player = origin.sourceEntity;
        if (!player || !(player instanceof Player)) {
            return { status: CustomCommandStatus.Failure, message: "Bu komut sadece oyuncular tarafından kullanılabilir." };
        }

        system.run(() => {
            if (player.isValid) openXrayLogMainMenu(player);
        });

        return { status: CustomCommandStatus.Success };
    };

    customCommandRegistry.registerCommand(
        {
            name: "sg:xraylog",
            description: "Xray log / oyuncu istatistik menüsünü aç. (sadece operatör)",
            permissionLevel: CommandPermissionLevel.GameDirectors,
            cheatsRequired: false,
        },
        handler
    );

    customCommandRegistry.registerCommand(
        {
            name: "sg:log",
            description: "Xray log menüsünü aç. (/sg:xraylog kısayolu)",
            permissionLevel: CommandPermissionLevel.GameDirectors,
            cheatsRequired: false,
        },
        handler
    );
}
