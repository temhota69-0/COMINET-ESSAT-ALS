import {
    CommandPermissionLevel,
    CustomCommandParamType,
    CustomCommandStatus,
    Player,
    system,
    world,
} from "@minecraft/server";

const NAME_PROPERTY = "sg:customName";
const MAX_NAME_LENGTH = 16;

/**
 * sg:name komutunu kaydeder.
 * Kullanım: /sg:name <istediğin ad>
 * Oyuncunun başındaki nametag'ini VE chat'te görünen adını değiştirir.
 * Boş ad girilirse (" " gibi sadece boşluk) özel ad kaldırılır, gerçek oyuncu adına döner.
 * @param {import("@minecraft/server").CustomCommandRegistry} customCommandRegistry
 */
export default function name(customCommandRegistry) {
    customCommandRegistry.registerCommand(
        {
            name: "sg:name",
            description: "Nametag ve chat adını değiştir. (Sadece operatör)",
            permissionLevel: CommandPermissionLevel.GameDirectors,
            cheatsRequired: false,
            mandatoryParameters: [{ name: "yeniAd", type: CustomCommandParamType.String }],
        },
        (origin, newName) => {
            const player = origin.sourceEntity;
            if (!player || !(player instanceof Player)) {
                return {
                    status: CustomCommandStatus.Failure,
                    message: "Bu komut sadece oyuncular tarafından kullanılabilir.",
                };
            }

            const trimmed = newName.trim();

            // Boş ad girildiyse özel adı kaldır, gerçek oyuncu adına dön
            if (trimmed.length === 0) {
                system.run(() => {
                    if (!player.isValid) return;
                    player.setDynamicProperty(NAME_PROPERTY, undefined);
                    player.nameTag = player.name;
                    player.sendMessage("§aÖzel adın kaldırıldı, gerçek adına döndün.");
                });
                return { status: CustomCommandStatus.Success };
            }

            if (trimmed.length > MAX_NAME_LENGTH) {
                return {
                    status: CustomCommandStatus.Failure,
                    message: `Ad en fazla ${MAX_NAME_LENGTH} karakter olabilir.`,
                };
            }

            system.run(() => {
                if (!player.isValid) return;
                // Dynamic property ile kaydediyoruz ki oyuncu çıkıp girince ad kalıcı olsun
                player.setDynamicProperty(NAME_PROPERTY, trimmed);
                player.nameTag = trimmed;
                player.sendMessage(`§aAdın "${trimmed}" olarak ayarlandı.`);
            });

            return { status: CustomCommandStatus.Success };
        }
    );
}

/**
 * Chat mesajlarını yakalayıp, gönderenin /sg:name ile ayarladığı özel adla gösterir.
 * Özel ad ayarlanmamışsa mesaj olduğu gibi (varsayılan davranış) geçer.
 */
export function initNameChat() {
    world.beforeEvents.chatSend.subscribe((event) => {
        const sender = event.sender;
        if (!sender) return;

        const customName = sender.getDynamicProperty(NAME_PROPERTY);
        if (typeof customName !== "string" || customName.length === 0) return;

        // Varsayılan chat mesajını iptal edip kendi formatımızla gönderiyoruz
        event.cancel = true;
        const message = event.message;

        system.run(() => {
            world.sendMessage(`<${customName}> ${message}`);
        });
    });
}

/**
 * Oyuncu oyuna girdiğinde, daha önce /sg:name ile kaydettiği özel adı varsa
 * nametag'ine tekrar uygular (dynamic property kalıcı olduğu için).
 */
export function initNameOnJoin() {
    world.afterEvents.playerSpawn.subscribe((event) => {
        if (!event.initialSpawn) return;
        const player = event.player;
        const customName = player.getDynamicProperty(NAME_PROPERTY);
        if (typeof customName === "string" && customName.length > 0) {
            system.run(() => {
                if (!player.isValid) return;
                player.nameTag = customName;
            });
        }
    });
}
