import { CommandPermissionLevel, CustomCommandStatus, Player, system } from "@minecraft/server";
import { ModalFormData } from "@minecraft/server-ui";
import { getHudSettings, setHudSettings } from "../data/hudSettingsData.js";

/**
 * HUD ayar panelini açar (Cps / Combo / Konum aç-kapa).
 * Not: Combo, cps ile aynı şekilde tamamen bu ayara bağlıdır (kapalıysa hiç
 * gösterilmez). Combat satırının ayarı yoktur; oyuncu combat'taysa her
 * zaman gösterilir.
 * @param {import("@minecraft/server").Player} player
 */
async function openSettingsMenu(player) {
    const current = getHudSettings(player);

    const form = new ModalFormData()
        .title("§l§bAYARLAR")
        .toggle("§bCps Göster", { defaultValue: current.cps })
        .toggle("§dCombo Göster", { defaultValue: current.combo })
        .toggle("§aKonum (Cord) Göster", { defaultValue: current.location })
        .toggle("§6Scoreboard Göster", { defaultValue: current.scoreboard });

    const response = await form.show(player);
    if (response.canceled || !response.formValues) return;

    const [cps, combo, location, scoreboard] = response.formValues;
    setHudSettings(player, { cps, combo, location, scoreboard });

    player.sendMessage(
        `§aHUD ayarların güncellendi: §bCps §7${cps ? "§aaçık" : "§ckapalı"}§7, §dCombo §7${
            combo ? "§aaçık" : "§ckapalı"
        }§7, §aKonum §7${location ? "§aaçık" : "§ckapalı"}§7, §6Scoreboard §7${
            scoreboard ? "§aaçık" : "§ckapalı"
        }`
    );
}

/**
 * sg:settings komutunu kaydeder.
 * Kullanım: /sg:settings
 * Action bar HUD'unda CPS / Combo / Konum bilgilerinin gösterilip
 * gösterilmeyeceğini ayarlayan modal formu açar.
 * @param {import("@minecraft/server").CustomCommandRegistry} customCommandRegistry
 */
export default function settings(customCommandRegistry) {
    customCommandRegistry.registerCommand(
        {
            name: "sg:settings",
            description: "AYARLAR",
            permissionLevel: CommandPermissionLevel.Any,
            cheatsRequired: false,
        },
        (origin) => {
            const player = origin.sourceEntity;
            if (!player || !(player instanceof Player)) {
                return {
                    status: CustomCommandStatus.Failure,
                    message: "Bu komut sadece oyuncular tarafından kullanılabilir.",
                };
            }

            system.run(() => {
                if (!player.isValid) return;
                openSettingsMenu(player).catch((err) => {
                    console.error(`[sg:settings] Menü açılırken hata: ${err}`);
                    try {
                        player.sendMessage(`§cAyarlar menüsü açılamadı: §7${err}`);
                    } catch (e) {}
                });
            });

            return { status: CustomCommandStatus.Success };
        }
    );
}
