import { CommandPermissionLevel, CustomCommandStatus, Player, system, world } from "@minecraft/server";
import { ActionFormData, ModalFormData } from "@minecraft/server-ui";
import { getKnownPlayerNames } from "../data/playerRegistry.js";
import { getAllHomeCounts, getPlayerHomesByName } from "../data/homesData.js";

function normalize(str) {
    return str
        .replace(/İ/g, "i")
        .replace(/I/g, "ı")
        .toLowerCase();
}

function homeButtonLabel(name, counts) {
    return `${name}\n§7Ev: §f${counts[name] ?? 0}`;
}

// ---------------------------------------------------------------------
// Ana menü
// ---------------------------------------------------------------------
function openHomeSeeMainMenu(admin) {
    const form = new ActionFormData()
        .title("§lHome Görüntüleyici")
        .body("§8Bir kategori seç:")
        .button("§aÇevrimiçi Oyuncular")
        .button("§8Çevrimdışı Oyuncular")
        .button("§eOyuncu Ara");

    form.show(admin).then((res) => {
        if (res.canceled || !admin.isValid) return;
        switch (res.selection) {
            case 0:
                openPlayerListMenu(admin, "online");
                break;
            case 1:
                openPlayerListMenu(admin, "offline");
                break;
            case 2:
                openSearchMenu(admin);
                break;
        }
    });
}

// ---------------------------------------------------------------------
// Çevrimiçi / Çevrimdışı oyuncu listesi (isim + ev sayısı)
// ---------------------------------------------------------------------
function openPlayerListMenu(admin, mode) {
    const onlineNames = new Set(world.getAllPlayers().map((p) => p.name));
    const known = getKnownPlayerNames();
    const counts = getAllHomeCounts();

    const names = (mode === "online" ? [...onlineNames] : known.filter((n) => !onlineNames.has(n))).sort((a, b) =>
        a.localeCompare(b)
    );

    const form = new ActionFormData()
        .title(mode === "online" ? "§lÇevrimiçi Oyuncular" : "§lÇevrimdışı Oyuncular")
        .body(names.length === 0 ? "§8Kayıtlı oyuncu yok." : "§8Evlerini görmek için bir oyuncu seç:");

    for (const name of names) form.button(homeButtonLabel(name, counts));
    form.button("§8<< Geri");

    form.show(admin).then((res) => {
        if (res.canceled || !admin.isValid) return;
        if (res.selection === names.length) {
            openHomeSeeMainMenu(admin);
            return;
        }
        openPlayerHomesMenu(admin, names[res.selection], () => openPlayerListMenu(admin, mode));
    });
}

// ---------------------------------------------------------------------
// Oyuncu arama
// ---------------------------------------------------------------------
function openSearchMenu(admin) {
    const form = new ModalFormData().title("§lOyuncu Ara").textField("İsim (parça yeter)", "örn: ömer");

    form.show(admin).then((res) => {
        if (res.canceled || !admin.isValid) return;
        const query = normalize((res.formValues?.[0] ?? "").trim());
        if (!query) {
            openHomeSeeMainMenu(admin);
            return;
        }

        const known = getKnownPlayerNames();
        const matches = known
            .map((name) => ({ name, idx: normalize(name).indexOf(query) }))
            .filter((e) => e.idx !== -1)
            .sort((a, b) => a.idx - b.idx || a.name.localeCompare(b.name))
            .slice(0, 25);

        openSearchResultsMenu(admin, query, matches.map((m) => m.name));
    });
}

function openSearchResultsMenu(admin, query, names) {
    const counts = getAllHomeCounts();

    const form = new ActionFormData()
        .title(`§lArama: "${query}"`)
        .body(names.length === 0 ? "§8Eşleşen oyuncu bulunamadı." : "§8Sonuçlar:");

    for (const name of names) form.button(homeButtonLabel(name, counts));
    form.button("§8<< Geri");

    form.show(admin).then((res) => {
        if (res.canceled || !admin.isValid) return;
        if (res.selection === names.length) {
            openHomeSeeMainMenu(admin);
            return;
        }
        openPlayerHomesMenu(admin, names[res.selection], () => openSearchMenu(admin));
    });
}

// ---------------------------------------------------------------------
// Seçilen oyuncunun evleri: seçilince ışınlanma
// ---------------------------------------------------------------------
function openPlayerHomesMenu(admin, targetName, onBack) {
    const homes = getPlayerHomesByName(targetName);
    const homeNames = Object.keys(homes);

    const form = new ActionFormData()
        .title(`§l${targetName} §r§8- Evleri`)
        .body(homeNames.length === 0 ? "§8Kayıtlı ev yok." : "§8Işınlanmak için bir ev seç:");

    for (const name of homeNames) {
        const h = homes[name];
        const dim = String(h.dimensionId ?? "").replace("minecraft:", "");
        form.button(`${name}\n§7(${Math.floor(h.x)}, ${Math.floor(h.y)}, ${Math.floor(h.z)}) §8${dim}`);
    }
    form.button("§8<< Geri");

    form.show(admin).then((res) => {
        if (res.canceled || !admin.isValid) return;
        if (res.selection === homeNames.length) {
            onBack();
            return;
        }

        const homeName = homeNames[res.selection];
        const homeData = homes[homeName];

        system.run(() => {
            try {
                const dimension = world.getDimension(homeData.dimensionId);
                admin.teleport({ x: homeData.x, y: homeData.y, z: homeData.z }, { dimension });
                admin.sendMessage(`§a"${targetName}" adlı oyuncunun "${homeName}" evine ışınlandın.`);
            } catch {
                admin.sendMessage("§cIşınlanma başarısız oldu.");
            }
        });
    });
}

/**
 * /sg:homesee komutunu kaydeder.
 * @param {import("@minecraft/server").CustomCommandRegistry} customCommandRegistry
 */
export default function homesee(customCommandRegistry) {
    customCommandRegistry.registerCommand(
        {
            name: "sg:homesee",
            description: "Oyuncuların evlerini görüntüle ve ışınlan. (sadece operatör)",
            permissionLevel: CommandPermissionLevel.GameDirectors,
            cheatsRequired: false,
        },
        (origin) => {
            const player = origin.sourceEntity;
            if (!player || !(player instanceof Player)) {
                return {
                    status: CustomCommandStatus.Failure,
                    message: "Bu komut sadece oyuncular tarafından kullanılabilir.",
                };
            }

            system.run(() => {
                if (player.isValid) openHomeSeeMainMenu(player);
            });

            return { status: CustomCommandStatus.Success };
        }
    );
}
