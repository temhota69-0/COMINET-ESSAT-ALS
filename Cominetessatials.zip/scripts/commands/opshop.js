import { CommandPermissionLevel, CustomCommandStatus, Player, system } from "@minecraft/server";
import { ActionFormData, ModalFormData, MessageFormData } from "@minecraft/server-ui";
import { ChestFormData } from "../extensions/forms.js";
import { getCategories, setStock, resetAllStock } from "../data/shopData.js";

/* ---------------------------------------------------------------------- */
/* Not: Kategori/eşya eklemek, silmek veya isim-fiyat değiştirmek için     */
/* artık scripts/data/shopConfig.js dosyasını düzenlemen yeterli.         */
/* Bu panel sadece ANLIK STOK yönetimi içindir (sınırlı stoklu eşyalar).  */
/* ---------------------------------------------------------------------- */

/* ---------------------------------------------------------------------- */
/* Stok Yönetimi (kategori -> eşya -> yeni stok)                          */
/* ---------------------------------------------------------------------- */

async function openCategoryStockMenu(player, categoryId) {
    const categories = getCategories();
    const category = categories.find((c) => c.id === categoryId);
    if (!category) return openAdminMenu(player);

    const form = new ChestFormData("large").title(`§l§6Stok - ${category.name}`);
    category.items.forEach((item, i) => {
        const lore =
            item.stock === -1
                ? ["§7Stok: §asınırsız", "§8(sınırsız eşyaların stoğu değiştirilemez)"]
                : [`§7Stok: §f${item.stock}`, "§e[Stok Ayarlamak İçin Tıkla]"];
        form.button(i, `§f${item.name}`, lore, item.icon || item.item);
    });
    form.button(49, "§6« Kategoriler", [], "minecraft:barrier");

    const response = await form.show(player);
    if (response.canceled || response.selection === undefined) return;
    if (response.selection === 49) return openCategoryListMenu(player);

    const item = category.items[response.selection];
    if (!item) return openCategoryStockMenu(player, categoryId);

    if (item.stock === -1) {
        player.sendMessage("§cBu eşyanın stoğu sınırsız, değiştirilemez.");
        return openCategoryStockMenu(player, categoryId);
    }

    const modal = new ModalFormData()
        .title(`Stok Ayarla - ${item.name}`)
        .textField("Yeni stok miktarı", String(item.stock), String(item.stock));
    const r = await modal.show(player);
    if (r.canceled) return openCategoryStockMenu(player, categoryId);

    const newStock = Number(r.formValues[0]);
    if (!Number.isFinite(newStock) || newStock < 0) {
        player.sendMessage("§cGeçersiz miktar. 0 veya üzeri bir sayı gir.");
        return openCategoryStockMenu(player, categoryId);
    }

    setStock(categoryId, response.selection, Math.floor(newStock));
    player.sendMessage(`§a"${item.name}" stoğu ${Math.floor(newStock)} olarak ayarlandı.`);
    return openCategoryStockMenu(player, categoryId);
}

async function openCategoryListMenu(player) {
    const categories = getCategories();
    if (categories.length === 0) {
        player.sendMessage("§cMağaza boş. scripts/data/shopConfig.js dosyasına kategori/eşya ekle.");
        return;
    }

    const form = new ChestFormData("large").title("§l§6Stok Yönetimi - Kategori Seç");
    categories.forEach((c, i) => {
        form.button(i, `§f${c.name}`, [`§7${c.items.length} eşya`], c.icon || "minecraft:emerald");
    });

    const response = await form.show(player);
    if (response.canceled || response.selection === undefined) return;

    const category = categories[response.selection];
    if (category) return openCategoryStockMenu(player, category.id);
}

/* ---------------------------------------------------------------------- */
/* Tüm Stokları Sıfırla                                                   */
/* ---------------------------------------------------------------------- */

async function flowResetAllStock(player) {
    const confirm = new MessageFormData()
        .title("Emin misin?")
        .body("Tüm sınırlı stoklu eşyalar shopConfig.js dosyasındaki başlangıç değerlerine sıfırlanacak.")
        .button1("§aEvet, sıfırla")
        .button2("§7Vazgeç");

    const r = await confirm.show(player);
    if (r.canceled || r.selection !== 0) return;

    resetAllStock();
    player.sendMessage("§aTüm stoklar başlangıç değerlerine sıfırlandı.");
}

/* ---------------------------------------------------------------------- */
/* Mağazayı Görüntüle (salt okunur metin listesi)                        */
/* ---------------------------------------------------------------------- */

async function flowViewCatalog(player) {
    const categories = getCategories();
    if (categories.length === 0) {
        player.sendMessage("§cMağaza boş.");
        return;
    }

    const lines = [];
    for (const category of categories) {
        lines.push(`§l§2${category.name}§r §7(${category.id})`);
        if (category.items.length === 0) {
            lines.push("  §8- eşya yok -");
            continue;
        }
        for (const item of category.items) {
            const stockText = item.stock === -1 ? "sınırsız" : String(item.stock);
            lines.push(`  §f${item.name} §7(${item.item}) §e${item.price} Para §8- stok: ${stockText}`);
        }
    }
    lines.push("", "§8Kategori/eşya eklemek, silmek veya düzenlemek için scripts/data/shopConfig.js dosyasını değiştir.");

    const form = new ActionFormData().title("Mağaza Kataloğu").body(lines.join("\n")).button("Kapat");
    await form.show(player);
}

/* ---------------------------------------------------------------------- */
/* Ana menü                                                                */
/* ---------------------------------------------------------------------- */

async function openAdminMenu(player) {
    const form = new ActionFormData()
        .title("§l§6Mağaza Yönetimi")
        .body(
            "§7Kategori/eşya eklemek, silmek veya isim-fiyat değiştirmek için\n§7scripts/data/shopConfig.js dosyasını düzenle.\n\nBu menüden sadece stokları yönetebilirsin:"
        )
        .button("Stokları Yönet")
        .button("Tüm Stokları Sıfırla")
        .button("Kataloğu Görüntüle");

    const response = await form.show(player);
    if (response.canceled || response.selection === undefined) return;

    switch (response.selection) {
        case 0:
            await openCategoryListMenu(player);
            break;
        case 1:
            await flowResetAllStock(player);
            break;
        case 2:
            await flowViewCatalog(player);
            break;
    }
}

/**
 * sg:opshop komutunu kaydeder (sadece operatörler).
 * @param {import("@minecraft/server").CustomCommandRegistry} customCommandRegistry
 */
export default function opshop(customCommandRegistry) {
    customCommandRegistry.registerCommand(
        {
            name: "sg:opshop",
            description: "Mağaza stok yönetim panelini aç. (sadece operatör)",
            permissionLevel: CommandPermissionLevel.GameDirectors,
            cheatsRequired: false,
        },
        (origin) => {
            const player = origin.sourceEntity;
            if (!player || !(player instanceof Player)) {
                return { status: CustomCommandStatus.Failure, message: "Bu komut sadece oyuncular tarafından kullanılabilir." };
            }
            system.run(() => openAdminMenu(player));
            return { status: CustomCommandStatus.Success };
        }
    );
}

/**
 * /scriptevent sg:menu opshop ile de aynı panelin açılabilmesini sağlar.
 * main.js içinde bir kere çağrılmalı.
 */
export function initOpshopMenuEvent() {
    system.afterEvents.scriptEventReceive.subscribe((event) => {
        if (event.id !== "sg:menu") return;
        if (event.message.trim().toLowerCase() !== "opshop") return;

        const player = event.sourceEntity;
        if (!player || !(player instanceof Player)) return;
        if (!player.isOp()) {
            player.sendMessage("§cBu menüyü açmak için operatör olmalısın.");
            return;
        }

        system.run(() => openAdminMenu(player));
    });
}
