import {
    CommandPermissionLevel,
    CustomCommandStatus,
    Player,
    system,
    world,
} from "@minecraft/server";
import { startStillnessCountdown } from "./util/teleportCountdown.js";

const RTP_COUNTDOWN_SECONDS = 5;
const COOLDOWN_SECONDS = 10;
const RESISTANCE_SECONDS = 15;

const RTP_RADIUS = {
    "minecraft:overworld": 10000,
    "minecraft:nether": 3000,
};

const lastRtpTick = new Map();

world.afterEvents.entityHurt.subscribe((event) => {
    const { hurtEntity, damageSource } = event;
    if (!(hurtEntity instanceof Player)) return;
    if (!(damageSource.damagingEntity instanceof Player)) return;

    const resistance = hurtEntity.getEffect("resistance");
    if (resistance) {
        hurtEntity.removeEffect("resistance");
    }
});

export default function rtp(customCommandRegistry) {
    customCommandRegistry.registerCommand(
        {
            name: "sg:rtp",
            description: "Bulunduğun boyutta rastgele bir konuma ışınlan.",
            permissionLevel: CommandPermissionLevel.Any,
            cheatsRequired: false,
        },
        (origin) => {
            const player = origin.sourceEntity;
            if (!player || !(player instanceof Player)) {
                return {
                    status: CustomCommandStatus.Failure,
                    message: "Bu komut sadece oyuncular tarafından kullanılabilir.",
                };
            }

            const dimensionId = player.dimension.id;
            const radius = RTP_RADIUS[dimensionId];
            if (!radius) {
                return {
                    status: CustomCommandStatus.Failure,
                    message: "Bu boyutta rtp kullanılamaz.",
                };
            }

            const lastTick = lastRtpTick.get(player.id);
            if (lastTick !== undefined) {
                const ticksSince = system.currentTick - lastTick;
                const cooldownTicks = COOLDOWN_SECONDS * 20;
                if (ticksSince < cooldownTicks) {
                    const secondsLeft = Math.ceil((cooldownTicks - ticksSince) / 20);
                    return {
                        status: CustomCommandStatus.Failure,
                        message: `Tekrar ışınlanmak için ${secondsLeft} saniye beklemelisin.`,
                    };
                }
            }

            startStillnessCountdown(
                player,
                RTP_COUNTDOWN_SECONDS,
                (secondsLeft) => `§eRastgele ışınlanıyorsun... §a${secondsLeft}s`,
                () => {
                    const dimension = player.dimension;
                    const x = (Math.random() * 2 - 1) * radius;
                    const z = (Math.random() * 2 - 1) * radius;
                    const topBlock = dimension.getTopmostBlock({ x: Math.floor(x), z: Math.floor(z) });

                    const location = {
                        x: topBlock.x + 0.5,
                        y: topBlock.y + 1,
                        z: topBlock.z + 0.5,
                    };

                    player.teleport(location, { dimension });
                    lastRtpTick.set(player.id, system.currentTick);

                    player.addEffect("resistance", RESISTANCE_SECONDS * 20, {
                        amplifier: 255,
                        showParticles: false,
                    });

                    player.sendMessage(
                        `§aRastgele bir konuma ışınlandın. §7(${Math.floor(location.x)}, ${Math.floor(location.y)}, ${Math.floor(location.z)})`
                    );
                },
                () => {
                    if (player.isValid) {
                        player.sendMessage("§cHareket ettiğin için ışınlanma iptal edildi.");
                    }
                }
            );

            return { status: CustomCommandStatus.Success };
        }
    );
}