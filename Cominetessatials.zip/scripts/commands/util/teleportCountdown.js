import { system } from "@minecraft/server";

const MOVE_TOLERANCE = 0.5;

/**
 * Bir oyuncuyu belirli bir süre hareketsiz tutup, kalan süreyi action bar'da gösterir.
 * Süre dolunca onComplete, hareket edilince (veya boyut değişirse) onCancel çağrılır.
 *
 * @param {import("@minecraft/server").Player} player - hareketsiz kalması gereken oyuncu
 * @param {number} seconds - bekleme süresi (saniye)
 * @param {(secondsLeft: number) => string} actionBarText - her tick action bar metnini üreten fonksiyon
 * @param {() => void} onComplete - süre dolunca çağrılır
 * @param {() => void} onCancel - hareket/iptal olunca çağrılır
 * @returns {() => void} dışarıdan da iptal edebilmek için durdurma fonksiyonu
 */
export function startStillnessCountdown(player, seconds, actionBarText, onComplete, onCancel) {
    const totalTicks = seconds * 20;
    let ticksElapsed = 0;
    const startLocation = { ...player.location };
    const startDimensionId = player.dimension.id;
    let intervalId;

    const stop = () => system.clearRun(intervalId);

    intervalId = system.runInterval(() => {
        if (!player.isValid) {
            stop();
            return;
        }

        if (player.dimension.id !== startDimensionId) {
            stop();
            onCancel();
            return;
        }

        const loc = player.location;
        const dx = Math.abs(loc.x - startLocation.x);
        const dy = Math.abs(loc.y - startLocation.y);
        const dz = Math.abs(loc.z - startLocation.z);

        if (dx > MOVE_TOLERANCE || dy > MOVE_TOLERANCE || dz > MOVE_TOLERANCE) {
            stop();
            onCancel();
            return;
        }

        ticksElapsed += 1;
        const ticksLeft = totalTicks - ticksElapsed;
        const secondsLeft = Math.ceil(ticksLeft / 20);

        player.onScreenDisplay.setActionBar(actionBarText(secondsLeft));

        if (ticksElapsed >= totalTicks) {
            stop();
            onComplete();
        }
    }, 1);

    return stop;
}
