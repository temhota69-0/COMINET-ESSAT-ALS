import {
    CommandPermissionLevel,
    CustomCommandStatus,
    Player,
    system,
    world,
} from "@minecraft/server";
import { startStillnessCountdown } from "./util/teleportCountdown.js";

const SPAWN_COUNTDOWN_SECONDS = 5;
const SPAWN_LOCATION = { x: 0.5, y: 205, z: 0.5 };
const SPAWN_DIMENSION_ID = "minecraft:overworld";

/**
 * sg:spawn komutunu kaydeder.
 * Kullanım: /sg:spawn
 * Oyuncuyu sabit spawn konumuna ışınlar (0.5, 205, 0.5).
 * @param {import("@minecraft/server").CustomCommandRegistry} customCommandRegistry
 */
export default function spawn(customCommandRegistry) {
    customCommandRegistry.registerCommand(
        {
            name: "sg:spawn",
            description: "Spawn noktasına ışınlan.",
            permissionLevel: CommandPermissionLevel.Any,
            cheatsRequired: false,
        },
        (origin) => {
            const player = origin.sourceEntity;
            if (!player || !(player instanceof Player)) {
                return {
                    status: CustomCommandStatus.Failure,
                    message: "Bu komut sadece oyuncular tarafından kullanılabilir.",
                };
            }

            player.sendMessage(`§eIşınlanmak için ${SPAWN_COUNTDOWN_SECONDS} saniye hareketsiz dur.`);

            startStillnessCountdown(
                player,
                SPAWN_COUNTDOWN_SECONDS,
                (secondsLeft) => `§eSpawn'a ışınlanıyorsun... §a${secondsLeft}s`,
                () => {
                    // onComplete
                    const dimension = world.getDimension(SPAWN_DIMENSION_ID);
                    player.teleport(SPAWN_LOCATION, { dimension });
                    player.sendMessage("§aSpawn'a ışınlandın.");
                },
                () => {
                    // onCancel
                    if (player.isValid) {
                        player.sendMessage("§cHareket ettiğin için ışınlanma iptal edildi.");
                    }
                }
            );

            return { status: CustomCommandStatus.Success };
        }
    );
}
