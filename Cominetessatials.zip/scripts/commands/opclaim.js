import {
    CommandPermissionLevel,
    CustomCommandStatus,
    Player,
    system,
    world,
} from "@minecraft/server";
import { ActionFormData, ModalFormData, MessageFormData } from "@minecraft/server-ui";

const CLAIMS_PROPERTY_KEY = "sg:claims";
const ADMIN_BYPASS_TAG = "admin";

const MAX_BOX_SIZE = 200;
const MAX_SPHERE_RADIUS = 100;

const PROTECTED_INTERACT_KEYWORDS = [
    "door",
    "trap",
    "sign",
    "shelf",
    "barrel",
    "shulker_box",
    "furnace",
    "smoker",
    "lectern",
    "lever",
    "repeater",
    "comparator",
    "cauldron",
    "composter",
    "hopper",
    "dispenser",
    "dropper",
    "anvil",
    "grindstone",
    "loom",
    "cartography_table",
    "stonecutter",
    "smithing_table",
    "brewing_stand",
    "beacon",
    "enchanting_table",
    "jukebox",
    "note_block",
    "bed",
    "campfire",
    "bell",
    "daylight_detector",
    "crafting_table",
    "fence_gate",
    "command_block",
    "structure_block",
    "lodestone",
    "respawn_anchor",
    "cake",
    "flower_pot",
    "item_frame",
    "armor_stand",
];

/** @type {any[]} */
let claimsCache = [];

function loadClaims() {
    const raw = world.getDynamicProperty(CLAIMS_PROPERTY_KEY);
    if (typeof raw !== "string") {
        claimsCache = [];
        return;
    }
    try {
        const parsed = JSON.parse(raw);
        claimsCache = Array.isArray(parsed) ? parsed : [];
    } catch {
        claimsCache = [];
    }
}

function saveClaims() {
    world.setDynamicProperty(CLAIMS_PROPERTY_KEY, JSON.stringify(claimsCache));
}

function addClaim(claim) {
    claimsCache.push(claim);
    saveClaims();
}

function removeClaim(id) {
    claimsCache = claimsCache.filter((c) => c.id !== id);
    saveClaims();
}

function generateClaimId() {
    return `${Date.now()}-${Math.floor(Math.random() * 100000)}`;
}

/**
 * @param {any} claim
 * @param {string} dimensionId
 * @param {number} x
 * @param {number} y
 * @param {number} z
 */
function isPointInClaim(claim, dimensionId, x, y, z) {
    if (claim.dimensionId !== dimensionId) return false;

    if (claim.type === "box") {
        const { min, max } = claim;
        return x >= min.x && x <= max.x && y >= min.y && y <= max.y && z >= min.z && z <= max.z;
    }

    if (claim.type === "sphere") {
        const { center, r } = claim;
        const dx = x + 0.5 - center.x;
        const dy = y + 0.5 - center.y;
        const dz = z + 0.5 - center.z;
        return dx * dx + dy * dy + dz * dz <= r * r;
    }

    return false;
}

function findClaimAt(dimensionId, x, y, z) {
    for (const claim of claimsCache) {
        if (isPointInClaim(claim, dimensionId, x, y, z)) return claim;
    }
    return undefined;
}

function hasBypassTag(player) {
    if (!player) return false;
    try {
        return player.hasTag(ADMIN_BYPASS_TAG);
    } catch {
        return false;
    }
}

function isProtectedInteractBlock(typeId) {
    const id = typeId.replace("minecraft:", "");
    for (const keyword of PROTECTED_INTERACT_KEYWORDS) {
        if (id.includes(keyword)) return true;
    }
    return false;
}

const pendingInteractRestore = new Map();

function makeRestoreKey(dimensionId, x, y, z) {
    return `${dimensionId}|${x}|${y}|${z}`;
}

export function initClaimProtection() {
    system.run(() => loadClaims());

    // Blok kırma engeli
    world.beforeEvents?.playerBreakBlock?.subscribe((event) => {
        const { block, player } = event;
        if (hasBypassTag(player)) return;
        if (!findClaimAt(block.dimension.id, block.x, block.y, block.z)) return;

        event.cancel = true;

        system.run(() => {
            try {
                player.sendMessage("§cBurası korumalı bir alan (Op Claim), blok kıramazsın.");
            } catch {}
        });
    });

    // Blok koyma engeli
    world.beforeEvents?.playerPlaceBlock?.subscribe((event) => {
        const { block, player } = event;
        if (hasBypassTag(player)) return;
        if (!findClaimAt(block.dimension.id, block.x, block.y, block.z)) return;

        event.cancel = true;

        system.run(() => {
            try {
                player.sendMessage("§cBurası korumalı bir alan (Op Claim), blok koyamazsın.");
            } catch {}
        });
    });

    // Etkileşim Kaydı (Before interact desteği olan sürümlerde durum kaydı tutar)
    if (world.beforeEvents?.playerInteractWithBlock) {
        world.beforeEvents.playerInteractWithBlock.subscribe((event) => {
            const { block, player } = event;
            if (hasBypassTag(player)) return;
            if (!isProtectedInteractBlock(block.typeId)) return;
            if (!findClaimAt(block.dimension.id, block.x, block.y, block.z)) return;

            event.cancel = true;
            const key = makeRestoreKey(block.dimension.id, block.x, block.y, block.z);
            pendingInteractRestore.set(key, block.permutation);
        });
    }

    // Etkileşimi Anında İptal Etme & Eski Hali Geri Yükleme (After interact)
    world.afterEvents?.playerInteractWithBlock?.subscribe((event) => {
        const { block, player } = event;
        if (hasBypassTag(player)) return;
        if (!isProtectedInteractBlock(block.typeId)) return;
        if (!findClaimAt(block.dimension.id, block.x, block.y, block.z)) return;

        const key = makeRestoreKey(block.dimension.id, block.x, block.y, block.z);
        const originalPermutation = pendingInteractRestore.get(key);

        system.run(() => {
            try {
                const currentBlock = block.dimension.getBlock({ x: block.x, y: block.y, z: block.z });
                if (currentBlock && originalPermutation) {
                    currentBlock.setPermutation(originalPermutation);
                }
            } catch {}
            try {
                player.sendMessage("§cBurası korumalı bir alan (Op Claim), bu bloğa dokunamazsın.");
            } catch {}
            pendingInteractRestore.delete(key);
        });
    });

    // Yedek Koruma: Blok kırma geri alma
    world.afterEvents?.playerBreakBlock?.subscribe((event) => {
        const { block, player, brokenBlockPermutation } = event;
        if (hasBypassTag(player)) return;
        if (!findClaimAt(block.dimension.id, block.x, block.y, block.z)) return;

        try {
            block.setPermutation(brokenBlockPermutation);
        } catch {}
    });

    // Yedek Koruma: Blok koyma geri alma
    world.afterEvents?.playerPlaceBlock?.subscribe((event) => {
        const { block, player } = event;
        if (hasBypassTag(player)) return;
        if (!findClaimAt(block.dimension.id, block.x, block.y, block.z)) return;

        try {
            block.setType("minecraft:air");
        } catch {}
    });

    // Patlama Engeli
    if (world.beforeEvents?.explosion) {
        world.beforeEvents.explosion.subscribe((event) => {
            if (claimsCache.length === 0) return;
            const dimensionId = event.dimension.id;
            const impacted = event.getImpactedBlocks ? event.getImpactedBlocks() : [];
            
            if (impacted.length > 0) {
                const filtered = impacted.filter((b) => !findClaimAt(dimensionId, b.x, b.y, b.z));
                if (filtered.length !== impacted.length && event.setImpactedBlocks) {
                    event.setImpactedBlocks(filtered);
                }
            }
        });
    }
}

function formatClaimLabel(claim) {
    const dim = claim.dimensionId.replace("minecraft:", "");
    if (claim.type === "box") {
        const { min, max } = claim;
        return (
            `§l§9Kutu§r  §7(${dim})\n` +
            `(${min.x}, ${min.y}, ${min.z}) -> (${max.x}, ${max.y}, ${max.z})\n` +
            `§8Oluşturan: ${claim.createdBy}`
        );
    }
    const { center, r } = claim;
    return (
        `§l§bKüre§r  §7(${dim})\n` +
        `Merkez: (${Math.floor(center.x)}, ${Math.floor(center.y)}, ${Math.floor(center.z)})  r=${r}\n` +
        `§8Oluşturan: ${claim.createdBy}`
    );
}

async function flowCreateBox(player) {
    const loc = player.location;
    const base = { x: Math.floor(loc.x), y: Math.floor(loc.y), z: Math.floor(loc.z) };

    const modal = new ModalFormData()
        .title("Dikdörtgen Prizma Alan")
        .textField(`Konumun baz alınıyor: (${base.x}, ${base.y}, ${base.z})\n\ndx (X yönü uzunluk)`, "5", {
            defaultValue: "5",
        })
        .textField("dy (Y yönü uzunluk)", "5", { defaultValue: "5" })
        .textField("dz (Z yönü uzunluk)", "5", { defaultValue: "5" });

    const response = await modal.show(player);
    if (response.canceled) return;

    const [dxRaw, dyRaw, dzRaw] = response.formValues;
    const dx = parseInt(String(dxRaw), 10);
    const dy = parseInt(String(dyRaw), 10);
    const dz = parseInt(String(dzRaw), 10);

    if (![dx, dy, dz].every((n) => Number.isFinite(n)) || dx === 0 || dy === 0 || dz === 0) {
        player.sendMessage("§cGeçersiz değer girdin. dx, dy, dz sıfırdan farklı bir sayı olmalı.");
        return;
    }
    if (Math.abs(dx) > MAX_BOX_SIZE || Math.abs(dy) > MAX_BOX_SIZE || Math.abs(dz) > MAX_BOX_SIZE) {
        player.sendMessage(`§cBir eksende en fazla ${MAX_BOX_SIZE} blok kullanabilirsin.`);
        return;
    }

    const corner2 = { x: base.x + dx, y: base.y + dy, z: base.z + dz };
    const min = {
        x: Math.min(base.x, corner2.x),
        y: Math.min(base.y, corner2.y),
        z: Math.min(base.z, corner2.z),
    };
    const max = {
        x: Math.max(base.x, corner2.x),
        y: Math.max(base.y, corner2.y),
        z: Math.max(base.z, corner2.z),
    };

    const claim = {
        id: generateClaimId(),
        type: "box",
        dimensionId: player.dimension.id,
        min,
        max,
        createdBy: player.name,
        createdAt: Date.now(),
    };

    addClaim(claim);
    player.sendMessage(
        `§aKutu alan oluşturuldu: (${min.x}, ${min.y}, ${min.z}) -> (${max.x}, ${max.y}, ${max.z})`
    );
}

async function flowCreateSphere(player) {
    const loc = player.location;
    const center = { x: Math.floor(loc.x) + 0.5, y: Math.floor(loc.y) + 0.5, z: Math.floor(loc.z) + 0.5 };

    const modal = new ModalFormData()
        .title("Küre Alan")
        .textField(
            `Merkez konumun baz alınıyor: (${Math.floor(center.x)}, ${Math.floor(center.y)}, ${Math.floor(center.z)})\n\nr (yarıçap)`,
            "5",
            { defaultValue: "5" }
        );

    const response = await modal.show(player);
    if (response.canceled) return;

    const [rRaw] = response.formValues;
    const r = parseFloat(String(rRaw));

    if (!Number.isFinite(r) || r <= 0) {
        player.sendMessage("§cGeçersiz değer girdin. r sıfırdan büyük bir sayı olmalı.");
        return;
    }
    if (r > MAX_SPHERE_RADIUS) {
        player.sendMessage(`§cYarıçap en fazla ${MAX_SPHERE_RADIUS} olabilir.`);
        return;
    }

    const claim = {
        id: generateClaimId(),
        type: "sphere",
        dimensionId: player.dimension.id,
        center,
        r,
        createdBy: player.name,
        createdAt: Date.now(),
    };

    addClaim(claim);
    player.sendMessage(
        `§aKüre alan oluşturuldu: Merkez (${Math.floor(center.x)}, ${Math.floor(center.y)}, ${Math.floor(center.z)}), r=${r}`
    );
}

async function flowDeleteClaim(player) {
    if (claimsCache.length === 0) {
        player.sendMessage("§cSilinecek herhangi bir alan yok.");
        return;
    }

    const list = new ActionFormData().title("Alan Sil").body("Silmek istediğin alanı seç:");
    for (const claim of claimsCache) list.button(formatClaimLabel(claim));

    const listResponse = await list.show(player);
    if (listResponse.canceled || listResponse.selection === undefined) return;

    const claim = claimsCache[listResponse.selection];

    const confirm = new MessageFormData()
        .title("Emin misin?")
        .body(`Bu alan kalıcı olarak silinecek:\n\n${formatClaimLabel(claim)}`)
        .button1("Evet, sil")
        .button2("Vazgeç");

    const confirmResponse = await confirm.show(player);
    if (confirmResponse.canceled || confirmResponse.selection !== 0) return;

    removeClaim(claim.id);
    player.sendMessage("§aAlan silindi.");
}

async function openMainMenu(player) {
    const form = new ActionFormData()
        .title("Op Claim Paneli")
        .body(`Kayıtlı alan sayısı: ${claimsCache.length}\n\nBir işlem seç:`)
        .button("§l§9Dikdörtgen Prizma Alan Oluştur")
        .button("§l§bKüre Alan Oluştur")
        .button("§l§cAlan Sil");

    const response = await form.show(player);
    if (response.canceled || response.selection === undefined) return;

    switch (response.selection) {
        case 0:
            await flowCreateBox(player);
            break;
        case 1:
            await flowCreateSphere(player);
            break;
        case 2:
            await flowDeleteClaim(player);
            break;
    }
}

/**
 * @param {import("@minecraft/server").CustomCommandRegistry} customCommandRegistry
 */
export default function opclaim(customCommandRegistry) {
    customCommandRegistry.registerCommand(
        {
            name: "sg:opclaim",
            description: "Koruma alanı oluştur / sil (kutu veya küre).",
            permissionLevel: CommandPermissionLevel.GameDirectors,
            cheatsRequired: false,
        },
        (origin) => {
            const player = origin.sourceEntity;
            if (!player || !(player instanceof Player)) {
                return {
                    status: CustomCommandStatus.Failure,
                    message: "Bu komut sadece oyuncular tarafından kullanılabilir.",
                };
            }

            system.run(() => openMainMenu(player));
            return { status: CustomCommandStatus.Success };
        }
    );
}
