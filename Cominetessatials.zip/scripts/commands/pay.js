import {
    CommandPermissionLevel,
    CustomCommandParamType,
    CustomCommandStatus,
    Player,
    system,
    world,
} from "@minecraft/server";

const SCOREBOARD_NAME = "Para";

/**
 * essentials:pay komutunu kaydeder.
 * Kullanım: /essentials:pay <oyuncu adı> <miktar>
 * Selector (@a, @p vb.) kabul edilmez, tpa.js ile aynı kural.
 * @param {import("@minecraft/server").CustomCommandRegistry} customCommandRegistry
 */
export default function pay(customCommandRegistry) {
    customCommandRegistry.registerCommand(
        {
            name: "sg:pay",
            description: "Başka bir oyuncuya para gönder.",
            permissionLevel: CommandPermissionLevel.Any,
            cheatsRequired: false,
            mandatoryParameters: [
                { name: "target", type: CustomCommandParamType.String },
                { name: "miktar", type: CustomCommandParamType.Integer },
            ],
        },
        (origin, targetName, amount) => {
            const sender = origin.sourceEntity;
            if (!sender || !(sender instanceof Player)) {
                return {
                    status: CustomCommandStatus.Failure,
                    message: "Bu komut sadece oyuncular tarafından kullanılabilir.",
                };
            }

            // @a, @p, @s, @e gibi selector'ları reddet - sadece düz isim kabul edilir
            if (targetName.startsWith("@")) {
                return {
                    status: CustomCommandStatus.Failure,
                    message: "Hedef seçici (@a, @p vb.) kullanılamaz, oyuncunun adını yaz.",
                };
            }

            if (!Number.isFinite(amount) || amount <= 0) {
                return { status: CustomCommandStatus.Failure, message: "Miktar 0'dan büyük bir sayı olmalı." };
            }

            const target = world.getAllPlayers().find((p) => p.name === targetName);
            if (!target) {
                return { status: CustomCommandStatus.Failure, message: `"${targetName}" adlı oyuncu bulunamadı.` };
            }

            if (target.id === sender.id) {
                return { status: CustomCommandStatus.Failure, message: "Kendine para gönderemezsin." };
            }

            const objective = world.scoreboard.getObjective(SCOREBOARD_NAME);
            if (!objective) {
                return {
                    status: CustomCommandStatus.Failure,
                    message: `"${SCOREBOARD_NAME}" adlı scoreboard bulunamadı. Önce oluştur: /scoreboard objectives add ${SCOREBOARD_NAME} dummy`,
                };
            }

            const senderScore = objective.getScore(sender) ?? 0;
            if (senderScore < amount) {
                return { status: CustomCommandStatus.Failure, message: "Yeterli paran yok." };
            }

            const targetScore = objective.getScore(target) ?? 0;

            system.run(() => {
                objective.setScore(sender, senderScore - amount);
                objective.setScore(target, targetScore + amount);
                sender.sendMessage(`§a${target.name} adlı oyuncuya ${amount} Para gönderdin.`);
                target.sendMessage(`§a${sender.name} sana ${amount} Para gönderdi.`);
            });

            return { status: CustomCommandStatus.Success };
        }
    );
}
