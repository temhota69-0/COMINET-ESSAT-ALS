import {
    CommandPermissionLevel,
    CustomCommandParamType,
    CustomCommandStatus,
    Player,
    system,
    world,
} from "@minecraft/server";
import { startStillnessCountdown } from "./util/teleportCountdown.js";

// target oyuncunun id'sine göre bekleyen istek: { requesterId, requesterName, timeoutId }
const pendingRequests = new Map();

// /sg:tpauto ile otomatik kabulü açan oyuncuların id'lerini tutar
const autoAcceptPlayers = new Set();

const REQUEST_TIMEOUT_SECONDS = 60;
const TPA_COUNTDOWN_SECONDS = 5;

/**
 * Kabul edilen isteklerde, ışınlanacak oyuncu (requester) 3 saniye hareketsiz
 * kalırsa hedefe (target) ışınlanır. Kalan süre requester'ın action bar'ında
 * görünür. Hareket ederse iptal olur ve target'a "{ad} isteğinizi reddetti" gider.
 */
function startTeleportCountdown(requester, target) {
    startStillnessCountdown(
        requester,
        TPA_COUNTDOWN_SECONDS,
        (secondsLeft) => `§e${target.name} yanına ışınlanıyorsun... §a${secondsLeft}s`,
        () => {
            // onComplete
            if (!target.isValid) {
                requester.sendMessage("§cHedef oyuncu artık sunucuda değil.");
                return;
            }
            requester.teleport(target.location, { dimension: target.dimension });
            requester.sendMessage(`§a${target.name} adlı oyuncunun yanına ışınlandın.`);
            target.sendMessage(`§a${requester.name} yanına ışınlandı.`);
        },
        () => {
            // onCancel
            if (requester.isValid) {
                requester.sendMessage("§cHareket ettiğin için ışınlanma iptal edildi.");
            }
            if (target.isValid) {
                target.sendMessage(`§c${requester.name} isteğinizi reddetti.`);
            }
        }
    );
}

/**
 * essentials:tpa / essentials:tpaccept / essentials:tpdeny komutlarını kaydeder.
 * main.js içinden system.beforeEvents.startup.subscribe altında çağrılmalı.
 * @param {import("@minecraft/server").CustomCommandRegistry} customCommandRegistry
 */
export default function tpa(customCommandRegistry) {
    // Oyuncu ayrılınca tpauto verisini temizle
    world.afterEvents.playerLeave.subscribe((event) => {
        autoAcceptPlayers.delete(event.playerId);
    });

    // /essentials:tpa <target>
    customCommandRegistry.registerCommand(
        {
            name: "sg:tpa",
            description: "Bir oyuncuya teleport isteği gönder.",
            permissionLevel: CommandPermissionLevel.Any,
            cheatsRequired: false,
            mandatoryParameters: [
                { name: "target", type: CustomCommandParamType.String },
            ],
        },
        (origin, targetName) => {
            const requester = origin.sourceEntity;
            if (!requester || !(requester instanceof Player)) {
                return {
                    status: CustomCommandStatus.Failure,
                    message: "Bu komut sadece oyuncular tarafından kullanılabilir.",
                };
            }

            // @a, @p, @s, @e gibi selector'ları reddet - sadece düz isim kabul edilir
            if (targetName.startsWith("@")) {
                return {
                    status: CustomCommandStatus.Failure,
                    message: "Hedef seçici (@a, @p vb.) kullanılamaz, oyuncunun adını yaz.",
                };
            }

            const target = world.getAllPlayers().find((p) => p.name === targetName);
            if (!target) {
                return { status: CustomCommandStatus.Failure, message: `"${targetName}" adlı oyuncu bulunamadı.` };
            }

            if (target.id === requester.id) {
                return { status: CustomCommandStatus.Failure, message: "Kendine istek gönderemezsin." };
            }

            // Hedef oyuncunun otomatik kabul özelliği açıksa, isteği beklemeden direkt kabul et
            if (autoAcceptPlayers.has(target.id)) {
                system.run(() => {
                    requester.sendMessage(
                        `§a${target.name} otomatik kabul açık olduğu için isteğini onayladı. Işınlanmak için 3 saniye hareketsiz dur.`
                    );
                    target.sendMessage(`§a${requester.name} adlı oyuncunun isteği otomatik olarak kabul edildi.`);
                    startTeleportCountdown(requester, target);
                });
                return { status: CustomCommandStatus.Success };
            }

            // aynı hedefe daha önce bekleyen bir istek varsa eski timeout'u iptal et
            const existing = pendingRequests.get(target.id);
            if (existing) {
                system.clearRun(existing.timeoutId);
            }

            const timeoutId = system.runTimeout(() => {
                const current = pendingRequests.get(target.id);
                if (current?.requesterId === requester.id) {
                    pendingRequests.delete(target.id);
                    system.run(() => {
                        requester.sendMessage(`§c${target.name} isteğine zamanında yanıt vermedi.`);
                        target.sendMessage(`§c${requester.name} adlı oyuncunun isteği zaman aşımına uğradı.`);
                    });
                }
            }, REQUEST_TIMEOUT_SECONDS * 20); // 20 tick = 1 saniye

            pendingRequests.set(target.id, {
                requesterId: requester.id,
                requesterName: requester.name,
                timeoutId,
            });

            system.run(() => {
                requester.sendMessage(`§a${target.name} adlı oyuncuya teleport isteği gönderildi.`);
                target.sendMessage(
                    `§e${requester.name} sana teleport olmak istiyor. §a/tpaccept§e (kabul et) veya §c/tpdeny§e (reddet)`
                );
            });

            return { status: CustomCommandStatus.Success };
        }
    );

    // /essentials:tpaccept
    customCommandRegistry.registerCommand(
        {
            name: "sg:tpaccept",
            description: "Bekleyen teleport isteğini kabul et.",
            permissionLevel: CommandPermissionLevel.Any,
            cheatsRequired: false,
        },
        (origin) => {
            const player = origin.sourceEntity;
            if (!player || !(player instanceof Player)) {
                return {
                    status: CustomCommandStatus.Failure,
                    message: "Bu komut sadece oyuncular tarafından kullanılabilir.",
                };
            }

            const request = pendingRequests.get(player.id);
            if (!request) {
                return { status: CustomCommandStatus.Failure, message: "Bekleyen bir teleport isteğin yok." };
            }

            pendingRequests.delete(player.id);
            system.clearRun(request.timeoutId);

            system.run(() => {
                const requester = world.getAllPlayers().find((p) => p.id === request.requesterId);
                if (!requester) {
                    player.sendMessage("§cİsteği gönderen oyuncu artık sunucuda değil.");
                    return;
                }
                player.sendMessage(`§a${requester.name} isteğini kabul ettin.`);
                requester.sendMessage(
                    `§a${player.name} isteğini kabul etti. Işınlanmak için 3 saniye hareketsiz dur, hareket edersen istek reddedilmiş sayılır.`
                );
                startTeleportCountdown(requester, player);
            });

            return { status: CustomCommandStatus.Success };
        }
    );

    // /essentials:tpdeny
    customCommandRegistry.registerCommand(
        {
            name: "sg:tpdeny",
            description: "Bekleyen teleport isteğini reddet.",
            permissionLevel: CommandPermissionLevel.Any,
            cheatsRequired: false,
        },
        (origin) => {
            const player = origin.sourceEntity;
            if (!player || !(player instanceof Player)) {
                return {
                    status: CustomCommandStatus.Failure,
                    message: "Bu komut sadece oyuncular tarafından kullanılabilir.",
                };
            }

            const request = pendingRequests.get(player.id);
            if (!request) {
                return { status: CustomCommandStatus.Failure, message: "Bekleyen bir teleport isteğin yok." };
            }

            pendingRequests.delete(player.id);
            system.clearRun(request.timeoutId);

            system.run(() => {
                player.sendMessage("§cİsteği reddettin.");
                const requester = world.getAllPlayers().find((p) => p.id === request.requesterId);
                if (requester) {
                    requester.sendMessage(`§c${player.name} teleport isteğini reddetti.`);
                }
            });

            return { status: CustomCommandStatus.Success };
        }
    );

    // /essentials:tpauto - otomatik kabulü aç/kapat
    customCommandRegistry.registerCommand(
        {
            name: "sg:tpauto",
            description: "Gelen teleport isteklerini otomatik kabul etmeyi aç/kapat.",
            permissionLevel: CommandPermissionLevel.Any,
            cheatsRequired: false,
        },
        (origin) => {
            const player = origin.sourceEntity;
            if (!player || !(player instanceof Player)) {
                return {
                    status: CustomCommandStatus.Failure,
                    message: "Bu komut sadece oyuncular tarafından kullanılabilir.",
                };
            }

            if (autoAcceptPlayers.has(player.id)) {
                autoAcceptPlayers.delete(player.id);
                system.run(() => player.sendMessage("§ctpauto kapatıldı"));
            } else {
                autoAcceptPlayers.add(player.id);
                system.run(() => player.sendMessage("§atpauto açık"));
            }

            return { status: CustomCommandStatus.Success };
        }
    );
}
