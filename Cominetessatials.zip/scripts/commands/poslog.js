import { CommandPermissionLevel, CustomCommandStatus, Player, system, world } from "@minecraft/server";
import { ActionFormData, ModalFormData } from "@minecraft/server-ui";
import { getKnownPlayerNames, findPlayerIdByName } from "../data/playerRegistry.js";
import {
    getLoggedPlayerIds,
    getLoggedDays,
    getDayEntries,
    dayKeyToDateLabel,
    secOfDayToLabel,
    dimShortToId,
    dimShortToLabel,
    formatStayDuration,
} from "../data/positionLogData.js";

function normalize(str) {
    return str
        .replace(/İ/g, "i")
        .replace(/I/g, "ı")
        .toLowerCase();
}

function nameForId(playerId, knownNames) {
    return knownNames.find((n) => findPlayerIdByName(n) === playerId) ?? playerId;
}

/** Konum logu bulunan tüm oyuncu isimlerini döner. */
function getLoggedPlayerNames() {
    const knownNames = getKnownPlayerNames();
    return getLoggedPlayerIds().map((id) => nameForId(id, knownNames));
}

function playerButtonLabel(name) {
    const id = findPlayerIdByName(name);
    const count = id ? getLoggedDays(id).length : 0;
    return `${name}\n${count} gün loglu`;
}

// ---------------------------------------------------------------------
// Ana menü
// ---------------------------------------------------------------------
function openMainMenu(admin) {
    const form = new ActionFormData()
        .title("§lKonum Log")
        .body("§8Bir kategori seç:")
        .button("§aÇevrimiçi Oyuncular")
        .button("§8Çevrimdışı Oyuncular")
        .button("§eOyuncu Ara");

    form.show(admin).then((res) => {
        if (res.canceled || !admin.isValid) return;
        switch (res.selection) {
            case 0:
                openPlayerListMenu(admin, "online");
                break;
            case 1:
                openPlayerListMenu(admin, "offline");
                break;
            case 2:
                openSearchMenu(admin);
                break;
        }
    });
}

// ---------------------------------------------------------------------
// Çevrimiçi / Çevrimdışı oyuncu listesi (sadece konum logu bulunanlar)
// ---------------------------------------------------------------------
function openPlayerListMenu(admin, mode) {
    const onlineNames = new Set(world.getAllPlayers().map((p) => p.name));
    const logged = getLoggedPlayerNames();

    const names = (mode === "online" ? logged.filter((n) => onlineNames.has(n)) : logged.filter((n) => !onlineNames.has(n))).sort(
        (a, b) => a.localeCompare(b)
    );

    const form = new ActionFormData()
        .title(mode === "online" ? "§lÇevrimiçi Oyuncular" : "§lÇevrimdışı Oyuncular")
        .body(names.length === 0 ? "§8Konum logu bulunan oyuncu yok." : "§8Konum geçmişini görmek için bir oyuncu seç:");

    for (const name of names) form.button(playerButtonLabel(name));
    form.button("§8<< Geri");

    form.show(admin).then((res) => {
        if (res.canceled || !admin.isValid) return;
        if (res.selection === names.length) {
            openMainMenu(admin);
            return;
        }
        const targetName = names[res.selection];
        openDayListMenu(admin, findPlayerIdByName(targetName), targetName, () => openPlayerListMenu(admin, mode));
    });
}

// ---------------------------------------------------------------------
// Oyuncu arama
// ---------------------------------------------------------------------
function openSearchMenu(admin) {
    const form = new ModalFormData().title("§lOyuncu Ara").textField("İsim (parça yeter)", "örn: ömer");

    form.show(admin).then((res) => {
        if (res.canceled || !admin.isValid) return;
        const query = normalize((res.formValues?.[0] ?? "").trim());
        if (!query) {
            openMainMenu(admin);
            return;
        }

        const logged = getLoggedPlayerNames();
        const matches = logged
            .map((name) => ({ name, idx: normalize(name).indexOf(query) }))
            .filter((e) => e.idx !== -1)
            .sort((a, b) => a.idx - b.idx || a.name.localeCompare(b.name))
            .slice(0, 25);

        openSearchResultsMenu(admin, query, matches.map((m) => m.name));
    });
}

function openSearchResultsMenu(admin, query, names) {
    const form = new ActionFormData()
        .title(`§lArama: "${query}"`)
        .body(names.length === 0 ? "§8Eşleşen oyuncu bulunamadı." : "§8Sonuçlar:");

    for (const name of names) form.button(playerButtonLabel(name));
    form.button("§8<< Geri");

    form.show(admin).then((res) => {
        if (res.canceled || !admin.isValid) return;
        if (res.selection === names.length) {
            openSearchMenu(admin);
            return;
        }
        const targetName = names[res.selection];
        openDayListMenu(admin, findPlayerIdByName(targetName), targetName, () => openSearchMenu(admin));
    });
}

// ---------------------------------------------------------------------
// Gün listesi
// ---------------------------------------------------------------------
function openDayListMenu(admin, playerId, playerName, onBack) {
    const days = getLoggedDays(playerId);

    const form = new ActionFormData()
        .title(`§l${playerName} §r§8- Loglu Günler`)
        .body(days.length === 0 ? "§8Kayıt yok." : "§8Bir gün seç:");

    for (const dk of days) {
        const entries = getDayEntries(playerId, dk);
        form.button(`${dayKeyToDateLabel(dk)}\n${entries.length} kayıt`);
    }
    form.button("§8<< Geri");

    form.show(admin).then((res) => {
        if (res.canceled || !admin.isValid) return;
        if (res.selection === days.length) {
            onBack();
            return;
        }
        openDayEntriesMenu(admin, playerId, playerName, days[res.selection], () =>
            openDayListMenu(admin, playerId, playerName, onBack)
        );
    });
}

// ---------------------------------------------------------------------
// Gün içindeki konum kayıtları (seçilince ışınlanma)
// ---------------------------------------------------------------------
function openDayEntriesMenu(admin, playerId, playerName, dayKey, onBack) {
    const entries = getDayEntries(playerId, dayKey);

    const form = new ActionFormData()
        .title(`§l${playerName} §r§8- ${dayKeyToDateLabel(dayKey)}`)
        .body(entries.length === 0 ? "§8Kayıt yok." : "§8Işınlanmak için bir kayıt seç:");

    for (const [sec, x, y, z, dim, checkCount] of entries) {
        form.button(
            `(${secOfDayToLabel(sec)})(pos:${x} ${y} ${z})\n(${formatStayDuration(checkCount)})(${dimShortToLabel(dim)})`
        );
    }
    form.button("§8<< Geri");

    form.show(admin).then((res) => {
        if (res.canceled || !admin.isValid) return;
        if (res.selection === entries.length) {
            onBack();
            return;
        }

        const [, x, y, z, dim] = entries[res.selection];
        system.run(() => {
            try {
                const dimension = world.getDimension(dimShortToId(dim));
                admin.teleport({ x, y, z }, { dimension });
                admin.sendMessage(`§a${playerName} adlı oyuncunun kaydına ışınlandın.`);
            } catch {
                admin.sendMessage("§cIşınlanma başarısız oldu.");
            }
        });
    });
}

/**
 * /sg:poslog
 * permissionLevel: GameDirectors -> sadece operatörler kullanabilir.
 * @param {import("@minecraft/server").CustomCommandRegistry} customCommandRegistry
 */
export default function poslog(customCommandRegistry) {
    customCommandRegistry.registerCommand(
        {
            name: "sg:poslog",
            description: "Oyuncuların 5 dakikada bir kaydedilen konum geçmişini görüntüle. (sadece operatör)",
            permissionLevel: CommandPermissionLevel.GameDirectors,
            cheatsRequired: false,
        },
        (origin) => {
            const player = origin.sourceEntity;
            if (!player || !(player instanceof Player)) {
                return {
                    status: CustomCommandStatus.Failure,
                    message: "Bu komut sadece oyuncular tarafından kullanılabilir.",
                };
            }

            system.run(() => {
                if (player.isValid) openMainMenu(player);
            });

            return { status: CustomCommandStatus.Success };
        }
    );
}
