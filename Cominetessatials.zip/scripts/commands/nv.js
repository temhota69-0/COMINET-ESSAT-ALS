import { CommandPermissionLevel, CustomCommandStatus, Player, system } from "@minecraft/server";

// Efekt süresi tick cinsinden (20 tick = 1 saniye). Gerçek "sonsuz" efekt
// olmadığı için çok büyük bir süre veriliyor (~13.8 saat), pratikte sınırsız.
const NIGHT_VISION_DURATION_TICKS = 999999;

/**
 * sg:nv komutunu kaydeder.
 * Kullanım: /sg:nv
 * Komutu kullanan oyuncuya sınırsız (çok uzun süreli) night vision verir.
 * Zaten aktifse efekti kaldırır (aç/kapa).
 * @param {import("@minecraft/server").CustomCommandRegistry} customCommandRegistry
 */
export default function nv(customCommandRegistry) {
    customCommandRegistry.registerCommand(
        {
            name: "sg:nv",
            description: "night vision aç/kapat.",
            permissionLevel: CommandPermissionLevel.Any,
            cheatsRequired: false,
        },
        (origin) => {
            const player = origin.sourceEntity;
            if (!player || !(player instanceof Player)) {
                return {
                    status: CustomCommandStatus.Failure,
                    message: "Bu komut sadece oyuncular tarafından kullanılabilir.",
                };
            }

            system.run(() => {
                if (!player.isValid) return;

                const hasNightVision = player.getEffect("night_vision") !== undefined;

                if (hasNightVision) {
                    player.removeEffect("night_vision");
                    player.sendMessage("§eNight vision kapatıldı.");
                } else {
                    player.addEffect("night_vision", NIGHT_VISION_DURATION_TICKS, {
                        amplifier: 0,
                        showParticles: false,
                    });
                    player.sendMessage("§aNight vision açıldı.");
                }
            });

            return { status: CustomCommandStatus.Success };
        }
    );
}
