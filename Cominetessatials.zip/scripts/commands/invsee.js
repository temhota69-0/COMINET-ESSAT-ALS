import { CommandPermissionLevel, CustomCommandStatus, EquipmentSlot, Player, system, world } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";
import { ChestFormData } from "../extensions/forms.js";

// UI slot düzeni (54'lük "large" chest):
//   0-26   -> hedef oyuncunun envanteri (27 slot)
//   27-35  -> hedef oyuncunun hotbar'ı (9 slot)
//   36-39  -> zırh: kask, göğüslük, pantolon, bot
//   40     -> sol el (offhand)
//   49     -> geri butonu
const BACK_SLOT = 49;

function buildInventorySlotMap() {
    const map = new Map();
    for (let i = 0; i < 27; i++) map.set(i, { kind: "container", index: 9 + i });
    for (let i = 0; i < 9; i++) map.set(27 + i, { kind: "container", index: i });
    map.set(36, { kind: "equip", eq: EquipmentSlot.Head, label: "Kask" });
    map.set(37, { kind: "equip", eq: EquipmentSlot.Chest, label: "Göğüslük" });
    map.set(38, { kind: "equip", eq: EquipmentSlot.Legs, label: "Pantolon" });
    map.set(39, { kind: "equip", eq: EquipmentSlot.Feet, label: "Bot" });
    map.set(40, { kind: "equip", eq: EquipmentSlot.Offhand, label: "Sol El" });
    return map;
}
const INVENTORY_SLOT_MAP = buildInventorySlotMap();

function formatItemName(typeId) {
    return typeId
        .replace(/^.*:/, "")
        .replace(/_/g, " ")
        .replace(/(^\w|\s\w)/g, (m) => m.toUpperCase());
}

function itemDurabilityPercent(item) {
    try {
        const d = item.getComponent("durability");
        if (!d) return 0;
        return Math.round(((d.maxDurability - d.damage) / d.maxDurability) * 99);
    } catch {
        return 0;
    }
}

function itemEnchanted(item) {
    try {
        const e = item.getComponent("enchantable");
        return Boolean(e && e.getEnchantments().length > 0);
    } catch {
        return false;
    }
}

function findOnlinePlayerByName(name) {
    return world.getAllPlayers().find((p) => p.name === name) ?? null;
}

function getEnderContainer(target) {
    try {
        const comp = target.getComponent("minecraft:ender_inventory") ?? target.getComponent("ender_inventory");
        return comp?.container ?? null;
    } catch {
        return null;
    }
}

function getItemAtInventoryMapping(target, mapping) {
    if (mapping.kind === "container") {
        const inv = target.getComponent("minecraft:inventory");
        return inv?.container?.getItem(mapping.index) ?? undefined;
    }
    const equippable = target.getComponent("minecraft:equippable");
    return equippable?.getEquipment(mapping.eq) ?? undefined;
}

function setItemAtInventoryMapping(target, mapping, item) {
    if (mapping.kind === "container") {
        const inv = target.getComponent("minecraft:inventory");
        inv?.container?.setItem(mapping.index, item);
        return;
    }
    const equippable = target.getComponent("minecraft:equippable");
    equippable?.setEquipment(mapping.eq, item);
}

// Adminin eline item verir: mainhand boşsa oraya, doluysa envantere, o da doluysa yere düşürür.
function giveToAdminHand(admin, item) {
    const equippable = admin.getComponent("minecraft:equippable");
    const current = equippable?.getEquipment(EquipmentSlot.Mainhand);
    if (equippable && !current) {
        equippable.setEquipment(EquipmentSlot.Mainhand, item);
        return;
    }

    const inv = admin.getComponent("minecraft:inventory");
    const leftover = inv?.container?.addItem(item);
    if (leftover) {
        try {
            admin.dimension.spawnItem(leftover, admin.location);
        } catch {}
    }
}

// ---------------------------------------------------------------------
// Envanter görünümü (envanter + hotbar + zırh + offhand)
// ---------------------------------------------------------------------
async function openInventoryView(admin, target) {
    if (!admin.isValid) return;
    if (!target.isValid) {
        admin.sendMessage("§cOyuncu artık çevrimdışı.");
        return;
    }

    const form = new ChestFormData("large").title(`§l${target.name} §r§8- Envanter`);

    for (const [slot, mapping] of INVENTORY_SLOT_MAP) {
        const item = getItemAtInventoryMapping(target, mapping);
        if (item) {
            form.button(
                slot,
                `§r§f${formatItemName(item.typeId)}`,
                mapping.label ? [`§7${mapping.label}`] : [],
                item.typeId,
                item.amount,
                itemDurabilityPercent(item),
                itemEnchanted(item)
            );
        } else if (mapping.label) {
            form.button(slot, `§8(Boş) ${mapping.label}`, [], "minecraft:barrier");
        }
    }
    form.button(BACK_SLOT, "§c<< Geri", [], "minecraft:barrier");

    const response = await form.show(admin);
    if (response.canceled || response.selection === undefined) return;
    if (response.selection === BACK_SLOT) {
        openPlayerActionMenu(admin, target);
        return;
    }

    const mapping = INVENTORY_SLOT_MAP.get(response.selection);
    if (!mapping) return openInventoryView(admin, target);

    const item = getItemAtInventoryMapping(target, mapping);
    if (!item) return openInventoryView(admin, target);

    await openItemActionMenu(admin, target, item, {
        get: () => getItemAtInventoryMapping(target, mapping),
        clear: () => setItemAtInventoryMapping(target, mapping, undefined),
    });
    openInventoryView(admin, target);
}

// ---------------------------------------------------------------------
// Ender sandığı görünümü (27 slot)
// ---------------------------------------------------------------------
async function openEnderChestView(admin, target) {
    if (!admin.isValid) return;
    if (!target.isValid) {
        admin.sendMessage("§cOyuncu artık çevrimdışı.");
        return;
    }

    const container = getEnderContainer(target);
    if (!container) {
        admin.sendMessage("§cEnder sandığı bu dünyada desteklenmiyor (Beta APIs açık olmayabilir).");
        openPlayerActionMenu(admin, target);
        return;
    }

    // 36'lık chest-ui: 0-26 ender sandığı içeriği, 27-35 alt satır (dolgu cam
    // + ortada kırmızı "Geri Dön"), /ah'daki shulker önizlemesiyle aynı stil.
    const ENDER_BACK_SLOT = 31;
    const form = new ChestFormData(36).title(`§l${target.name} §r§8- Ender Sandığı`);

    for (let i = 0; i < container.size && i < 27; i++) {
        const item = container.getItem(i);
        if (!item) continue;
        form.button(
            i,
            `§r§f${formatItemName(item.typeId)}`,
            [],
            item.typeId,
            item.amount,
            itemDurabilityPercent(item),
            itemEnchanted(item)
        );
    }

    for (let i = 27; i < 36; i++) {
        if (i === ENDER_BACK_SLOT) continue;
        form.button(i, "§r", [], "minecraft:gray_stained_glass_pane");
    }
    form.button(ENDER_BACK_SLOT, "§c« Geri Dön", [], "minecraft:red_stained_glass_pane");

    const response = await form.show(admin);
    if (response.canceled || response.selection === undefined) return;
    if (response.selection >= 27) {
        openPlayerActionMenu(admin, target);
        return;
    }

    const slot = response.selection;
    const item = container.getItem(slot);
    if (!item) return openEnderChestView(admin, target);

    await openItemActionMenu(admin, target, item, {
        get: () => getEnderContainer(target)?.getItem(slot),
        clear: () => getEnderContainer(target)?.setItem(slot, undefined),
    });
    openEnderChestView(admin, target);
}

// ---------------------------------------------------------------------
// Bir item'e tıklanınca çıkan işlem menüsü: Kopyala / Sil ve Ele Al / İptal
// ---------------------------------------------------------------------
async function openItemActionMenu(admin, target, item, accessors) {
    const form = new ActionFormData()
        .title(formatItemName(item.typeId))
        .body(`§7Adet: §f${item.amount}\n\n§aKopyala: §7item hedeften silinmez, sana klonu gelir.\n§cSil ve Ele Al: §7item hedeften silinir, klonu sana gelir.`)
        .button("§aKopyala (Ele Al)")
        .button("§cSil ve Ele Al")
        .button("§7İptal");

    const response = await form.show(admin);
    if (response.canceled || response.selection === undefined || response.selection === 2) return;

    // En güncel veriyi tekrar al (menüler arası gecikmede değişmiş olabilir).
    const current = accessors.get();
    if (!current) return;

    if (response.selection === 0) {
        giveToAdminHand(admin, current.clone());
        admin.sendMessage(`§a${formatItemName(current.typeId)} eline kopyalandı.`);
        return;
    }

    if (response.selection === 1) {
        const clone = current.clone();
        accessors.clear();
        giveToAdminHand(admin, clone);
        admin.sendMessage(`§a${formatItemName(clone.typeId)} hedeften silindi ve eline alındı.`);
    }
}

// ---------------------------------------------------------------------
// Oyuncu seçildikten sonra: Envanter mi Ender Sandığı mı
// ---------------------------------------------------------------------
function openPlayerActionMenu(admin, target) {
    const form = new ActionFormData()
        .title(target.name)
        .body("§8Ne görüntülemek istersin?")
        .button("§lEnvanter")
        .button("§lEnder Sandığı")
        .button("§8<< Geri");

    form.show(admin).then((res) => {
        if (res.canceled || !admin.isValid) return;
        if (res.selection === 0) {
            openInventoryView(admin, target);
        } else if (res.selection === 1) {
            openEnderChestView(admin, target);
        } else {
            openPlayerSelectMenu(admin);
        }
    });
}

// ---------------------------------------------------------------------
// Ana menü: sadece çevrimiçi oyuncular
// ---------------------------------------------------------------------
function openPlayerSelectMenu(admin) {
    const names = world
        .getAllPlayers()
        .map((p) => p.name)
        .sort((a, b) => a.localeCompare(b));

    const form = new ActionFormData()
        .title("§lInvSee - Oyuncu Seç")
        .body(names.length === 0 ? "§8Çevrimiçi oyuncu yok." : "§8İncelemek için bir oyuncu seç:");

    for (const name of names) form.button(name);

    form.show(admin).then((res) => {
        if (res.canceled || res.selection === undefined || !admin.isValid) return;
        const targetName = names[res.selection];
        const target = findOnlinePlayerByName(targetName);
        if (!target) {
            admin.sendMessage("§cOyuncu artık çevrimiçi değil.");
            return;
        }
        openPlayerActionMenu(admin, target);
    });
}

/**
 * /sg:invsee komutunu kaydeder.
 * @param {import("@minecraft/server").CustomCommandRegistry} customCommandRegistry
 */
export default function invsee(customCommandRegistry) {
    customCommandRegistry.registerCommand(
        {
            name: "sg:invsee",
            description: "Çevrimiçi bir oyuncunun envanterini / ender sandığını görüntüle. (sadece operatör)",
            permissionLevel: CommandPermissionLevel.GameDirectors,
            cheatsRequired: false,
        },
        (origin) => {
            const player = origin.sourceEntity;
            if (!player || !(player instanceof Player)) {
                return {
                    status: CustomCommandStatus.Failure,
                    message: "Bu komut sadece oyuncular tarafından kullanılabilir.",
                };
            }

            system.run(() => {
                if (player.isValid) openPlayerSelectMenu(player);
            });

            return { status: CustomCommandStatus.Success };
        }
    );
}
