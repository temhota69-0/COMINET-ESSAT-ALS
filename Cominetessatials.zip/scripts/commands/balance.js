import {
    CommandPermissionLevel,
    CustomCommandParamType,
    CustomCommandStatus,
    Player,
    ScoreboardIdentityType,
    world,
} from "@minecraft/server";

const SCOREBOARD_NAME = "Para";
const PAGE_SIZE = 10;

// Scoreboard identity id -> gerçek oyuncu adı önbelleği.
// Offline oyuncularda ScoreboardIdentity.displayName bazen bozuk/placeholder
// dönebildiği için, oyuncu online olduğu her an gerçek adını burada saklıyoruz.
const NAME_CACHE_KEY = "sg:balanceNameCache";

function getObjective() {
    return world.scoreboard.getObjective(SCOREBOARD_NAME);
}

function getNameCache() {
    const raw = world.getDynamicProperty(NAME_CACHE_KEY);
    if (typeof raw !== "string") return {};
    try {
        const parsed = JSON.parse(raw);
        return parsed && typeof parsed === "object" ? parsed : {};
    } catch {
        return {};
    }
}

function saveNameCache(cache) {
    world.setDynamicProperty(NAME_CACHE_KEY, JSON.stringify(cache));
}

/**
 * Bir scoreboard identity'si için en güvenilir görünen ismi döner.
 * Önce isim önbelleğine bakar (offline'da bile doğru çalışır),
 * bulamazsa identity.displayName'e düşer.
 * @param {import("@minecraft/server").ScoreboardIdentity} identity
 */
function resolveDisplayName(identity) {
    const cache = getNameCache();
    const cached = cache[String(identity.id)];
    return cached ?? identity.displayName;
}

/**
 * Her oyuncu spawn olduğunda (online olduğunda) scoreboard identity id -> isim
 * eşleşmesini kaydeder. main.js içinde bir kere çağrılmalı.
 */
export function initBalanceNameCache() {
    world.afterEvents.playerSpawn.subscribe((event) => {
        const player = event.player;
        const identity = player.scoreboardIdentity;
        if (!identity) return;

        const cache = getNameCache();
        if (cache[String(identity.id)] !== player.name) {
            cache[String(identity.id)] = player.name;
            saveNameCache(cache);
        }
    });
}

/**
 * İsme göre (online ya da offline) scoreboard identity'sini bulur.
 * Hem isim önbelleğini hem de displayName'i kontrol eder.
 * @param {import("@minecraft/server").ScoreboardObjective} objective
 * @param {string} name
 */
function findIdentityByName(objective, name) {
    const lower = name.toLowerCase();
    return objective
        .getParticipants()
        .find((p) => p.type === ScoreboardIdentityType.Player && resolveDisplayName(p).toLowerCase() === lower);
}

function missingObjectiveError() {
    return {
        status: CustomCommandStatus.Failure,
        message: `"${SCOREBOARD_NAME}" adlı scoreboard bulunamadı. Önce oluştur: /scoreboard objectives add ${SCOREBOARD_NAME} dummy`,
    };
}

/**
 * @param {import("@minecraft/server").CustomCommandOrigin} origin
 * @param {string | undefined} targetName
 */
function handleBalance(origin, targetName) {
    const sender = origin.sourceEntity;
    if (!sender || !(sender instanceof Player)) {
        return { status: CustomCommandStatus.Failure, message: "Bu komut sadece oyuncular tarafından kullanılabilir." };
    }

    const objective = getObjective();
    if (!objective) return missingObjectiveError();

    // hedef verilmediyse kendi bakiyeni göster
    if (!targetName) {
        const score = objective.getScore(sender) ?? 0;
        sender.sendMessage(`§aBakiyen: §e${score} Para`);
        return { status: CustomCommandStatus.Success };
    }

    if (targetName.startsWith("@")) {
        return { status: CustomCommandStatus.Failure, message: "Hedef seçici (@a, @p vb.) kullanılamaz, oyuncunun adını yaz." };
    }

    const identity = findIdentityByName(objective, targetName);
    if (!identity) {
        return { status: CustomCommandStatus.Failure, message: `"${targetName}" adlı oyuncunun bakiye kaydı bulunamadı.` };
    }

    const score = objective.getScore(identity) ?? 0;
    sender.sendMessage(`§a${resolveDisplayName(identity)} §7adlı oyuncunun bakiyesi: §e${score} Para`);
    return { status: CustomCommandStatus.Success };
}

/**
 * @param {import("@minecraft/server").CustomCommandOrigin} origin
 * @param {number | undefined} page
 */
function handleBalTop(origin, page) {
    const sender = origin.sourceEntity;
    if (!sender || !(sender instanceof Player)) {
        return { status: CustomCommandStatus.Failure, message: "Bu komut sadece oyuncular tarafından kullanılabilir." };
    }

    const objective = getObjective();
    if (!objective) return missingObjectiveError();

    const entries = objective
        .getParticipants()
        .filter((p) => p.type === ScoreboardIdentityType.Player)
        .map((p) => ({ name: resolveDisplayName(p), score: objective.getScore(p) ?? 0 }))
        .sort((a, b) => b.score - a.score);

    if (entries.length === 0) {
        sender.sendMessage("§cHenüz kayıtlı hiçbir bakiye yok.");
        return { status: CustomCommandStatus.Success };
    }

    const totalPages = Math.max(1, Math.ceil(entries.length / PAGE_SIZE));
    const pageNum = Math.min(Math.max(page ?? 1, 1), totalPages);
    const start = (pageNum - 1) * PAGE_SIZE;
    const pageEntries = entries.slice(start, start + PAGE_SIZE);

    const medals = ["§6#1", "§7#2", "§c#3"];
    const lines = pageEntries.map((entry, i) => {
        const rank = start + i + 1;
        const prefix = rank <= 3 ? medals[rank - 1] : `§7#${rank}`;
        return `${prefix} §f${entry.name} §8- §e${entry.score} Para`;
    });

    sender.sendMessage(`§6=== Zenginlik Sıralaması (${pageNum}/${totalPages}) ===\n${lines.join("\n")}`);
    return { status: CustomCommandStatus.Success };
}

/**
 * @param {import("@minecraft/server").CustomCommandOrigin} origin
 * @param {number} identityId
 * @param {string} name
 */
function handleSetBalName(origin, identityId, name) {
    if (!Number.isFinite(identityId)) {
        return { status: CustomCommandStatus.Failure, message: "Geçersiz id." };
    }

    const cache = getNameCache();
    cache[String(identityId)] = name;
    saveNameCache(cache);

    return { status: CustomCommandStatus.Success, message: `§aId §e${identityId} §aiçin isim §e${name} §aolarak kaydedildi.` };
}

/**
 * Op'ların bozuk/görünmeyen isimleri eşleştirebilmesi için tüm Player tipi
 * identity id + mevcut skoru listeler. Gerçek ismi başka yerden (örn. vanilla
 * /scoreboard players list) teyit edip /sg:setbalname ile elle atayabilirler.
 * @param {import("@minecraft/server").CustomCommandOrigin} origin
 */
function handleBalTopId(origin) {
    const sender = origin.sourceEntity;
    if (!sender || !(sender instanceof Player)) {
        return { status: CustomCommandStatus.Failure, message: "Bu komut sadece oyuncular tarafından kullanılabilir." };
    }

    const objective = getObjective();
    if (!objective) return missingObjectiveError();

    const cache = getNameCache();
    const entries = objective
        .getParticipants()
        .filter((p) => p.type === ScoreboardIdentityType.Player)
        .map((p) => ({ id: p.id, cached: cache[String(p.id)] ?? null, raw: p.displayName, score: objective.getScore(p) ?? 0 }))
        .sort((a, b) => b.score - a.score);

    const lines = entries.map((e) => `§7id:§f${e.id} §8- §e${e.score} Para §8- ${e.cached ? `§a${e.cached}` : `§c${e.raw}`}`);
    sender.sendMessage(`§6=== Bakiye Id Listesi ===\n${lines.join("\n")}`);
    return { status: CustomCommandStatus.Success };
}

/**
 * sg:balance, sg:bal (kısayol) ve sg:baltop komutlarını kaydeder.
 * Kullanım:
 *   /sg:balance [oyuncu]  veya  /sg:bal [oyuncu]  -> bakiye göster
 *   /sg:baltop [sayfa]                            -> zenginlik sıralaması
 * @param {import("@minecraft/server").CustomCommandRegistry} customCommandRegistry
 */
export default function balance(customCommandRegistry) {
    const balanceParams = {
        permissionLevel: CommandPermissionLevel.Any,
        cheatsRequired: false,
        optionalParameters: [{ name: "oyuncu", type: CustomCommandParamType.String }],
    };

    customCommandRegistry.registerCommand(
        { name: "sg:balance", description: "Kendi bakiyeni veya bir oyuncunun bakiyesini gör.", ...balanceParams },
        (origin, targetName) => handleBalance(origin, targetName)
    );

    // /sg:bal -> /sg:balance ile birebir aynı davranış, sadece kısa isim
    customCommandRegistry.registerCommand(
        { name: "sg:bal", description: "Bakiyeni gör. (/sg:balance kısayolu)", ...balanceParams },
        (origin, targetName) => handleBalance(origin, targetName)
    );

    customCommandRegistry.registerCommand(
        {
            name: "sg:baltop",
            description: "En zengin oyuncuları listeler.",
            permissionLevel: CommandPermissionLevel.Any,
            cheatsRequired: false,
            optionalParameters: [{ name: "sayfa", type: CustomCommandParamType.Integer }],
        },
        (origin, page) => handleBalTop(origin, page)
    );

    customCommandRegistry.registerCommand(
        {
            name: "sg:baltopid",
            description: "Bozuk/offline isimleri eşleştirmek için id listesi gösterir. (op)",
            permissionLevel: CommandPermissionLevel.GameDirectors,
            cheatsRequired: false,
        },
        (origin) => handleBalTopId(origin)
    );

    customCommandRegistry.registerCommand(
        {
            name: "sg:setbalname",
            description: "Bir scoreboard id'sine elle gerçek isim atar. (op)",
            permissionLevel: CommandPermissionLevel.GameDirectors,
            cheatsRequired: false,
            mandatoryParameters: [
                { name: "id", type: CustomCommandParamType.Integer },
                { name: "isim", type: CustomCommandParamType.String },
            ],
        },
        (origin, identityId, name) => handleSetBalName(origin, identityId, name)
    );
}
