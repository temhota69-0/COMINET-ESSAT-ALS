import { CommandPermissionLevel, CustomCommandStatus, ItemStack, Player, system, world } from "@minecraft/server";
import { ModalFormData } from "@minecraft/server-ui";
import { ChestFormData } from "../extensions/forms.js";
import { getCategories, decreaseStock } from "../data/shopData.js";
import { createSpawnerItemStack } from "../systems/spawnerSystem.js";

const SCOREBOARD_NAME = "Para";
const ITEMS_PER_PAGE = 45; // slot 0-44 eşya, 45-53 kontrol/sayfalama

// Her kategori kendi objective'ine (Para, DarkCoin vb.) göre çalışır.
function getObjective(name = SCOREBOARD_NAME) {
    return world.scoreboard.getObjective(name);
}

function getBalance(objective, player) {
    return objective.getScore(player) ?? 0;
}

/**
 * Bir itemin gerçek stack üst sınırını döner (ör. ender pearl: 16, çoğu blok: 64).
 * Sabit 64 varsaymak yerine ItemStack'in kendi maxAmount değerini okur.
 */
function getMaxStackSize(typeId) {
    try {
        return new ItemStack(typeId, 1).maxAmount;
    } catch {
        return 64;
    }
}

/**
 * Envantere item ekler; itemin gerçek stack limitinden büyük miktarları stack'lere böler.
 * @returns {number} envantere sığmayan (verilemeyen) miktar
 */
function giveItems(player, typeId, amount) {
    const inventory = player.getComponent("inventory");
    const container = inventory?.container;
    if (!container) return amount;

    const maxStack = getMaxStackSize(typeId);
    let remaining = amount;
    while (remaining > 0) {
        const stackAmount = Math.min(remaining, maxStack);
        const itemStack = new ItemStack(typeId, stackAmount);
        const leftover = container.addItem(itemStack);
        if (leftover) {
            remaining = remaining - stackAmount + leftover.amount;
            break;
        }
        remaining -= stackAmount;
    }
    return remaining;
}

function stockLore(item) {
    return item.stock === -1 ? "§7Stok: §asınırsız" : `§7Stok: §f${item.stock}`;
}

/**
 * Spawner eşyaları normal eşyalardan farklı: stacklenemez, tek adet alınır ve
 * yerleştirildiğinde özel spawner sistemine kaydolur (bkz. systems/spawnerSystem.js).
 * @param {import("@minecraft/server").Player} player
 * @param {import("../data/shopData.js").ShopCategory} category
 * @param {import("../data/shopData.js").ShopItem} item
 * @param {number} page
 * @param {string} currencyName
 */
async function purchaseSpawner(player, category, item, page, currencyName) {
    const objective = getObjective(currencyName);
    if (!objective) {
        player.sendMessage(`§c"${currencyName}" adlı scoreboard bulunamadı. Önce oluştur: /scoreboard objectives add ${currencyName} dummy`);
        return openCategoryMenu(player, category, page);
    }

    const balance = getBalance(objective, player);
    if (balance < item.price) {
        player.sendMessage(`§cYeterli ${currencyName} yok. Gereken: §e${item.price} ${currencyName}`);
        return openCategoryMenu(player, category, page);
    }

    const container = player.getComponent("inventory")?.container;
    const spawnerStack = createSpawnerItemStack(item.spawnerType);
    const leftover = container?.addItem(spawnerStack);
    if (leftover) {
        player.sendMessage("§cEnvanterinde yer yok.");
        return openCategoryMenu(player, category, page);
    }

    objective.setScore(player, balance - item.price);
    player.sendMessage(`§a${item.name} §asatın aldın. §e-${item.price} ${currencyName}`);
    return openCategoryMenu(player, category, page);
}

/**
 * @param {import("@minecraft/server").Player} player
 * @param {import("../data/shopData.js").ShopCategory} category
 * @param {import("../data/shopData.js").ShopItem} item
 * @param {number} index
 * @param {number} page
 */
async function openItemPurchase(player, category, item, index, page) {
    const currencyName = category.currency ?? "Para";

    // Spawner eşyaları için ayrı, miktar seçimi olmayan bir akış kullanılır.
    if (item.spawnerType) {
        return purchaseSpawner(player, category, item, page, currencyName);
    }

    const objective = getObjective(currencyName);
    const balance = getBalance(objective, player);
    const maxStack = getMaxStackSize(item.item);
    const maxAffordable = item.price > 0 ? Math.floor(balance / item.price) : maxStack;
    const stockCap = item.stock === -1 ? maxStack : Math.min(maxStack, item.stock);
    const maxAmount = Math.max(1, Math.min(maxAffordable, stockCap));

    // NOT: @minecraft/server-ui 2.0+ ile slider() imzası değişti; 4. parametre artık
    // sayı (valueStep) değil, { valueStep, defaultValue } objesi. Eski haliyle (düz
    // sayı geçmek) form açılırken hataya düşüp satın alma akışını tamamen kırıyordu.
    const modal = new ModalFormData()
        .title(item.name)
        .slider(`Birim fiyat: ${item.price} ${currencyName}  |  Bakiyen: ${balance} ${currencyName}`, 1, Math.max(1, maxAmount), {
            valueStep: 1,
            defaultValue: 1,
        });

    const response = await modal.show(player);
    if (response.canceled) return openCategoryMenu(player, category, page);

    const amount = response.formValues?.[0] ?? 1;
    const total = amount * item.price;

    if (getBalance(objective, player) < total) {
        player.sendMessage(`§cYeterli ${currencyName} yok.`);
        return openCategoryMenu(player, category, page);
    }
    if (item.stock !== -1 && item.stock < amount) {
        player.sendMessage("§cYeterli stok kalmamış.");
        return openCategoryMenu(player, category, page);
    }

    const notGiven = giveItems(player, item.item, amount);
    const given = amount - notGiven;
    if (given <= 0) {
        player.sendMessage("§cEnvanterinde yer yok.");
        return openCategoryMenu(player, category, page);
    }

    const cost = given * item.price;
    objective.setScore(player, getBalance(objective, player) - cost);
    decreaseStock(category.id, index, given);

    player.sendMessage(`§a${given} adet §f${item.name} §asatın aldın. §e-${cost} ${currencyName}`);
    if (notGiven > 0) {
        player.sendMessage(`§e${notGiven} adet için envanterinde yer kalmadığından parası alınmadı.`);
    }

    return openCategoryMenu(player, category, page);
}

/**
 * @param {import("@minecraft/server").Player} player
 * @param {import("../data/shopData.js").ShopCategory} category
 * @param {number} page
 */
async function openCategoryMenu(player, category, page = 0) {
    const availableItems = category.items.filter((it) => it.stock === -1 || it.stock > 0);
    if (availableItems.length === 0) {
        player.sendMessage("§cBu kategoride şu anda satılık eşya yok.");
        return openShopMenu(player);
    }

    const totalPages = Math.max(1, Math.ceil(availableItems.length / ITEMS_PER_PAGE));
    page = Math.min(Math.max(page, 0), totalPages - 1);
    const start = page * ITEMS_PER_PAGE;
    const pageItems = availableItems.slice(start, start + ITEMS_PER_PAGE);

    const currencyName = category.currency ?? "Para";
    const form = new ChestFormData("large").title(`${category.name} §r§8(${page + 1}/${totalPages})`);

    pageItems.forEach((item, i) => {
        const lore = item.spawnerType
            ? [`§e${item.price} ${currencyName}`, "", "§a[Satın Almak İçin Tıkla]"]
            : [`§e${item.price} ${currencyName} §7/ adet`, stockLore(item), "", "§a[Satın Almak İçin Tıkla]"];
        form.button(i, `§f${item.name}`, lore, item.icon || item.item);
    });

    if (page > 0) form.button(45, "§7« Önceki Sayfa", [], "minecraft:arrow");
    form.button(49, "§6« Mağaza Menüsü", [], "minecraft:barrier");
    if (page < totalPages - 1) form.button(53, "§7Sonraki Sayfa »", [], "minecraft:arrow");

    const response = await form.show(player);
    if (response.canceled || response.selection === undefined) return;

    const selection = response.selection;
    if (selection < ITEMS_PER_PAGE && pageItems[selection]) {
        const selectedItem = pageItems[selection];
        const realIndex = category.items.indexOf(selectedItem);
        return openItemPurchase(player, category, selectedItem, realIndex, page);
    }

    switch (selection) {
        case 45:
            if (page > 0) return openCategoryMenu(player, category, page - 1);
            return;
        case 49:
            return openShopMenu(player);
        case 53:
            if (page < totalPages - 1) return openCategoryMenu(player, category, page + 1);
            return;
        default:
            return;
    }
}

async function openShopMenu(player) {
    const categories = getCategories();
    if (categories.length === 0) {
        player.sendMessage("§cMağaza henüz yapılandırılmamış. scripts/data/shopConfig.js dosyasını düzenle.");
        return;
    }

    const form = new ChestFormData("large").title("§l§2Mağaza");
    categories.forEach((category, i) => {
        const itemCount = category.items.filter((it) => it.stock === -1 || it.stock > 0).length;
        form.button(i, `§f${category.name}`, [`§7${itemCount} eşya mevcut`], category.icon || "minecraft:emerald");
    });

    const response = await form.show(player);
    if (response.canceled || response.selection === undefined) return;

    const category = categories[response.selection];
    if (!category) return;
    return openCategoryMenu(player, category, 0);
}

/**
 * sg:shop komutunu kaydeder (oyuncular için chest UI tabanlı satın alma menüsü).
 * @param {import("@minecraft/server").CustomCommandRegistry} customCommandRegistry
 */
export default function shop(customCommandRegistry) {
    customCommandRegistry.registerCommand(
        {
            name: "sg:shop",
            description: "Mağazayı aç ve eşya satın al.",
            permissionLevel: CommandPermissionLevel.Any,
            cheatsRequired: false,
        },
        (origin) => {
            const player = origin.sourceEntity;
            if (!player || !(player instanceof Player)) {
                return { status: CustomCommandStatus.Failure, message: "Bu komut sadece oyuncular tarafından kullanılabilir." };
            }

            const objective = getObjective();
            if (!objective) {
                return {
                    status: CustomCommandStatus.Failure,
                    message: `"${SCOREBOARD_NAME}" adlı scoreboard bulunamadı. Önce oluştur: /scoreboard objectives add ${SCOREBOARD_NAME} dummy`,
                };
            }

            system.run(() => openShopMenu(player));
            return { status: CustomCommandStatus.Success };
        }
    );
}
