import {
    CommandPermissionLevel,
    CustomCommandParamType,
    CustomCommandStatus,
    EquipmentSlot,
    Player,
    system,
    world,
} from "@minecraft/server";
import { SellPreset } from "../data/sellPreset.js";

const SCOREBOARD_NAME = "Para";

// item id -> fiyat map'i (SellPreset dosyasından üretilir, hiç dokunulmadı)
const PRICE_MAP = new Map(SellPreset.map((entry) => [entry.item, entry.price]));

/**
 * Bir item id'sinin satılabilir olup olmadığını ve fiyatını döner.
 * Fiyatı 0 veya listede olmayan itemler satılamaz sayılır.
 * @param {string} typeId
 * @returns {number | null}
 */
function getSellPrice(typeId) {
    const price = PRICE_MAP.get(typeId);
    if (!price || price <= 0) return null;
    return price;
}

function getScoreboard() {
    return world.scoreboard.getObjective(SCOREBOARD_NAME);
}

function addMoney(player, objective, amount) {
    const current = objective.getScore(player) ?? 0;
    objective.setScore(player, current + amount);
}

/**
 * Container içindeki belirtilen slot aralığını satar.
 * @param {import("@minecraft/server").Player} player
 * @param {import("@minecraft/server").Container} container
 * @param {number} startSlot
 * @param {number} endSlot (dahil değil)
 * @returns {{ total: number, count: number }}
 */
function sellSlots(player, container, startSlot, endSlot) {
    let total = 0;
    let count = 0;

    for (let slot = startSlot; slot < endSlot; slot++) {
        const itemStack = container.getItem(slot);
        if (!itemStack) continue;

        const price = getSellPrice(itemStack.typeId);
        if (price === null) continue;

        total += price * itemStack.amount;
        count += itemStack.amount;
        container.setItem(slot, undefined);
    }

    return { total, count };
}

/**
 * sg:sell komutunu kaydeder.
 * Kullanım:
 *   /sg:sell            -> elindeki (mainhand) itemi satar
 *   /sg:sell hand       -> yukarıdakiyle aynı
 *   /sg:sell all        -> envanterdeki (hotbar dahil) satılabilir her şeyi satar
 *   /sg:sell hotbar     -> sadece hotbar'daki satılabilir itemleri satar
 * @param {import("@minecraft/server").CustomCommandRegistry} customCommandRegistry
 */
export default function sell(customCommandRegistry) {
    customCommandRegistry.registerCommand(
        {
            name: "sg:sell",
            description: "Elindeki veya envanterindeki itemleri sat.",
            permissionLevel: CommandPermissionLevel.Any,
            cheatsRequired: false,
            optionalParameters: [{ name: "secenek", type: CustomCommandParamType.String }],
        },
        (origin, secenek) => {
            const player = origin.sourceEntity;
            if (!player || !(player instanceof Player)) {
                return {
                    status: CustomCommandStatus.Failure,
                    message: "Bu komut sadece oyuncular tarafından kullanılabilir.",
                };
            }

            const objective = getScoreboard();
            if (!objective) {
                return {
                    status: CustomCommandStatus.Failure,
                    message: `"${SCOREBOARD_NAME}" adlı scoreboard bulunamadı. Önce oluştur: /scoreboard objectives add ${SCOREBOARD_NAME} dummy`,
                };
            }

            const mode = (secenek ?? "hand").toLowerCase();

            const inventory = player.getComponent("inventory");
            const container = inventory?.container;
            if (!container) {
                return { status: CustomCommandStatus.Failure, message: "Envanterine erişilemedi." };
            }

            if (mode === "all") {
                system.run(() => {
                    const { total, count } = sellSlots(player, container, 0, container.size);
                    if (total <= 0) {
                        player.sendMessage("§cSatılabilir hiçbir itemin yok.");
                        return;
                    }
                    addMoney(player, objective, total);
                    player.sendMessage(`§a${count} adet item sattın ve §e${total} Para§a kazandın.`);
                });
                return { status: CustomCommandStatus.Success };
            }

            if (mode === "hotbar") {
                system.run(() => {
                    const { total, count } = sellSlots(player, container, 0, 9);
                    if (total <= 0) {
                        player.sendMessage("§cHotbarında satılabilir hiçbir item yok.");
                        return;
                    }
                    addMoney(player, objective, total);
                    player.sendMessage(`§a${count} adet item sattın ve §e${total} Para§a kazandın.`);
                });
                return { status: CustomCommandStatus.Success };
            }

            if (mode === "hand") {
                system.run(() => {
                    const equippable = player.getComponent("minecraft:equippable");
                    const itemStack = equippable?.getEquipment(EquipmentSlot.Mainhand);

                    if (!itemStack) {
                        player.sendMessage("§cElinde satılacak bir item yok.");
                        return;
                    }

                    const price = getSellPrice(itemStack.typeId);
                    if (price === null) {
                        player.sendMessage("§cElindeki item satılamaz.");
                        return;
                    }

                    const total = price * itemStack.amount;
                    equippable.setEquipment(EquipmentSlot.Mainhand, undefined);
                    addMoney(player, objective, total);
                    player.sendMessage(`§a${itemStack.amount} adet ${itemStack.typeId} sattın ve §e${total} Para§a kazandın.`);
                });
                return { status: CustomCommandStatus.Success };
            }

            return {
                status: CustomCommandStatus.Failure,
                message: `Geçersiz seçenek: "${secenek}". Kullanım: /sg:sell, /sg:sell hand, /sg:sell hotbar, /sg:sell all`,
            };
        }
    );
}
