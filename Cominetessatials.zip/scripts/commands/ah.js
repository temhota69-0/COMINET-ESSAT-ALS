// sg:ah — v.I
import {
    CommandPermissionLevel,
    CustomCommandParamType,
    CustomCommandStatus,
    EquipmentSlot,
    Player,
    system,
} from "@minecraft/server";
import { ModalFormData, MessageFormData } from "@minecraft/server-ui";
import { ChestFormData } from "../extensions/forms.js";
import {
    ensureStorageEntity,
    createListing,
    cancelListing,
    buyListing,
    listListings,
    getListingItem,
    getScoreboard,
    isShulkerBox,
    captureShulkerFromBlock,
} from "../data/ahData.js";

const ITEMS_PER_PAGE = 45;
const sessionState = new Map();

function getState(playerId) {
    let state = sessionState.get(playerId);
    if (!state) {
        state = { mode: "browse", page: 0, filter: "" };
        sessionState.set(playerId, state);
    }
    return state;
}

function formatItemName(typeId) {
    return typeId
        .replace(/^.*:/, "")
        .replace(/_/g, " ")
        .replace(/(^\w|\s\w)/g, (m) => m.toUpperCase());
}

// Bazı sürümlerde component id'si kısa ("enchantable") bazılarında
// tam namespace'li ("minecraft:enchantable") isteniyor; ayrıca büyülü
// kitaplarda component farklı davranabiliyor. İkisini de deniyoruz ve
// hatayı artık sessizce yutmuyoruz (debug için console.warn).
function getEnchantComponent(item) {
    for (const id of ["enchantable", "minecraft:enchantable"]) {
        try {
            const comp = item.getComponent(id);
            if (comp) return comp;
        } catch (e) {
            // devam et, diğer id'yi dene
        }
    }
    return undefined;
}

function getDurabilityComponent(item) {
    for (const id of ["durability", "minecraft:durability"]) {
        try {
            const comp = item.getComponent(id);
            if (comp) return comp;
        } catch (e) {
            // devam et
        }
    }
    return undefined;
}

function sellFromHand(player, price) {
    const equippable = player.getComponent("minecraft:equippable");
    const item = equippable?.getEquipment(EquipmentSlot.Mainhand);
    if (!item || item.typeId === "minecraft:air") {
        return { ok: false, reason: "Elinde satılacak bir eşya yok." };
    }

    if (isShulkerBox(item.typeId)) {
        return {
            ok: false,
            reason:
                "Dolu bir shulker kutusu elden satılamaz. Önce kutuyu yere koy, üzerine bakarken §e/sg:ah sellshulker <fiyat>§c yaz.",
        };
    }

    const result = createListing(player, item, price);
    if (!result.ok) return result;

    equippable.setEquipment(EquipmentSlot.Mainhand, undefined);
    return result;
}

// Oyuncunun BAKTIĞI (hedefteki) dolu shulker kutusu bloğunu satışa çıkarır.
// İçeriği okumanın tek güvenilir yolu budur (bkz. ahData.js açıklaması).
function sellShulkerFromTarget(player, price) {
    let targetBlock;
    try {
        targetBlock = player.getBlockFromViewDirection({ maxDistance: 8 })?.block;
    } catch (e) {
        targetBlock = undefined;
    }

    if (!targetBlock || !isShulkerBox(targetBlock.typeId)) {
        return { ok: false, reason: "Baktığın yerde satılacak, yere konmuş bir shulker kutusu yok." };
    }

    const captured = captureShulkerFromBlock(targetBlock);
    if (!captured) {
        return { ok: false, reason: "Shulker kutusu okunamadı, tekrar dene." };
    }

    const result = createListing(player, captured.item, price, captured.contents);
    if (!result.ok) {
        // İlan oluşturulamadıysa kırılan kutuyu oyuncuya geri ver.
        const inv = player.getComponent("inventory")?.container;
        const leftover = inv?.addItem(captured.item.clone());
        if (leftover) {
            try { player.dimension.spawnItem(leftover, player.location); } catch {}
        }
        return result;
    }

    return result;
}

async function openMenu(player, state) {
    ensureStorageEntity();

    const filter = state.mode === "mine" ? { ownerId: player.id } : state.filter ? { query: state.filter } : {};
    const listings = listListings(filter);

    const totalPages = Math.max(1, Math.ceil(listings.length / ITEMS_PER_PAGE));
    state.page = Math.min(Math.max(state.page, 0), totalPages - 1);
    const start = state.page * ITEMS_PER_PAGE;
    const pageListings = listings.slice(start, start + ITEMS_PER_PAGE);

    const myCount = state.mode === "mine" ? listings.length : listListings({ ownerId: player.id }).length;

    const form = new ChestFormData("large").title(
        state.mode === "mine" ? "§l§6İhale Evi §r§8- §7Satışlarım" : `§l§2İhale Evi §r§8(${state.page + 1}/${totalPages})`
    );

    pageListings.forEach((listing, i) => {
        const item = getListingItem(listing.slot);
        const name = formatItemName(listing.typeId);

        const isShulker = Array.isArray(listing.shulkerContents) && listing.shulkerContents.length > 0;

        let lore = [];
        if (state.mode === "mine") {
            lore = ["", `§7Fiyat: §e${listing.price} Para`, isShulker ? "§9[İçini Görüntülemek İçin Tıkla]" : "§c[İptal Etmek İçin Tıkla]"];
        } else {
            lore = [
                "",
                `§7Satıcı: §f${listing.ownerName}`,
                `§7Fiyat: §e${listing.price} Para`,
                listing.ownerId === player.id
                    ? "§8(Senin ilanın)"
                    : isShulker
                    ? "§9[İçini Görüntülemek İçin Tıkla]"
                    : "§a[Satın Almak İçin Tıkla]",
            ];
        }

        let enchanted = false;
        if (item) {
            const enchantComp = getEnchantComponent(item);
            if (enchantComp) {
                try {
                    const enchants = enchantComp.getEnchantments();
                    if (enchants && enchants.length > 0) {
                        enchanted = true;
                        lore.push("§r§d--- Büyüler ---");
                        for (const enc of enchants) {
                            lore.push(`§r§7- §d${formatItemName(enc.type.id)} §7v${enc.level}`);
                        }
                    }
                } catch (e) {
                    console.warn(`[sg:ah] Büyü okunamadı (${listing.typeId}): ${e}`);
                }
            }
        }

        const durabilityComp = getDurabilityComponent(item);
        const durability = durabilityComp
            ? Math.round(((durabilityComp.maxDurability - durabilityComp.damage) / durabilityComp.maxDurability) * 99)
            : 0;

        form.button(i, `§r§f${name}`, lore, listing.typeId, listing.amount, durability, enchanted);
    });

    if (state.page > 0) form.button(47, "§7« Önceki Sayfa", [], "minecraft:arrow");
    form.button(
        48,
        state.mode === "mine" ? "§6« Tüm İlanlar" : "§6Eşyalarım",
        [`§7(${myCount} Aktif İlan)`],
        "minecraft:chest"
    );
    form.button(
        49,
        "§bBilgi",
        [
            "§7Satış yapmak için:",
            "§e/sg:ah sell <fiyat>",
            "§7Dolu shulker satmak için, kutuya",
            "§7bakarken:",
            "§e/sg:ah sellshulker <fiyat>",
        ],
        "minecraft:written_book"
    );
    form.button(
        50,
        "§eArama Yap",
        state.filter ? [`§7Filtre: §f${state.filter}`] : ["§7Aramak için tıkla"],
        "minecraft:oak_sign"
    );
    if (state.filter) form.button(52, "§cFiltreyi Sıfırla", [], "minecraft:barrier");
    if (state.page < totalPages - 1) form.button(53, "§7Sonraki Sayfa »", [], "minecraft:arrow");

    const response = await form.show(player);
    if (response.canceled || response.selection === undefined) return;

    const selection = response.selection;
    if (selection >= 54) return;

    if (selection < ITEMS_PER_PAGE) {
        const listing = pageListings[selection];
        if (!listing) return;
        return handleListingClick(player, state, listing);
    }

    switch (selection) {
        case 47:
            if (state.page > 0) state.page--;
            return openMenu(player, state);
        case 48:
            state.mode = state.mode === "mine" ? "browse" : "mine";
            state.page = 0;
            return openMenu(player, state);
        case 49:
            return openMenu(player, state);
        case 50:
            return openSearchModal(player, state);
        case 52:
            state.filter = "";
            state.page = 0;
            return openMenu(player, state);
        case 53:
            if (state.page < totalPages - 1) state.page++;
            return openMenu(player, state);
        default:
            return;
    }
}

async function handleListingClick(player, state, listing) {
    const isShulker = Array.isArray(listing.shulkerContents) && listing.shulkerContents.length > 0;
    if (isShulker) return openShulkerPreview(player, state, listing);

    if (state.mode === "mine") return openCancelConfirm(player, state, listing);

    if (listing.ownerId === player.id) {
        player.sendMessage("§eKendi ilanlarını 'Eşyalarım' sekmesinden iptal edebilirsin.");
        return openMenu(player, state);
    }
    return openBuyConfirm(player, state, listing);
}

// Shulker kutusu ilanları için: /ah'daki gibi bir chest-ui açılır. İlk 27
// slotta kutunun içeriği (önizleme) gösterilir, alt satırda 30 numaralı
// slotta kırmızı cam "Geri Dön", 32 numaralı slotta ise duruma göre yeşil
// "Satın Al" ya da kırmızı "İlanı İptal Et" butonu bulunur.
const BACK_GLASS_SLOT = 30;
const ACTION_GLASS_SLOT = 32;

async function openShulkerPreview(player, state, listing) {
    const isOwner = listing.ownerId === player.id;
    const name = formatItemName(listing.typeId);

    const form = new ChestFormData("large").title(`§l§dShulker Önizleme §r§8- ${name}`);

    for (const entry of listing.shulkerContents) {
        if (entry.slot < 0 || entry.slot >= 27) continue;
        form.button(
            entry.slot,
            `§r§f${entry.name ? entry.name : formatItemName(entry.typeId)}`,
            [],
            entry.typeId,
            entry.amount
        );
    }

    for (let i = 27; i < 54; i++) {
        if (i === BACK_GLASS_SLOT || i === ACTION_GLASS_SLOT) continue;
        form.button(i, "§r", [], "minecraft:gray_stained_glass_pane");
    }

    form.button(BACK_GLASS_SLOT, "§c« Geri Dön", [], "minecraft:red_stained_glass_pane");

    if (state.mode === "mine" || isOwner) {
        form.button(
            ACTION_GLASS_SLOT,
            "§cİlanı İptal Et",
            ["§7Kutu envanterine geri döner."],
            "minecraft:red_stained_glass_pane"
        );
    } else {
        form.button(
            ACTION_GLASS_SLOT,
            "§aSatın Al",
            [`§7Fiyat: §e${listing.price} Para`],
            "minecraft:lime_stained_glass_pane"
        );
    }

    const response = await form.show(player);
    if (response.canceled || response.selection === undefined) return openMenu(player, state);

    if (response.selection === ACTION_GLASS_SLOT) {
        if (state.mode === "mine" || isOwner) return openCancelConfirm(player, state, listing);
        return openBuyConfirm(player, state, listing);
    }

    // 30 (geri dön) dahil diğer her tık ana menüye döner.
    return openMenu(player, state);
}

async function openBuyConfirm(player, state, listing) {
    const objective = getScoreboard();
    const balance = objective ? objective.getScore(player) ?? 0 : 0;
    const name = formatItemName(listing.typeId);

    const confirm = new MessageFormData()
        .title("Satın Alma Onayı")
        .body(`Eşya: §f${name} §7x${listing.amount}\nSatıcı: §f${listing.ownerName}\nFiyat: §e${listing.price} Para\nBakiyeniz: §e${balance} Para`)
        .button1("§aSatın Al")
        .button2("§cVazgeç");

    const r = await confirm.show(player);
    if (r.canceled || r.selection !== 0) return openMenu(player, state);

    const result = buyListing(player, listing.slot);
    if (!result.ok) player.sendMessage(`§c${result.reason}`);
    else player.sendMessage(`§a${name} x${listing.amount} başarıyla satın alındı.`);

    return openMenu(player, state);
}

async function openCancelConfirm(player, state, listing) {
    const name = formatItemName(listing.typeId);

    const confirm = new MessageFormData()
        .title("İlan İptal Onayı")
        .body(`Eşya: §f${name} §7x${listing.amount}\nFiyat: §e${listing.price} Para\n\nİlanı iptal ederseniz eşya envanterinize iade edilir.`)
        .button1("§cİlanı Kaldır")
        .button2("§7Vazgeç");

    const r = await confirm.show(player);
    if (r.canceled || r.selection !== 0) return openMenu(player, state);

    const result = cancelListing(player, listing.slot);
    if (!result.ok) player.sendMessage(`§c${result.reason}`);
    else player.sendMessage(`§aİlan iptal edildi. Eşya envanterinize aktarıldı.`);

    return openMenu(player, state);
}

async function openSearchModal(player, state) {
    const modal = new ModalFormData()
        .title("İhale Evi Arama")
        .textField("Aranacak eşya adı/ID'si:", "Örn: diamond", state.filter ?? "");

    const r = await modal.show(player);
    if (r.canceled) return openMenu(player, state);

    const input = String(r.formValues?.[0] ?? "").trim();
    state.filter = input;
    state.page = 0;
    state.mode = "browse";
    return openMenu(player, state);
}

export default function ah(customCommandRegistry) {
    customCommandRegistry.registerCommand(
        {
            name: "sg:ah",
            description: "İhale evini açar, eşya arar veya satar.",
            permissionLevel: CommandPermissionLevel.Any,
            cheatsRequired: false,
            optionalParameters: [
                { name: "arg1", type: CustomCommandParamType.String },
                { name: "arg2", type: CustomCommandParamType.String },
            ],
        },
        (origin, arg1, arg2) => {
            const player = origin.sourceEntity;
            if (!player || !(player instanceof Player)) {
                return { status: CustomCommandStatus.Failure, message: "Yalnızca oyuncular kullanabilir." };
            }

            system.run(() => {
                const firstArg = typeof arg1 === "string" ? arg1.trim() : "";
                const secondArg = typeof arg2 === "string" ? arg2.trim() : "";

                // SELL KOMUTU (/sg:ah sell <fiyat>)
                if (firstArg.toLowerCase() === "sell") {
                    const price = Number(secondArg);
                    if (!secondArg || isNaN(price) || price <= 0) {
                        player.sendMessage("§cLütfen geçerli bir fiyat girin! Örn: §e/sg:ah sell 1000");
                        return;
                    }

                    const objective = getScoreboard();
                    if (!objective) {
                        player.sendMessage('§c"Para" adında bir scoreboard objective bulunamadı.');
                        return;
                    }

                    const result = sellFromHand(player, Math.floor(price));
                    if (!result.ok) {
                        player.sendMessage(`§c${result.reason}`);
                        return;
                    }

                    player.sendMessage(`§aEşyanız §e${Math.floor(price)} Para§a karşılığında satışa çıkarıldı.`);
                    return;
                }

                // SHULKER SATIŞ KOMUTU (/sg:ah sellshulker <fiyat>) — bakılan,
                // yere konmuş dolu shulker kutusunu içeriğiyle birlikte satışa çıkarır.
                if (firstArg.toLowerCase() === "sellshulker") {
                    const price = Number(secondArg);
                    if (!secondArg || isNaN(price) || price <= 0) {
                        player.sendMessage("§cLütfen geçerli bir fiyat girin! Örn: §e/sg:ah sellshulker 5000");
                        return;
                    }

                    const objective = getScoreboard();
                    if (!objective) {
                        player.sendMessage('§c"Para" adında bir scoreboard objective bulunamadı.');
                        return;
                    }

                    const result = sellShulkerFromTarget(player, Math.floor(price));
                    if (!result.ok) {
                        player.sendMessage(`§c${result.reason}`);
                        return;
                    }

                    player.sendMessage(
                        `§aShulker kutusu, içindekilerle birlikte §e${Math.floor(price)} Para§a karşılığında satışa çıkarıldı.`
                    );
                    return;
                }

                // MENÜ VE ARAMA KOMUTU (/sg:ah veya /sg:ah <itemid>)
                const state = getState(player.id);
                state.mode = "browse";
                state.page = 0;
                state.filter = firstArg;
                openMenu(player, state);
            });

            return { status: CustomCommandStatus.Success };
        }
    );
}
