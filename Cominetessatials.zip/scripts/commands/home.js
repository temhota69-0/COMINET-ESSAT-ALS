import {
    CommandPermissionLevel,
    CustomCommandParamType,
    CustomCommandStatus,
    Player,
    system,
    world,
} from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";
import { startStillnessCountdown } from "./util/teleportCountdown.js";
import { syncPlayerHomes } from "../data/homesData.js";

const MAX_HOMES = 7;
const HOME_COUNTDOWN_SECONDS = 5;
const HOMES_PROPERTY_KEY = "sg:homes";

/** @param {import("@minecraft/server").Player} player */
function getHomes(player) {
    const raw = player.getDynamicProperty(HOMES_PROPERTY_KEY);
    if (typeof raw !== "string") return {};
    try {
        const parsed = JSON.parse(raw);
        return parsed && typeof parsed === "object" ? parsed : {};
    } catch {
        return {};
    }
}

function setHomes(player, homes) {
    player.setDynamicProperty(HOMES_PROPERTY_KEY, JSON.stringify(homes));
    syncPlayerHomes(player.name, homes);
}

// homeadi verilmezse 1'den 7'ye kadar boş olan ilk numarayı döner
function nextAutoName(homes) {
    for (let i = 1; i <= MAX_HOMES; i++) {
        const name = String(i);
        if (!homes[name]) return name;
    }
    return null;
}

function beginHomeTeleport(player, homeName, homeData) {
    player.sendMessage(`§eIşınlanmak için ${HOME_COUNTDOWN_SECONDS} saniye hareketsiz dur.`);

    startStillnessCountdown(
        player,
        HOME_COUNTDOWN_SECONDS,
        (secondsLeft) => `§e"${homeName}" evine ışınlanıyorsun... §a${secondsLeft}s`,
        () => {
            // onComplete
            const dimension = world.getDimension(homeData.dimensionId);
            player.teleport({ x: homeData.x, y: homeData.y, z: homeData.z }, { dimension });
            player.sendMessage(`§a"${homeName}" evine ışınlandın.`);
        },
        () => {
            // onCancel
            player.sendMessage("§cHareket ettiğin için ışınlanma iptal edildi.");
        }
    );
}

/**
 * sg:sethome / sg:home / sg:delhome komutlarını kaydeder.
 * @param {import("@minecraft/server").CustomCommandRegistry} customCommandRegistry
 */
export default function home(customCommandRegistry) {
    // /sg:sethome [homeadi]
    customCommandRegistry.registerCommand(
        {
            name: "sg:sethome",
            description: "Bulunduğun konumu ev olarak kaydet.",
            permissionLevel: CommandPermissionLevel.Any,
            cheatsRequired: false,
            optionalParameters: [{ name: "homeadi", type: CustomCommandParamType.String }],
        },
        (origin, homeName) => {
            const player = origin.sourceEntity;
            if (!player || !(player instanceof Player)) {
                return {
                    status: CustomCommandStatus.Failure,
                    message: "Bu komut sadece oyuncular tarafından kullanılabilir.",
                };
            }

            const homes = getHomes(player);
            const homeCount = Object.keys(homes).length;

            let name = homeName;
            if (!name) {
                name = nextAutoName(homes);
                if (!name) {
                    return { status: CustomCommandStatus.Failure, message: `En fazla ${MAX_HOMES} ev kaydedebilirsin.` };
                }
            } else if (!homes[name] && homeCount >= MAX_HOMES) {
                return { status: CustomCommandStatus.Failure, message: `En fazla ${MAX_HOMES} ev kaydedebilirsin.` };
            }

            const loc = player.location;
            const isOverwrite = Boolean(homes[name]);
            homes[name] = {
                x: loc.x,
                y: loc.y,
                z: loc.z,
                dimensionId: player.dimension.id,
            };

            system.run(() => {
                setHomes(player, homes);
                player.sendMessage(
                    isOverwrite ? `§a"${name}" adlı ev güncellendi.` : `§a"${name}" adlı ev kaydedildi.`
                );
            });

            return { status: CustomCommandStatus.Success };
        }
    );

    // /sg:delhome <homeadi>
    customCommandRegistry.registerCommand(
        {
            name: "sg:delhome",
            description: "Kayıtlı bir evi sil.",
            permissionLevel: CommandPermissionLevel.Any,
            cheatsRequired: false,
            mandatoryParameters: [{ name: "homeadi", type: CustomCommandParamType.String }],
        },
        (origin, homeName) => {
            const player = origin.sourceEntity;
            if (!player || !(player instanceof Player)) {
                return {
                    status: CustomCommandStatus.Failure,
                    message: "Bu komut sadece oyuncular tarafından kullanılabilir.",
                };
            }

            const homes = getHomes(player);
            if (!homes[homeName]) {
                return { status: CustomCommandStatus.Failure, message: `"${homeName}" adlı ev bulunamadı.` };
            }

            delete homes[homeName];

            system.run(() => {
                setHomes(player, homes);
                player.sendMessage(`§a"${homeName}" adlı ev silindi.`);
            });

            return { status: CustomCommandStatus.Success };
        }
    );

    // /sg:home [homeadi]
    customCommandRegistry.registerCommand(
        {
            name: "sg:home",
            description: "Kayıtlı bir eve ışınlan. İsim verilmezse menü açılır.",
            permissionLevel: CommandPermissionLevel.Any,
            cheatsRequired: false,
            optionalParameters: [{ name: "homeadi", type: CustomCommandParamType.String }],
        },
        (origin, homeName) => {
            const player = origin.sourceEntity;
            if (!player || !(player instanceof Player)) {
                return {
                    status: CustomCommandStatus.Failure,
                    message: "Bu komut sadece oyuncular tarafından kullanılabilir.",
                };
            }

            const homes = getHomes(player);
            const homeNames = Object.keys(homes);

            if (homeNames.length === 0) {
                return { status: CustomCommandStatus.Failure, message: "Hiç kayıtlı evin yok. Önce /sg:sethome kullan." };
            }

            // isim verildiyse direkt o eve ışınlanma sürecini başlat
            if (homeName) {
                if (!homes[homeName]) {
                    return { status: CustomCommandStatus.Failure, message: `"${homeName}" adlı ev bulunamadı.` };
                }

                system.run(() => beginHomeTeleport(player, homeName, homes[homeName]));
                return { status: CustomCommandStatus.Success };
            }

            // isim verilmediyse menü aç
            system.run(async () => {
                const form = new ActionFormData().title("Evlerim").body("Işınlanmak istediğin evi seç:");
                for (const name of homeNames) {
                    form.button(name);
                }

                const response = await form.show(player);
                if (response.canceled || response.selection === undefined) return;

                const selectedName = homeNames[response.selection];
                beginHomeTeleport(player, selectedName, homes[selectedName]);
            });

            return { status: CustomCommandStatus.Success };
        }
    );
}
