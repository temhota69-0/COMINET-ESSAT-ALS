import { system, world } from "@minecraft/server";
import { recordKill } from "./killLogData.js";

const COMBAT_WINDOW_MS = 15000;
const COMBO_MIN_DAMAGE = 0.2;
const CPS_WINDOW_MS = 1000;

const CPS_KICK_THRESHOLD = 30;
const CPS_WARN_THRESHOLD = 16;
const CPS_WARN_COOLDOWN_MS = 3000;
const CPS_WEAKNESS_DURATION_TICKS = 60; // 3 saniye

const comboMap = new Map();
const combatMap = new Map();
const damageLogMap = new Map();
const playerClickMap = new Map();
const cpsWarningMap = new Map();

export function getCombatInfo(playerId) {
    const now = Date.now();

    const combat = combatMap.get(playerId);
    let inCombat = false;
    let combatSecondsLeft = 0;
    if (combat) {
        if (now >= combat.until) {
            combatMap.delete(playerId);
            comboMap.set(playerId, 0);
        } else {
            inCombat = true;
            combatSecondsLeft = Math.max(0, Math.ceil((combat.until - now) / 1000));
        }
    }

    return {
        inCombat,
        combo: comboMap.get(playerId) || 0,
        cps: getCps(playerId),
        combatSecondsLeft,
    };
}

// cps burada, vuruşun bağlantı kurduğu anda (entityHitEntity) sayılıyor.
// entityHurt'a bağlı olmadığı için hasar 0 olsa/absorb edilse bile her vuruş sayılır.
function registerClick(playerId) {
    const now = Date.now();
    const clicks = (playerClickMap.get(playerId) || []).filter((t) => t > now - CPS_WINDOW_MS);
    clicks.push(now);
    playerClickMap.set(playerId, clicks);
    return clicks.length;
}

function getCps(playerId) {
    const clicks = playerClickMap.get(playerId);
    if (!clicks || clicks.length === 0) return 0;
    const now = Date.now();
    const validClicks = clicks.filter((t) => t > now - CPS_WINDOW_MS);
    playerClickMap.set(playerId, validClicks);
    return validClicks.length;
}

function handleCpsViolation(attacker, cps) {
    const now = Date.now();
    const lastWarn = cpsWarningMap.get(attacker.id) || 0;

    system.run(() => {
        if (!attacker.isValid) return;
        try {
            attacker.addEffect("weakness", CPS_WEAKNESS_DURATION_TICKS, {
                amplifier: 255,
                showParticles: false,
            });
        } catch (e) {
        }
    });

    if (now - lastWarn > CPS_WARN_COOLDOWN_MS) {
        cpsWarningMap.set(attacker.id, now);
        system.run(() => {
            if (!attacker.isValid) return;
            try {
                attacker.sendMessage(`§c[!] ${CPS_WARN_THRESHOLD} CPS limitini geçmeyiniz!`);
                attacker.playSound("random.fuse");
            } catch (e) {
            }
        });
    }
}

function registerCpsClick(attacker) {
    const cps = registerClick(attacker.id);

    if (cps >= CPS_KICK_THRESHOLD) {
        system.run(() => {
            if (!attacker.isValid) return;
            try {
                attacker.runCommand(`kick "${attacker.name}" §cCPS Limiti Aşırı Yüksek! (${cps} CPS)`);
            } catch (e) {
            }
        });
        return;
    }

    if (cps > CPS_WARN_THRESHOLD) {
        handleCpsViolation(attacker, cps);
    }
}

function registerHit(attacker, victim, damage, victimIsPlayer) {
    const now = Date.now();

    // Combat sadece oyuncu-oyuncu vuruşmasında (PvP) başlar.
    // Mob'a (canlıya) vurmak artık combat'ı tetiklemiyor.
    if (!victimIsPlayer) return;

    combatMap.set(attacker.id, { until: now + COMBAT_WINDOW_MS });
    combatMap.set(victim.id, { until: now + COMBAT_WINDOW_MS });

    if (damage >= COMBO_MIN_DAMAGE) {
        comboMap.set(attacker.id, (comboMap.get(attacker.id) || 0) + 1);
    }

    comboMap.set(victim.id, 0);

    const log = (damageLogMap.get(victim.id) || []).filter((e) => now - e.time <= COMBAT_WINDOW_MS);
    log.push({ attacker, time: now });
    damageLogMap.set(victim.id, log);
}

// --- Combat-log cezası -------------------------------------------------
// Bir oyuncu combat'tayken oyundan çıkarsa, dynamic property'e işaretlenir.
// afterEvents.playerLeave'de entity'ye artık erişilemediği için eşyalar hemen
// düşürülemez; bunun yerine oyuncu tekrar sunucuya girdiğinde (playerSpawn)
// eşyaları yere dökülür. Bu bayrak world dynamic property'de tutulduğu için
// sunucu yeniden başlasa bile kalıcıdır.
const COMBATLOG_FLAG_PREFIX = "sg:combatlog:";

function flagCombatLogout(playerId) {
    world.setDynamicProperty(COMBATLOG_FLAG_PREFIX + playerId, true);
}

function consumeCombatLogFlag(playerId) {
    const key = COMBATLOG_FLAG_PREFIX + playerId;
    const flagged = world.getDynamicProperty(key) === true;
    if (flagged) world.setDynamicProperty(key, undefined);
    return flagged;
}

function punishCombatLogger(player) {
    try {
        const inventory = player.getComponent("inventory")?.container;
        if (!inventory) return;

        for (let i = 0; i < inventory.size; i++) {
            const item = inventory.getItem(i);
            if (!item) continue;
            try {
                player.dimension.spawnItem(item, player.location);
            } catch {}
            inventory.setItem(i, undefined);
        }
    } catch {}
}

const KILLS_OBJ = "Kills";
const DEATHS_OBJ = "Deaths";
const ASSISTS_OBJ = "Assists";

function addScoreboardScore(objectiveName, participant, amount) {
    try {
        const obj = world.scoreboard.getObjective(objectiveName)
            ?? world.scoreboard.addObjective(objectiveName, objectiveName);
        const current = obj.getScore(participant) ?? 0;
        obj.setScore(participant, current + amount);
    } catch {}
}

// Combat'tayken çıkan oyuncu: kendisine death, son vurana kill, o combat'ta
// ona vurmuş diğer kişilere assist verir.
function creditCombatLogDeath(victim) {
    addScoreboardScore(DEATHS_OBJ, victim, 1);

    const { killer, assists } = resolveKillCredit(victim.id);
    if (!killer || !killer.isValid || killer.id === victim.id) return;

    addScoreboardScore(KILLS_OBJ, killer, 1);
    recordKill(killer, victim);

    for (const assist of assists) {
        if (!assist.isValid || assist.id === killer.id || assist.id === victim.id) continue;
        addScoreboardScore(ASSISTS_OBJ, assist, 1);
    }
}

export function resolveKillCredit(victimId) {
    const now = Date.now();
    const log = (damageLogMap.get(victimId) || []).filter((e) => now - e.time <= COMBAT_WINDOW_MS && e.attacker?.isValid);
    damageLogMap.delete(victimId);

    if (log.length === 0) {
        return { killer: null, assists: [] };
    }

    const killerEntry = log[log.length - 1];

    const assistMap = new Map();
    for (const entry of log) {
        if (entry.attacker.id === killerEntry.attacker.id) continue;
        assistMap.set(entry.attacker.id, entry.attacker);
    }

    return { killer: killerEntry.attacker, assists: [...assistMap.values()] };
}

export function clearDamageLog(victimId) {
    damageLogMap.delete(victimId);
}

export function clearPlayerCombat(playerId) {
    comboMap.delete(playerId);
    combatMap.delete(playerId);
    damageLogMap.delete(playerId);
    playerClickMap.delete(playerId);
    cpsWarningMap.delete(playerId);
}

export function initCombatTracking() {
    // cps burada sayılıyor: vuruş bağlantı kurduğu an, hasar şartı aranmadan.
    world.afterEvents.entityHitEntity.subscribe((event) => {
        const { hitEntity, damagingEntity } = event;
        if (!damagingEntity || damagingEntity.typeId !== "minecraft:player") return;
        if (!hitEntity || hitEntity.id === damagingEntity.id) return;

        registerCpsClick(damagingEntity);
    });

    world.afterEvents.entityHurt.subscribe((event) => {
        const { hurtEntity, damage, damageSource } = event;
        const attacker = damageSource?.damagingEntity;

        if (!attacker || attacker.typeId !== "minecraft:player") return;
        if (!hurtEntity || hurtEntity.id === attacker.id) return;

        registerHit(attacker, hurtEntity, damage, hurtEntity.typeId === "minecraft:player");
    });

    world.beforeEvents.playerLeave.subscribe((event) => {
        const player = event.player;
        const { inCombat } = getCombatInfo(player.id);
        if (inCombat) {
            flagCombatLogout(player.id);
            creditCombatLogDeath(player);
        }
    });

    world.afterEvents.playerLeave.subscribe((event) => {
        clearPlayerCombat(event.playerId);
    });

    // Combat'tayken çıkan oyuncu geri girdiğinde eşyaları yere dökülür.
    world.afterEvents.playerSpawn.subscribe((event) => {
        if (!event.initialSpawn) return;
        const player = event.player;
        system.run(() => {
            if (!player?.isValid) return;
            if (consumeCombatLogFlag(player.id)) {
                punishCombatLogger(player);
            }
        });
    });
}
