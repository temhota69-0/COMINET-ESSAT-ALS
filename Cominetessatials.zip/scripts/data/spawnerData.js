import { world } from "@minecraft/server";
import { SellPreset } from "./sellPreset.js";

const STORAGE_KEY = "sg:spawners";

// Genel /sg:sell sistemiyle aynı fiyat listesini kullanıyoruz, böylece
// "Hepsini Sat" butonu ekonomiyle tutarlı çalışır.
const SELL_PRICE_MAP = new Map(SellPreset.map((entry) => [entry.item, entry.price]));

/** Bir itemin Para karşılığı satış fiyatını döner (satılamıyorsa null). */
export function getSellPrice(itemTypeId) {
    const price = SELL_PRICE_MAP.get(itemTypeId);
    return price && price > 0 ? price : null;
}

// Her spawner'ın depolayabileceği item türü başına maksimum miktar.
// Doluysa yeni loot üretilmez, oyuncu gelip alana kadar bekler.
export const MAX_STORAGE_PER_ITEM = 1728; // 27 stack

/**
 * Spawner tipleri: shop'ta satılan her spawner burada tanımlanır.
 * Yeni bir mob eklemek için bu objeye yeni bir key eklemen yeterli,
 * başka hiçbir yeri değiştirmene gerek yok.
 *
 * loot: [{ item: typeId, min, max, weight }]
 * weight: göreceli olasılık ağırlığı (yüksek olan daha sık düşer)
 */
export const SPAWNER_TYPES = {
    pig: {
        name: "Domuz Spawner",
        price: 250,
        loot: [{ item: "minecraft:porkchop", min: 1, max: 2, weight: 100 }],
    },
    cow: {
        name: "İnek Spawner",
        price: 350,
        loot: [
            { item: "minecraft:beef", min: 1, max: 2, weight: 70 },
            { item: "minecraft:leather", min: 1, max: 1, weight: 30 },
        ],
    },
    zombie: {
        name: "Zombi Spawner",
        price: 400,
        loot: [
            { item: "minecraft:rotten_flesh", min: 1, max: 3, weight: 70 },
            { item: "minecraft:carrot", min: 1, max: 1, weight: 8 },
            { item: "minecraft:potato", min: 1, max: 1, weight: 8 },
            { item: "minecraft:iron_ingot", min: 1, max: 1, weight: 3 },
        ],
    },
    zombified_piglin: {
        name: "Zombileşmiş Piglin Spawner",
        price: 400,
        loot: [
            { item: "minecraft:gold_nugget", min: 1, max: 3, weight: 80 },
            { item: "minecraft:rotten_flesh", min: 1, max: 1, weight: 20 },
        ],
    },
    skeleton: {
        name: "İskelet Spawner",
        price: 500,
        loot: [
            { item: "minecraft:bone", min: 1, max: 2, weight: 60 },
            { item: "minecraft:arrow", min: 1, max: 2, weight: 60 },
            { item: "minecraft:bow", min: 1, max: 1, weight: 2 },
        ],
    },
    creeper: {
        name: "Creeper Spawner",
        price: 625,
        loot: [{ item: "minecraft:gunpowder", min: 1, max: 2, weight: 100 }],
    },
    spider: {
        name: "Örümcek Spawner",
        price: 750,
        loot: [
            { item: "minecraft:string", min: 1, max: 2, weight: 65 },
            { item: "minecraft:spider_eye", min: 1, max: 1, weight: 15 },
        ],
    },
    blaze: {
        name: "Blaze Spawner",
        price: 1000,
        loot: [
            { item: "minecraft:blaze_rod", min: 1, max: 1, weight: 40 },
            { item: "minecraft:blaze_powder", min: 1, max: 2, weight: 60 },
        ],
    },
    iron_golem: {
        name: "Demir Golem Spawner",
        price: 1500,
        loot: [
            { item: "minecraft:iron_ingot", min: 1, max: 3, weight: 80 },
            { item: "minecraft:poppy", min: 1, max: 1, weight: 20 },
        ],
    },
};

function getRaw() {
    const raw = world.getDynamicProperty(STORAGE_KEY);
    if (typeof raw !== "string") return {};
    try {
        const parsed = JSON.parse(raw);
        return parsed && typeof parsed === "object" ? parsed : {};
    } catch {
        return {};
    }
}

function saveRaw(data) {
    world.setDynamicProperty(STORAGE_KEY, JSON.stringify(data));
}

/** dimensionId + konum -> benzersiz kayıt anahtarı */
export function spawnerKey(dimensionId, location) {
    return `${dimensionId};${Math.floor(location.x)};${Math.floor(location.y)};${Math.floor(location.z)}`;
}

/** Yeni bir spawner'ı dünyaya kaydeder. */
export function registerSpawner(dimensionId, location, type) {
    const data = getRaw();
    const key = spawnerKey(dimensionId, location);
    data[key] = { type, storage: {} };
    saveRaw(data);
}

/** Bir spawner'ı kayıttan siler (kırıldığında). */
export function unregisterSpawner(dimensionId, location) {
    const data = getRaw();
    const key = spawnerKey(dimensionId, location);
    if (data[key]) {
        delete data[key];
        saveRaw(data);
        return true;
    }
    return false;
}

/** Konumdaki kayıtlı spawner verisini döner (yoksa null). */
export function getSpawner(dimensionId, location) {
    const data = getRaw();
    return data[spawnerKey(dimensionId, location)] ?? null;
}

/** Tüm kayıtlı spawner'ları [key, entry] listesi olarak döner. */
export function getAllSpawners() {
    return Object.entries(getRaw());
}

/** Bir spawner'ın depolanmış itemlerine ekleme yapar (kapasiteyi aşmaz). */
export function addLootToSpawner(dimensionId, location, itemTypeId, amount) {
    const data = getRaw();
    const key = spawnerKey(dimensionId, location);
    const entry = data[key];
    if (!entry) return;

    const current = entry.storage[itemTypeId] ?? 0;
    entry.storage[itemTypeId] = Math.min(MAX_STORAGE_PER_ITEM, current + amount);
    data[key] = entry;
    saveRaw(data);
}

/** Bir spawner'ın depolanmış tüm itemlerini boşaltır ve önceki içeriği döner. */
export function clearSpawnerStorage(dimensionId, location) {
    const data = getRaw();
    const key = spawnerKey(dimensionId, location);
    const entry = data[key];
    if (!entry) return {};

    const storage = entry.storage;
    entry.storage = {};
    data[key] = entry;
    saveRaw(data);
    return storage;
}

/**
 * Ağırlıklara göre tek bir loot seçip { item, amount } olarak döner (yoksa null).
 * Her "spawn tick"inde bir spawner için bir kez çağrılır.
 */
export function rollLoot(spawnerTypeKey) {
    const config = SPAWNER_TYPES[spawnerTypeKey];
    if (!config || config.loot.length === 0) return null;

    const totalWeight = config.loot.reduce((sum, d) => sum + d.weight, 0);
    let roll = Math.random() * totalWeight;

    for (const drop of config.loot) {
        roll -= drop.weight;
        if (roll <= 0) {
            const amount = drop.min + Math.floor(Math.random() * (drop.max - drop.min + 1));
            return amount > 0 ? { item: drop.item, amount } : null;
        }
    }
    return null;
}

/** Bir spawner'ın toplam depolama kapasitesine göre doluluk yüzdesini döner (0-100). */
export function getFillPercent(entry) {
    const config = SPAWNER_TYPES[entry.type];
    if (!config || config.loot.length === 0) return 0;

    const capacity = config.loot.length * MAX_STORAGE_PER_ITEM;
    const total = Object.values(entry.storage).reduce((sum, amount) => sum + amount, 0);
    return capacity > 0 ? Math.min(100, Math.round((total / capacity) * 100)) : 0;
}
