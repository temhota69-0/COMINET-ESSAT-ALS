// sg:ah — v.II (fix: enchant/lore/durability kaybı düzeltildi)
import { world, system, ItemStack, EnchantmentTypes } from "@minecraft/server";

const PAYOUT_DELAY_TICKS = 1200; // 1 dakika (20 tick/sn * 60sn)
const ENTITY_LOAD_RETRY_TICKS = 10; // entity/chunk henüz yüklenmemişse tekrar deneme aralığı
const ENTITY_LOAD_MAX_RETRIES = 20; // ~10 saniye boyunca dener, sonra yeni entity spawn eder

export const SCOREBOARD_NAME = "Para";
export const VIP_TAG = "dark+";
export const NORMAL_LIMIT = 20;
export const VIP_LIMIT = 40;

export const AH_ENTITY_TYPE = "sg:ah_storage";
export const AH_INVENTORY_SIZE = 1500;
export const AH_DIMENSION_ID = "overworld";
export const AH_LOCATION = { x: 0.5, y: -60, z: 0.5 };
export const AH_TICKINGAREA_NAME = "sg_ah_area";

const DP_ENTITY_ID = "sg:ah:entityId";
const DP_FREE = "sg:ah:free";
const DP_ACTIVE = "sg:ah:active";
const DP_OWNER_PREFIX = "sg:ah:owner:";
const DP_LISTING_PREFIX = "sg:ah:listing:";
const DP_PENDING_PREFIX = "sg:ah:pending:";

let cachedEntity = null;
let entitySpawnInProgress = false;

function getJSON(key, fallback) {
    const raw = world.getDynamicProperty(key);
    if (typeof raw !== "string") return fallback;
    try {
        return JSON.parse(raw) ?? fallback;
    } catch {
        return fallback;
    }
}

function setJSON(key, value) {
    world.setDynamicProperty(key, JSON.stringify(value));
}

function clearProperty(key) {
    world.setDynamicProperty(key, undefined);
}

function getFreeSlots() {
    return getJSON(DP_FREE, null);
}
function saveFreeSlots(arr) {
    saveFreeSlots_raw(arr);
}
function saveFreeSlots_raw(arr) {
    setJSON(DP_FREE, arr);
}
function getActiveSlots() {
    return getJSON(DP_ACTIVE, []);
}
function saveActiveSlots(arr) {
    setJSON(DP_ACTIVE, arr);
}
function getOwnerSlots(playerId) {
    return getJSON(DP_OWNER_PREFIX + playerId, []);
}
function saveOwnerSlots(playerId, arr) {
    if (!arr || arr.length === 0) clearProperty(DP_OWNER_PREFIX + playerId);
    else setJSON(DP_OWNER_PREFIX + playerId, arr);
}
export function getListingMeta(slot) {
    return getJSON(DP_LISTING_PREFIX + slot, null);
}
function saveListingMeta(slot, data) {
    setJSON(DP_LISTING_PREFIX + slot, data);
}
function deleteListingMeta(slot) {
    clearProperty(DP_LISTING_PREFIX + slot);
}

// Oyuncu offlineyken satılan eşyaların parası buraya birikir, giriş yapınca
// (1 dakikalık gecikmeyle) ödenir.
function getPendingEarnings(ownerId) {
    return getJSON(DP_PENDING_PREFIX + ownerId, 0);
}
function addPendingEarnings(ownerId, amount) {
    const current = getPendingEarnings(ownerId);
    setJSON(DP_PENDING_PREFIX + ownerId, current + amount);
}
function clearPendingEarnings(ownerId) {
    clearProperty(DP_PENDING_PREFIX + ownerId);
}

// ---------------------------------------------------------------------------
// ITEM SERIALIZATION
// Meta artık sadece typeId/amount değil, büyü/isim/lore/durability bilgisini
// de saklıyor. Container'a erişilemediği (chunk unload, entity henüz load
// olmamış vb.) nadir durumlarda fallback item bu veriden kusursuz kurulur.
// ---------------------------------------------------------------------------
function serializeItem(itemStack, shulkerContents) {
    const data = {
        typeId: itemStack.typeId,
        amount: itemStack.amount,
    };

    if (itemStack.nameTag) data.nameTag = itemStack.nameTag;
    if (shulkerContents && shulkerContents.length > 0) data.shulkerContents = shulkerContents;

    try {
        const lore = itemStack.getLore();
        if (lore && lore.length > 0) data.lore = lore;
    } catch {}

    try {
        const durability = itemStack.getComponent("durability");
        if (durability && durability.damage > 0) data.damage = durability.damage;
    } catch {}

    try {
        const enchantable = itemStack.getComponent("enchantable");
        if (enchantable) {
            const list = enchantable.getEnchantments();
            if (list && list.length > 0) {
                data.enchants = list.map((e) => ({ type: e.type.id, level: e.level }));
            }
        }
    } catch {}

    return data;
}

// ---------------------------------------------------------------------------
// SHULKER KUTUSU İÇERİK OKUMA
// Script API'de dolu bir shulker kutusu ITEM'ının içini elde tutarken
// doğrudan okumanın bir yolu yok (Bedrock bunu desteklemiyor). Tek güvenilir
// yöntem: kutunun bir BLOK olarak yerde durması (oyuncu onu koymuş olmalı).
// O yüzden "sellshulker" akışı, oyuncunun eldeki değil, BAKTIĞI/yerdeki dolu
// shulker bloğunu hedef alır:
//   1) block.getComponent("inventory") ile 27 slotu okuyup önizleme verisini
//      çıkarıyoruz (sadece /ah'daki önizleme ekranını doldurmak için).
//   2) Bloğu "destroy" modunda kırdırıyoruz (bu, normal blok kırma gibi
//      davranır ve içi dolu gerçek item'i olduğu gibi düşürür).
//   3) Düşen item entity'sini yakalayıp gerçek (ve tam) ItemStack'i alıyoruz.
// Böylece hem önizleme hem de satılan gerçek eşya, oyuncunun kutuya koyduğu
// eşyalarla birebir aynı olur.
// ---------------------------------------------------------------------------
export function isShulkerBox(typeId) {
    return typeId === "minecraft:shulker_box" || typeId.endsWith("_shulker_box");
}

export function captureShulkerFromBlock(block) {
    if (!block || !isShulkerBox(block.typeId)) return null;

    const inv = block.getComponent("minecraft:inventory") ?? block.getComponent("inventory");
    const container = inv?.container;
    if (!container) return null;

    const contents = [];
    for (let i = 0; i < container.size && i < 27; i++) {
        const it = container.getItem(i);
        if (!it) continue;
        contents.push({
            slot: i,
            typeId: it.typeId,
            amount: it.amount,
            name: it.nameTag || undefined,
        });
    }

    const loc = block.location;
    const dimension = block.dimension;
    const blockTypeId = block.typeId;

    try {
        dimension.runCommand(`setblock ${loc.x} ${loc.y} ${loc.z} air destroy`);
    } catch (e) {
        return null;
    }

    let capturedItem = null;
    try {
        const drops = dimension.getEntities({
            type: "minecraft:item",
            location: { x: loc.x + 0.5, y: loc.y + 0.5, z: loc.z + 0.5 },
            maxDistance: 3,
        });
        for (const drop of drops) {
            const itemComp = drop.getComponent("item");
            if (itemComp?.itemStack?.typeId === blockTypeId) {
                capturedItem = itemComp.itemStack.clone();
                try { drop.remove(); } catch {}
                break;
            }
        }
    } catch (e) {
        console.warn(`[sg:ah] Shulker yakalanamadı: ${e}`);
    }

    if (!capturedItem) return null;
    return { item: capturedItem, contents };
}

function buildItemFromData(data) {
    const item = new ItemStack(data.typeId, data.amount ?? 1);

    if (data.nameTag) {
        try { item.nameTag = data.nameTag; } catch {}
    }
    if (data.lore?.length) {
        try { item.setLore(data.lore); } catch {}
    }
    if (data.damage) {
        try {
            const durability = item.getComponent("durability");
            if (durability) durability.damage = data.damage;
        } catch {}
    }
    if (data.enchants?.length) {
        try {
            const enchantable = item.getComponent("enchantable");
            if (enchantable) {
                for (const e of data.enchants) {
                    try {
                        const type = EnchantmentTypes.get(e.type);
                        if (type) enchantable.addEnchantment({ type, level: e.level });
                    } catch {}
                }
            }
        } catch {}
    }

    return item;
}

// ---------------------------------------------------------------------------
// ENTITY / STORAGE
// ---------------------------------------------------------------------------

export function ensureStorageEntity() {
    const dimension = world.getDimension(AH_DIMENSION_ID);

    try {
        dimension.runCommand(
            `tickingarea add circle ${AH_LOCATION.x} ${AH_LOCATION.y} ${AH_LOCATION.z} 2 ${AH_TICKINGAREA_NAME}`
        );
    } catch {}

    if (cachedEntity && cachedEntity.isValid) {
        refreshInvisibility(cachedEntity);
        return cachedEntity;
    }

    const storedId = world.getDynamicProperty(DP_ENTITY_ID);
    if (typeof storedId === "string") {
        const existing = world.getEntity(storedId);
        if (existing?.isValid) {
            cachedEntity = existing;
            refreshInvisibility(existing);
            return existing;
        }
        // storedId var ama entity şu an bulunamadı: chunk henüz yüklenmemiş
        // olabilir. Burada YENİ bir entity spawn ETMİYORUZ — bu, eski
        // entity'nin (ve içindeki tüm eşyaların) referanssız kalıp "kaybolmuş"
        // gibi görünmesine yol açan asıl sebepti. Bunun yerine null dönüp
        // çağıranın (ensureStorageEntityAsync ile) tekrar denemesini bekliyoruz.
        return null;
    }

    // storedId hiç yoksa gerçekten ilk kurulumdur, güvenle yeni entity spawn edilir.
    if (entitySpawnInProgress) return null;
    entitySpawnInProgress = true;
    try {
        const entity = dimension.spawnEntity(AH_ENTITY_TYPE, AH_LOCATION);
        world.setDynamicProperty(DP_ENTITY_ID, entity.id);
        cachedEntity = entity;
        refreshInvisibility(entity);

        if (getFreeSlots() === null) {
            const free = [];
            for (let i = 0; i < AH_INVENTORY_SIZE; i++) free.push(i);
            saveFreeSlots(free);
            saveActiveSlots([]);
        }

        return entity;
    } finally {
        entitySpawnInProgress = false;
    }
}

/**
 * ensureStorageEntity()'nin async/retry'lı versiyonu. Server açılışında ya da
 * chunk henüz yüklenmemişken çağrılan yerlerde bunu kullan: birkaç tick
 * bekleyip tekrar dener, gerçekten bulunamazsa (storedId hiç yoksa) yeni
 * entity spawn eder. Böylece "chunk load gecikmesi yüzünden ikinci bir AH
 * entity'si spawn olması" riski ortadan kalkar.
 */
export function ensureStorageEntityAsync(callback, attempt = 0) {
    const entity = ensureStorageEntity();
    if (entity) {
        callback?.(entity);
        return;
    }

    const storedId = world.getDynamicProperty(DP_ENTITY_ID);
    if (typeof storedId === "string" && attempt < ENTITY_LOAD_MAX_RETRIES) {
        system.runTimeout(() => {
            ensureStorageEntityAsync(callback, attempt + 1);
        }, ENTITY_LOAD_RETRY_TICKS);
    } else {
        callback?.(null);
    }
}

export function refreshInvisibility(entity) {
    try {
        entity.addEffect("invisibility", 20000000, { showParticles: false, amplifier: 0 });
    } catch {}
}

export function getContainer() {
    const entity = ensureStorageEntity();
    if (!entity) return null;
    const inventory = entity.getComponent("inventory");
    return inventory ? inventory.container : null;
}

export function getScoreboard() {
    return world.scoreboard.getObjective(SCOREBOARD_NAME);
}

export function getListingLimit(player) {
    return player.hasTag(VIP_TAG) ? VIP_LIMIT : NORMAL_LIMIT;
}

export function createListing(player, itemStack, price, shulkerContents) {
    const container = getContainer();
    if (!container) {
        return { ok: false, reason: "İhale evi şu an hazır değil, birazdan tekrar dene." };
    }

    const ownerSlots = getOwnerSlots(player.id);
    const limit = getListingLimit(player);
    if (ownerSlots.length >= limit) {
        return { ok: false, reason: `En fazla ${limit} eşya listeleyebilirsin.` };
    }

    const free = getFreeSlots();
    if (!free || free.length === 0) {
        return { ok: false, reason: "İhale evi deposu dolu." };
    }

    const slot = free.pop();
    saveFreeSlots(free);

    container.setItem(slot, itemStack.clone());

    const active = getActiveSlots();
    active.push(slot);
    saveActiveSlots(active);

    ownerSlots.push(slot);
    saveOwnerSlots(player.id, ownerSlots);

    saveListingMeta(slot, {
        ownerId: player.id,
        ownerName: player.name,
        price: price,
        listedAt: Date.now(),
        ...serializeItem(itemStack, shulkerContents),
    });

    return { ok: true, slot };
}

function releaseSlot(slot) {
    const container = getContainer();
    if (container) {
        try { container.setItem(slot, undefined); } catch {}
    }
    deleteListingMeta(slot);

    const active = getActiveSlots().filter((s) => s !== slot);
    saveActiveSlots(active);

    const free = getFreeSlots() ?? [];
    if (!free.includes(slot)) {
        free.push(slot);
        saveFreeSlots(free);
    }
}

export function cancelListing(player, slot) {
    const meta = getListingMeta(slot);
    if (!meta) return { ok: false, reason: "Bu ilan bulunamadı." };
    if (meta.ownerId !== player.id) return { ok: false, reason: "Bu ilan sana ait değil." };

    const container = getContainer();
    let item = container ? container.getItem(slot) : null;

    // YEDEK MEKANİZMA: artık meta'da tam item verisi (enchant/isim/lore/
    // durability) olduğu için bu fallback kullanılsa bile hiçbir şey kaybolmaz.
    if (!item) {
        try {
            item = buildItemFromData(meta);
        } catch {
            return { ok: false, reason: "Eşya oluşturulamadı." };
        }
    }

    const inv = player.getComponent("inventory")?.container;
    if (!inv) return { ok: false, reason: "Envanterinize ulaşılamadı." };

    const leftover = inv.addItem(item.clone());
    if (leftover) {
        player.dimension.spawnItem(leftover, player.location);
    }

    const ownerSlots = getOwnerSlots(player.id).filter((s) => s !== slot);
    saveOwnerSlots(player.id, ownerSlots);

    releaseSlot(slot);
    return { ok: true, meta };
}

export function buyListing(player, slot) {
    const meta = getListingMeta(slot);
    if (!meta) return { ok: false, reason: "İlan artık bulunmuyor." };
    if (meta.ownerId === player.id) return { ok: false, reason: "Kendi eşyanı satın alamazsın." };

    const objective = getScoreboard();
    if (!objective) return { ok: false, reason: "Ekonomi sistemi devre dışı." };

    const balance = objective.getScore(player) ?? 0;
    if (balance < meta.price) return { ok: false, reason: "Yeterli paranız yok." };

    const container = getContainer();
    let item = container ? container.getItem(slot) : null;

    // YEDEK MEKANİZMA (artık büyü/isim/lore/durability korunuyor)
    if (!item) {
        try {
            item = buildItemFromData(meta);
        } catch {
            return { ok: false, reason: "Eşya yüklenemedi." };
        }
    }

    const inv = player.getComponent("inventory")?.container;
    if (!inv) return { ok: false, reason: "Envanterinize erişilemedi." };

    const leftover = inv.addItem(item.clone());
    if (leftover) {
        return { ok: false, reason: "Envanterinizde yeterli boş yer yok." };
    }

    objective.setScore(player, balance - meta.price);

    // Satıcı online ise doğrudan gerçek entity'sine yazıyoruz; offline ise
    // parayı biriktirip, giriş yaptıktan 1 dakika sonra ödüyoruz
    // (bkz. initAhPendingPayout).
    const onlineOwner = world.getAllPlayers().find((p) => p.id === meta.ownerId);
    if (onlineOwner) {
        const ownerBalance = objective.getScore(onlineOwner) ?? 0;
        objective.setScore(onlineOwner, ownerBalance + meta.price);
        try {
            onlineOwner.sendMessage(`§a"${meta.typeId.replace(/^.*:/, "")}" §7ilanın satıldı! §e+${meta.price} §7Para kazandın.`);
        } catch {}
    } else {
        addPendingEarnings(meta.ownerId, meta.price);
    }

    const ownerSlots = getOwnerSlots(meta.ownerId).filter((s) => s !== slot);
    saveOwnerSlots(meta.ownerId, ownerSlots);

    releaseSlot(slot);
    return { ok: true, meta };
}

export function listListings(filter = {}) {
    const active = getActiveSlots();
    const results = [];
    for (const slot of active) {
        const meta = getListingMeta(slot);
        if (!meta) continue;
        if (filter.ownerId && meta.ownerId !== filter.ownerId) continue;
        if (filter.query) {
            const q = filter.query.trim().toLowerCase();
            const rawId = meta.typeId.toLowerCase();
            const cleanId = rawId.replace(/^.*:/, "");
            if (!rawId.includes(q) && !cleanId.includes(q)) continue;
        }
        results.push({ slot, ...meta });
    }
    results.sort((a, b) => b.listedAt - a.listedAt);
    return results;
}

export function getListingItem(slot) {
    const container = getContainer();
    const item = container ? container.getItem(slot) : null;
    if (item) return item;

    // Fallback item — artık tam veriden (enchant dahil) kuruluyor.
    const meta = getListingMeta(slot);
    if (meta) {
        try { return buildItemFromData(meta); } catch {}
    }
    return undefined;
}

/**
 * Oyuncu offlineyken satılan ilanlardan biriken parayı, oyuncu tekrar girip
 * 1 dakika oyunda kaldıktan sonra gerçek bakiyesine ekler ve
 * "Toplam {gelir} kazandınız" mesajı gösterir.
 * main.js içinde bir kere çağrılmalı: initAhPendingPayout();
 */
export function initAhPendingPayout() {
    world.afterEvents.playerSpawn.subscribe((event) => {
        if (!event.initialSpawn) return;
        const player = event.player;
        const playerId = player.id;

        const pending = getPendingEarnings(playerId);
        if (!pending || pending <= 0) return;

        // Giriş yaptıktan 1 dakika (1200 tick) sonra öde.
        system.runTimeout(() => {
            // Oyuncu bu süre içinde tekrar offline olmuş olabilir; güncel
            // online listeden taze referansı alıyoruz.
            const freshPlayer = world.getAllPlayers().find((p) => p.id === playerId);
            if (!freshPlayer?.isValid) return;

            const currentPending = getPendingEarnings(playerId);
            if (!currentPending || currentPending <= 0) return;

            const objective = getScoreboard();
            if (!objective) return;

            const balance = objective.getScore(freshPlayer) ?? 0;
            objective.setScore(freshPlayer, balance + currentPending);
            clearPendingEarnings(playerId);

            try {
                freshPlayer.sendMessage(`§aİhale Evi: §7Offlineyken satılan eşyalardan §eToplam ${currentPending} Para §7kazandınız!`);
            } catch {}
        }, PAYOUT_DELAY_TICKS);
    });
}

world.afterEvents.entityDie.subscribe((event) => {
    const entity = event.deadEntity;
    if (entity.typeId !== AH_ENTITY_TYPE) return;

    const active = getActiveSlots();
    const container = entity.getComponent("inventory")?.container;

    for (const slot of active) {
        if (container) {
            const item = container.getItem(slot);
            if (item) {
                entity.dimension.spawnItem(item, entity.location);
            }
        }
        deleteListingMeta(slot);
    }

    saveActiveSlots([]);
    saveFreeSlots(null);
    clearProperty(DP_ENTITY_ID);
});