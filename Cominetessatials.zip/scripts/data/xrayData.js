import { world } from "@minecraft/server";

// Blok id -> gösterim anahtarı. Varyantlar (deepslate, lit vb.) tek anahtara toplanıyor.
const ORE_DISPLAY = {
    "minecraft:diamond_ore": "diamond",
    "minecraft:deepslate_diamond_ore": "diamond",
    "minecraft:iron_ore": "iron",
    "minecraft:deepslate_iron_ore": "iron",
    "minecraft:gold_ore": "gold",
    "minecraft:deepslate_gold_ore": "gold",
    "minecraft:nether_gold_ore": "gold",
    "minecraft:coal_ore": "coal",
    "minecraft:deepslate_coal_ore": "coal",
    "minecraft:copper_ore": "copper",
    "minecraft:deepslate_copper_ore": "copper",
    "minecraft:redstone_ore": "redstone",
    "minecraft:deepslate_redstone_ore": "redstone",
    "minecraft:lit_redstone_ore": "redstone",
    "minecraft:lit_deepslate_redstone_ore": "redstone",
    "minecraft:lapis_ore": "lapis",
    "minecraft:deepslate_lapis_ore": "lapis",
    "minecraft:emerald_ore": "emerald",
    "minecraft:deepslate_emerald_ore": "emerald",
    "minecraft:ancient_debris": "ancient_debris",
    "minecraft:nether_quartz_ore": "quartz",
};

const ORE_LABELS = {
    diamond: "Elmas",
    iron: "Demir",
    gold: "Altın",
    coal: "Kömür",
    copper: "Bakır",
    redstone: "Redstone",
    lapis: "Lapis",
    emerald: "Zümrüt",
    ancient_debris: "Ancient Debris",
    quartz: "Kuvars",
};

// Şüphe puanı sadece "enclosed" (etrafı tamamen kapalı, yani oyuncunun kendi
// açtığı bir tünelden görünmeden bulunmuş) kırımlarda veriliyor. Normal oyuncu
// cevhere ulaşmak için önce bir yanını açar, x-ray kullanan direkt kırar.
const SUSPICION_POINTS = {
    diamond: 10,
    ancient_debris: 10,
    emerald: 10,
    gold: 5,
    redstone: 5,
    lapis: 5,
};

const MINED_KEY_PREFIX = "sg:mined:";
const WARNINGS_KEY = "sg:xray:warnings";
const MAX_WARNINGS = 60;

function getJSON(key, fallback) {
    const raw = world.getDynamicProperty(key);
    if (typeof raw !== "string") return fallback;
    try {
        const parsed = JSON.parse(raw);
        return parsed ?? fallback;
    } catch {
        return fallback;
    }
}

function setJSON(key, value) {
    world.setDynamicProperty(key, JSON.stringify(value));
}

export function classifyOre(typeId) {
    return ORE_DISPLAY[typeId] ?? null;
}

export function getSuspicionPoints(oreKey) {
    return SUSPICION_POINTS[oreKey] ?? 0;
}

export function getOreLabel(oreKey) {
    return ORE_LABELS[oreKey] ?? oreKey;
}

export function getAllOreKeys() {
    return Object.keys(ORE_LABELS);
}

export function recordMinedOre(playerId, oreKey) {
    const key = MINED_KEY_PREFIX + playerId;
    const stats = getJSON(key, {});
    stats[oreKey] = (stats[oreKey] || 0) + 1;
    setJSON(key, stats);
}

export function getMinedStats(playerId) {
    return getJSON(MINED_KEY_PREFIX + playerId, {});
}

export function addWarning(entry) {
    const list = getJSON(WARNINGS_KEY, []);
    list.push(entry);
    while (list.length > MAX_WARNINGS) list.shift();
    setJSON(WARNINGS_KEY, list);
}

export function getWarnings() {
    return getJSON(WARNINGS_KEY, []);
}

export function getWarningsForPlayer(playerId) {
    return getWarnings().filter((w) => w.playerId === playerId);
}

export function deleteWarning(warningId) {
    const list = getWarnings().filter((w) => w.id !== warningId);
    setJSON(WARNINGS_KEY, list);
}
