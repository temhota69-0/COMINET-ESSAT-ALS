const HUD_SETTINGS_KEY = "sg:hudSettings";

const DEFAULT_SETTINGS = {
    cps: true,
    combo: true,
    location: true,
    scoreboard: true,
};

/**
 * Oyuncunun action bar HUD ayarlarını döner (CPS / Combo / Konum / Scoreboard).
 * Ayar hiç kaydedilmemişse varsayılan olarak hepsi açık kabul edilir.
 * @param {import("@minecraft/server").Player} player
 */
export function getHudSettings(player) {
    try {
        const raw = player.getDynamicProperty(HUD_SETTINGS_KEY);
        if (typeof raw !== "string") return { ...DEFAULT_SETTINGS };
        const parsed = JSON.parse(raw);
        return {
            cps: typeof parsed.cps === "boolean" ? parsed.cps : DEFAULT_SETTINGS.cps,
            combo: typeof parsed.combo === "boolean" ? parsed.combo : DEFAULT_SETTINGS.combo,
            location: typeof parsed.location === "boolean" ? parsed.location : DEFAULT_SETTINGS.location,
            scoreboard: typeof parsed.scoreboard === "boolean" ? parsed.scoreboard : DEFAULT_SETTINGS.scoreboard,
        };
    } catch (e) {
        return { ...DEFAULT_SETTINGS };
    }
}

/**
 * Oyuncunun action bar HUD ayarlarını kaydeder.
 * @param {import("@minecraft/server").Player} player
 * @param {{cps: boolean, combo: boolean, location: boolean, scoreboard: boolean}} settings
 */
export function setHudSettings(player, settings) {
    const merged = {
        cps: !!settings.cps,
        combo: !!settings.combo,
        location: !!settings.location,
        scoreboard: !!settings.scoreboard,
    };
    try {
        player.setDynamicProperty(HUD_SETTINGS_KEY, JSON.stringify(merged));
    } catch (e) {
    }
    return merged;
}
