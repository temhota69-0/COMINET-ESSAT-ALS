import { world } from "@minecraft/server";
import { shopCatalog } from "./shopConfig.js";

/**
 * Eşya kalıcı verisi (fiyat, isim, item id vs.) artık shopConfig.js dosyasından
 * geliyor. Burada sadece SINIRLI stok sayan eşyaler için "kaç tane kaldı" bilgisi
 * world dynamic property üzerinde tutulur, böylece satış yapıldıkça dosyayı
 * değiştirmeye gerek kalmaz.
 */

const STOCK_KEY_PREFIX = "sg:stock:";

function stockKey(categoryId, index) {
    return `${STOCK_KEY_PREFIX}${categoryId}:${index}`;
}

function getBaseItem(categoryId, index) {
    const category = shopCatalog.find((c) => c.id === categoryId);
    return category?.items[index] ?? null;
}

/** @returns {number} bir eşya için o an geçerli stok (kaydedilmiş varsa o, yoksa config'teki başlangıç değeri) */
function resolveStock(categoryId, index, baseItem) {
    if (baseItem.stock === -1) return -1;
    const saved = world.getDynamicProperty(stockKey(categoryId, index));
    return typeof saved === "number" ? saved : baseItem.stock;
}

/** shopConfig.js'teki kategorileri, güncel stok bilgisiyle birleştirerek döner. */
export function getCategories() {
    return shopCatalog.map((category) => ({
        id: category.id,
        name: category.name,
        icon: category.icon,
        currency: category.currency ?? "Para",
        items: category.items.map((item, index) => ({
            ...item,
            stock: resolveStock(category.id, index, item),
        })),
    }));
}

/** @returns {ShopCategory | null} */
export function findCategory(categoryId) {
    return getCategories().find((c) => c.id === categoryId) ?? null;
}

/** Satın alma sonrası stok düşürür. Sınırsız (-1) ise her zaman true döner. @returns {boolean} */
export function decreaseStock(categoryId, index, amount) {
    const baseItem = getBaseItem(categoryId, index);
    if (!baseItem) return false;
    if (baseItem.stock === -1) return true;

    const current = resolveStock(categoryId, index, baseItem);
    if (current < amount) return false;

    world.setDynamicProperty(stockKey(categoryId, index), current - amount);
    return true;
}

/** Bir eşyanın stoğunu belirli bir değere sabitler (opshop panelinden kullanılır). @returns {boolean} */
export function setStock(categoryId, index, amount) {
    const baseItem = getBaseItem(categoryId, index);
    if (!baseItem) return false;
    if (baseItem.stock === -1) return false; // sınırsız eşyanın stoğu değiştirilemez

    world.setDynamicProperty(stockKey(categoryId, index), Math.max(0, Math.floor(amount)));
    return true;
}

/** Bir eşyanın stoğunu shopConfig.js'teki başlangıç değerine döndürür. */
export function resetStock(categoryId, index) {
    world.setDynamicProperty(stockKey(categoryId, index), undefined);
}

/** Tüm eşyaların stoğunu shopConfig.js'teki başlangıç değerlerine döndürür. */
export function resetAllStock() {
    shopCatalog.forEach((category) => {
        category.items.forEach((item, index) => {
            if (item.stock !== -1) world.setDynamicProperty(stockKey(category.id, index), undefined);
        });
    });
}
