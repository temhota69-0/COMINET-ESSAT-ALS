import { world } from "@minecraft/server";

const REGISTRY_KEY = "sg:homesRegistry";

function getRegistry() {
    const raw = world.getDynamicProperty(REGISTRY_KEY);
    if (typeof raw !== "string") return {};
    try {
        const parsed = JSON.parse(raw);
        return parsed && typeof parsed === "object" ? parsed : {};
    } catch {
        return {};
    }
}

function saveRegistry(registry) {
    world.setDynamicProperty(REGISTRY_KEY, JSON.stringify(registry));
}

/**
 * Bir oyuncunun ev verilerini world seviyesinde de günceller.
 * Böylece oyuncu çevrimdışıyken de evleri /sg:homesee ile görülebilir.
 * home.js içindeki setHomes her çağrıldığında bu fonksiyon da çağrılmalı.
 * @param {string} playerName
 * @param {Record<string, any>} homes
 */
export function syncPlayerHomes(playerName, homes) {
    const registry = getRegistry();
    if (!homes || Object.keys(homes).length === 0) {
        delete registry[playerName];
    } else {
        registry[playerName] = homes;
    }
    saveRegistry(registry);
}

/** Kayıtlı tüm oyuncuların ev sayısını döner: { isim: sayi } */
export function getAllHomeCounts() {
    const registry = getRegistry();
    const result = {};
    for (const [name, homes] of Object.entries(registry)) {
        result[name] = Object.keys(homes ?? {}).length;
    }
    return result;
}

/** Belirli bir oyuncunun (çevrimdışı dahil) ev verilerini döner. */
export function getPlayerHomesByName(playerName) {
    const registry = getRegistry();
    return registry[playerName] ?? {};
}
