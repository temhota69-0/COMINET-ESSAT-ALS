import { world } from "@minecraft/server";

const REGISTRY_KEY = "sg:playerRegistry";

function getRegistry() {
    const raw = world.getDynamicProperty(REGISTRY_KEY);
    if (typeof raw !== "string") return {};
    try {
        const parsed = JSON.parse(raw);
        return parsed && typeof parsed === "object" ? parsed : {};
    } catch {
        return {};
    }
}

function saveRegistry(registry) {
    world.setDynamicProperty(REGISTRY_KEY, JSON.stringify(registry));
}

/**
 * Oyuncu her girişte adı -> id eşleşmesini world dynamic property'sine kaydeder.
 * Böylece offline oyuncular da isimden bulunabilir (ileride /msg, ban, opshop vb. için).
 * main.js içinde bir kere çağrılmalı.
 */
export function initPlayerRegistry() {
    world.afterEvents.playerSpawn.subscribe((event) => {
        if (!event.initialSpawn) return;
        const registry = getRegistry();
        registry[event.player.name] = event.player.id;
        saveRegistry(registry);
    });
}

/** Kayıtlı (online + offline) tüm oyuncu isimlerini döner. */
export function getKnownPlayerNames() {
    return Object.keys(getRegistry());
}

/** İsme göre kayıtlı oyuncu id'sini döner, yoksa null. */
export function findPlayerIdByName(name) {
    const registry = getRegistry();
    const match = Object.keys(registry).find((n) => n.toLowerCase() === name.toLowerCase());
    return match ? registry[match] : null;
}
