import { world } from "@minecraft/server";

const KEY = "sg:killlog";
const MAX_ENTRIES = 300;

function getJSON(key, fallback) {
    const raw = world.getDynamicProperty(key);
    if (typeof raw !== "string") return fallback;
    try {
        const parsed = JSON.parse(raw);
        return parsed ?? fallback;
    } catch {
        return fallback;
    }
}

function setJSON(key, value) {
    world.setDynamicProperty(key, JSON.stringify(value));
}

/**
 * killerId_victimId -> { killerName, victimName, count }
 * Aynı çift tekrar öldürünce sayaç artar.
 */
export function recordKill(killer, victim) {
    if (!killer || !victim || killer.id === victim.id) return;

    const log = getJSON(KEY, {});
    const pairKey = `${killer.id}_${victim.id}`;
    const entry = log[pairKey] || { killerName: killer.name, victimName: victim.name, count: 0 };
    entry.count++;
    entry.killerName = killer.name;
    entry.victimName = victim.name;
    log[pairKey] = entry;

    const keys = Object.keys(log);
    if (keys.length > MAX_ENTRIES) {
        delete log[keys[0]];
    }

    setJSON(KEY, log);
}

/** Bir oyuncunun kimi kaç öldürdüğü + kimin onu kaç öldürdüğü. */
export function getKillLogForPlayer(playerId) {
    const log = getJSON(KEY, {});
    const kills = [];
    const deaths = [];

    for (const [pairKey, entry] of Object.entries(log)) {
        const [killerId, victimId] = pairKey.split("_");
        if (killerId === playerId) kills.push({ name: entry.victimName, count: entry.count });
        if (victimId === playerId) deaths.push({ name: entry.killerName, count: entry.count });
    }

    kills.sort((a, b) => b.count - a.count);
    deaths.sort((a, b) => b.count - a.count);
    return { kills, deaths };
}
