import { SPAWNER_TYPES } from "./spawnerData.js";

export const shopCatalog = [
    {
        id: "spawner",
        name: "§dSpawner",
        icon: "minecraft:mob_spawner",
        // Bu kategorideki eşyalar Para yerine DarkCoin scoreboard'u ile satın alınır.
        currency: "DarkCoin",
        items: Object.entries(SPAWNER_TYPES).map(([type, config]) => ({
            spawnerType: type,
            item: "minecraft:mob_spawner",
            name: config.name,
            price: config.price,
            stock: -1,
        })),
    },

    {
        id: "end",
        name: "§5End",
        icon: "minecraft:end_stone",
        items: [
            { item: "minecraft:ender_chest", name: "Ender Sandığı", price: 2500, stock: -1 },
            { item: "minecraft:ender_pearl", name: "Ender İncisi", price: 75, stock: -1 },
            { item: "minecraft:end_stone", name: "End Taşı", price: 128, stock: -1 },
            { item: "minecraft:dragon_breath", name: "Ejderha Nefesi", price: 1000, stock: -1 },
            { item: "minecraft:end_rod", name: "End Çubuğu", price: 100, stock: -1 },
            { item: "minecraft:chorus_fruit", name: "Korus Meyvesi", price: 108, stock: -1 },
            { item: "minecraft:popped_chorus_fruit", name: "Patlamış Korus Meyvesi", price: 24, stock: -1 },
            { item: "minecraft:shulker_shell", name: "Shulker Kabuğu", price: 350, stock: -1 },
            { item: "minecraft:shulker_box", name: "Shulker Kutusu", price: 800, stock: -1 },
        ],
    },

    {
        id: "nether",
        name: "§cNether",
        icon: "minecraft:netherrack",
        items: [
            { item: "minecraft:blaze_rod", name: "Blaze Çubuğu", price: 150, stock: -1 },
            { item: "minecraft:nether_wart", name: "Nether Wart", price: 96, stock: -1 },
            { item: "minecraft:glowstone_dust", name: "Glowstone Tozu", price: 15, stock: -1 },
            { item: "minecraft:magma_cream", name: "Magma Kremi", price: 96, stock: -1 },
            { item: "minecraft:ghast_tear", name: "Ghast Gözyaşı", price: 350, stock: -1 },
            { item: "minecraft:quartz", name: "Nether Kuvarsı", price: 30, stock: -1 },
            { item: "minecraft:soul_sand", name: "Ruh Kumu", price: 50, stock: -1 },
            { item: "minecraft:magma_block", name: "Magma Bloğu", price: 35, stock: -1 },
            { item: "minecraft:crying_obsidian", name: "Ağlayan Obsidyen", price: 150, stock: -1 },
        ],
    },

    {
        id: "gear",
        name: "§bGear",
        icon: "minecraft:diamond_sword",
        items: [
            { item: "minecraft:obsidian", name: "Obsidyen", price: 100, stock: -1 },
            { item: "minecraft:end_crystal", name: "End Kristali", price: 350, stock: -1 },
            { item: "minecraft:respawn_anchor", name: "Yeniden Doğma Çapası", price: 1000, stock: -1 },
            { item: "minecraft:glowstone", name: "Glowstone", price: 100, stock: -1 },
            { item: "minecraft:totem_of_undying", name: "Ölümsüzlük Totemi", price: 1500, stock: -1 },
            { item: "minecraft:ender_pearl", name: "Ender İncisi", price: 75, stock: -1 },
            { item: "minecraft:golden_apple", name: "Altın Elma", price: 250, stock: -1 },
            { item: "minecraft:experience_bottle", name: "Büyü Tecrübesi Şişesi", price: 100, stock: -1 },
            { item: "minecraft:arrow", name: "Yavaşlık Düşüşü Oku", price: 500, stock: -1 },
        ],
    },

    {
        id: "food",
        name: "§6Yiyecek",
        icon: "minecraft:golden_carrot",
        items: [
            { item: "minecraft:potato", name: "Patates", price: 96, stock: -1 },
            { item: "minecraft:sweet_berries", name: "Tatlı Meyveler", price: 50, stock: -1 },
            { item: "minecraft:melon_slice", name: "Karpuz Dilimi", price: 36, stock: -1 },
            { item: "minecraft:carrot", name: "Havuç", price: 96, stock: -1 },
            { item: "minecraft:apple", name: "Elma", price: 25, stock: -1 },
            { item: "minecraft:cooked_chicken", name: "Pişmiş Tavuk", price: 48, stock: -1 },
            { item: "minecraft:cooked_beef", name: "Biftek", price: 35, stock: -1 },
            { item: "minecraft:golden_carrot", name: "Altın Havuç", price: 120, stock: -1 },
            { item: "minecraft:golden_apple", name: "Altın Elma", price: 250, stock: -1 },
        ],
    },
];