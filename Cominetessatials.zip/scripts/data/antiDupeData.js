import { world } from "@minecraft/server";

const WARNINGS_KEY = "sg:dupe:warnings";
const MAX_WARNINGS = 60;

function getJSON(key, fallback) {
    const raw = world.getDynamicProperty(key);
    if (typeof raw !== "string") return fallback;
    try {
        const parsed = JSON.parse(raw);
        return parsed ?? fallback;
    } catch {
        return fallback;
    }
}

function setJSON(key, value) {
    world.setDynamicProperty(key, JSON.stringify(value));
}

/**
 * entry şekli: { id, playerId, playerName, time, reason, withWhat?, location? }
 * location: { x, y, z, dimensionId }
 */
export function addDupeWarning(entry) {
    const list = getJSON(WARNINGS_KEY, []);
    list.push(entry);
    while (list.length > MAX_WARNINGS) list.shift();
    setJSON(WARNINGS_KEY, list);
}

export function getDupeWarnings() {
    return getJSON(WARNINGS_KEY, []);
}

export function getDupeWarningsForPlayer(playerId) {
    return getDupeWarnings().filter((w) => w.playerId === playerId);
}

export function deleteDupeWarning(warningId) {
    const list = getDupeWarnings().filter((w) => w.id !== warningId);
    setJSON(WARNINGS_KEY, list);
}
