import { world } from "@minecraft/server";

// Konum logları world dynamic property'lerinde oyuncu+gün bazlı ayrı
// parçalar halinde tutulur: "sg:poslog:<playerId>:<dayKey>" ->
// [[saniye, x, y, z, boyut, 5dkKontrolSayısı], ...]
//
// Davranış:
// - Oyuncu son kaydedilen 32x32'lik alanın içindeyse yeni satır AÇILMAZ,
//   o satırın "5 dk'lık kontrol sayısı" +1 artırılır (dakika hesabı yapılmaz,
//   sadece sayaç artar; log şişmez, ekstra işlem yükü olmaz, lag riski azalır).
// - Oyuncu alandan çıkarsa o satırın sayması DURUR ve yeni konum için
//   yeni bir satır açılır.
// - Oyuncu çıktığı alana bir sonraki kontrolde (yani en fazla 5 dk içinde)
//   geri dönerse, yeni satır açmak yerine ESKİ satırdan kaldığı yerden
//   devam edilir ve "girişSayısı" 1 artırılır (örn. (2) = 2. kez orada).
// - 5 dk'dan uzun süre alandan uzak kalınırsa o alanın devam hakkı düşer,
//   dönüşte tamamen yeni bir satır açılır.
//
// Bu "devam hakkı" oyuncu başına bellekte (RAM) tutulur; sadece bir sonraki
// kontrol turunda geçerlidir, bu yüzden ekstra depolama/tarama maliyeti yoktur.

const PREFIX = "sg:poslog:";
const DAY_MS = 24 * 60 * 60 * 1000;
const KEEP_DAYS = 7;
const ZONE_HALF = 16; // 32x32 alan -> merkeze göre yarı genişlik

const DIM_SHORT = {
    "minecraft:overworld": "o",
    "minecraft:nether": "n",
    "minecraft:the_end": "e",
};
const DIM_LONG = { o: "minecraft:overworld", n: "minecraft:nether", e: "minecraft:the_end" };

// playerId -> { active: Zone|null, paused: Zone|null }
// Zone = { x, z, dim, dayKey, index }
const zoneState = new Map();

function dayKeyFor(ts) {
    return Math.floor(ts / DAY_MS);
}

function propKey(playerId, dayKey) {
    return `${PREFIX}${playerId}:${dayKey}`;
}

function getJSON(key, fallback) {
    const raw = world.getDynamicProperty(key);
    if (typeof raw !== "string") return fallback;
    try {
        const parsed = JSON.parse(raw);
        return parsed ?? fallback;
    } catch {
        return fallback;
    }
}

function setJSON(key, value) {
    world.setDynamicProperty(key, JSON.stringify(value));
}

function inZone(zone, x, z, dim, dayKey) {
    return (
        !!zone &&
        zone.dayKey === dayKey &&
        zone.dim === dim &&
        Math.abs(x - zone.x) <= ZONE_HALF &&
        Math.abs(z - zone.z) <= ZONE_HALF
    );
}

function updateZoneEntry(playerId, zone) {
    const key = propKey(playerId, zone.dayKey);
    const list = getJSON(key, []);
    const entry = list[zone.index];
    if (!entry) return false;
    entry[5] = (entry[5] ?? 0) + 1;
    setJSON(key, list);
    return true;
}

function pushNewEntry(playerId, dayKey, sec, x, y, z, dim) {
    const key = propKey(playerId, dayKey);
    const list = getJSON(key, []);
    const index = list.length;
    list.push([sec, x, y, z, dim, 0]);
    setJSON(key, list);
    return index;
}

/**
 * Bir oyuncunun anlık konumunu işler. Aynı 32x32 alanda kalıyorsa süreyi
 * artırır; alandan çıkıp 5 dk içinde geri dönerse kaldığı yerden devam
 * ettirir; aksi halde yeni bir kayıt satırı açar.
 */
export function recordPosition(player) {
    const now = Date.now();
    const dayKey = dayKeyFor(now);
    const secOfDay = Math.floor((now - dayKey * DAY_MS) / 1000);
    const dim = DIM_SHORT[player.dimension.id] ?? "o";
    const x = Math.round(player.location.x);
    const y = Math.round(player.location.y);
    const z = Math.round(player.location.z);
    const id = player.id;

    const st = zoneState.get(id) ?? { active: null, paused: null };

    if (inZone(st.active, x, z, dim, dayKey)) {
        // Hâlâ aynı alanda: 5 dk'lık kontrol sayısı 1 artıyor.
        updateZoneEntry(id, st.active);
        st.paused = null;
    } else if (inZone(st.paused, x, z, dim, dayKey)) {
        // Az önce çıktığı alana geri döndü (en fazla 5 dk içinde): kaldığı yerden devam.
        updateZoneEntry(id, st.paused);
        st.active = st.paused;
        st.paused = null;
    } else {
        // Yeni bir alan: eski aktif alanın devam hakkı bir sonraki kontrole kadar saklanır,
        // sonra düşer (yani en fazla 5 dk grace period).
        st.paused = st.active;
        const index = pushNewEntry(id, dayKey, secOfDay, x, y, z, dim);
        st.active = { x, z, dim, dayKey, index };
    }

    zoneState.set(id, st);
}

/** Oyuncu ayrıldığında bellekteki alan takibini temizler (opsiyonel bakım). */
export function clearZoneState(playerId) {
    zoneState.delete(playerId);
}

/** 7 günden eski log parçalarını siler. */
export function cleanupOldLogs() {
    const cutoff = dayKeyFor(Date.now()) - KEEP_DAYS;
    const ids = world.getDynamicPropertyIds();
    for (const id of ids) {
        if (!id.startsWith(PREFIX)) continue;
        const dk = Number(id.slice(PREFIX.length).split(":")[1]);
        if (Number.isFinite(dk) && dk < cutoff) {
            world.setDynamicProperty(id, undefined);
        }
    }
}

/** Loglanmış tüm oyuncu id'lerini döner. */
export function getLoggedPlayerIds() {
    const ids = world.getDynamicPropertyIds();
    const set = new Set();
    for (const id of ids) {
        if (!id.startsWith(PREFIX)) continue;
        const rest = id.slice(PREFIX.length);
        set.add(rest.slice(0, rest.lastIndexOf(":")));
    }
    return [...set];
}

/** Bir oyuncu için loglanmış gün anahtarlarını (yeniden eskiye) döner. */
export function getLoggedDays(playerId) {
    const prefix = `${PREFIX}${playerId}:`;
    return world
        .getDynamicPropertyIds()
        .filter((id) => id.startsWith(prefix))
        .map((id) => Number(id.slice(prefix.length)))
        .filter((n) => Number.isFinite(n))
        .sort((a, b) => b - a);
}

export function getDayEntries(playerId, dayKey) {
    return getJSON(propKey(playerId, dayKey), []);
}

export function dayKeyToDateLabel(dk) {
    return new Date(dk * DAY_MS).toISOString().slice(0, 10);
}

export function secOfDayToLabel(sec) {
    const h = String(Math.floor(sec / 3600)).padStart(2, "0");
    const m = String(Math.floor((sec % 3600) / 60)).padStart(2, "0");
    return `${h}:${m}`;
}

export function dimShortToId(short) {
    return DIM_LONG[short] ?? "minecraft:overworld";
}

const DIM_LABEL = { o: "Overworld", n: "Nether", e: "End" };

/** Boyut kısaltmasını okunabilir isme çevirir (o -> Overworld vb.). */
export function dimShortToLabel(short) {
    return DIM_LABEL[short] ?? "Overworld";
}

/** 5 dk'lık kontrolden kaç kez geçtiğini düz sayı olarak döner. */
export function formatStayDuration(count) {
    return String(count ?? 0);
}
