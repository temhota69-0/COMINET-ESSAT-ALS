import { world, system } from "@minecraft/server";

// 20 tick = 1 saniye -> 30 saniye = 600 tick
const DESPAWN_TICKS = 600;

export function initItemDespawn() {
    world.afterEvents.entitySpawn.subscribe((event) => {
        const entity = event.entity;
        if (!entity || entity.typeId !== "minecraft:item") return;

        system.runTimeout(() => {
            try {
                // Oyuncu bu süre içinde item'ı aldıysa entity zaten geçersiz olur
                if (entity.isValid) {
                    entity.remove();
                }
            } catch (e) {
                // Entity zaten silinmiş/alınmış olabilir, göz ardı et
            }
        }, DESPAWN_TICKS);
    });
}
