import { system, world } from "@minecraft/server";
import { classifyOre, getSuspicionPoints, recordMinedOre, addWarning } from "../data/xrayData.js";

const POINT_WINDOW_MS = 60 * 60 * 1000; // 1 saat
const POINT_THRESHOLD = 70;             // 1 saat içinde 70 puan -> uyarı
const ALERT_COOLDOWN_MS = 10 * 60 * 1000;

// playerId -> [{ time, points }] (sadece son 1 saatlik pencere tutulur)
const pointLogMap = new Map();
const lastAlertMap = new Map();

function addPoints(player, points) {
    const now = Date.now();
    const log = (pointLogMap.get(player.id) || []).filter((e) => now - e.time <= POINT_WINDOW_MS);
    log.push({ time: now, points });
    pointLogMap.set(player.id, log);

    const total = log.reduce((sum, e) => sum + e.points, 0);
    if (total >= POINT_THRESHOLD) {
        triggerWarning(player, total);
        pointLogMap.delete(player.id); // eşik geçilince pencere sıfırlanır, tekrar birikmesi gerekir
    }
}

function triggerWarning(player, points) {
    const now = Date.now();
    const warning = {
        id: `${player.id}_${now}`,
        playerId: player.id,
        playerName: player.name,
        time: now,
        points,
    };
    addWarning(warning);

    const last = lastAlertMap.get(player.id) || 0;
    if (now - last < ALERT_COOLDOWN_MS) return;
    lastAlertMap.set(player.id, now);

    const msg = `§c[AntiXray] §f${player.name} §81 saat içinde §e${points} §8şüphe puanına ulaştı! (§bkırılan tüm bloklar için /sg:xraylog'a bak)`;

    let notified = false;
    for (const staff of world.getAllPlayers()) {
        if (staff.hasTag("admin") || staff.hasTag("op") || staff.hasTag("mod")) {
            try {
                staff.sendMessage(msg);
                notified = true;
            } catch {}
        }
    }
    // Online admin yoksa bile uyarı yukarıda addWarning() ile kalıcı olarak kaydedildi;
    // admin sonra /sg:xraylog menüsündeki "Xray Uyarıları" listesinden görebilir.
    console.warn(msg + (notified ? "" : " (online admin yok, sadece log'a kaydedildi)"));
}

export function initAntiXray() {
    world.afterEvents.playerBreakBlock.subscribe((event) => {
        const { player, block, brokenBlockPermutation } = event;
        if (!player || player.hasTag("admin")) return;

        const typeId = brokenBlockPermutation?.type?.id ?? block.typeId;
        const oreKey = classifyOre(typeId);
        if (!oreKey) return;

        // Herkesin ne kadar maden kırdığı her zaman kaydedilir (istatistik için).
        recordMinedOre(player.id, oreKey);

        // Şüphe puanı artık kırdığı HER değerli madende artıyor (enclosed şartı kaldırıldı).
        const suspicionPoints = getSuspicionPoints(oreKey);
        if (suspicionPoints > 0) {
            addPoints(player, suspicionPoints);
        }
    });

    world.afterEvents.playerLeave.subscribe((event) => {
        pointLogMap.delete(event.playerId);
        lastAlertMap.delete(event.playerId);
    });

    // Bellekte tutulan puan kayıtlarını periyodik temizle (1 saatten eskiyi at).
    system.runInterval(() => {
        const now = Date.now();
        for (const [id, log] of pointLogMap) {
            const fresh = log.filter((e) => now - e.time <= POINT_WINDOW_MS);
            if (fresh.length === 0) pointLogMap.delete(id);
            else pointLogMap.set(id, fresh);
        }
    }, 20 * 60 * 10); // 10 dakikada bir
}
