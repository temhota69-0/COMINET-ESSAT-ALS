import { world } from "@minecraft/server";

// Ayarlar
const WINDOW_MS = 3000;      // 3 saniyelik pencere
const MAX_MESSAGES = 2;      // Bu pencere içinde izin verilen maksimum mesaj sayısı

// playerId -> { timestamps: number[], lastMessage: string }
const playerChatData = new Map();

/**
 * 3 saniye içinde 2'den fazla mesaj atan ya da art arda aynı mesajı
 * tekrar eden oyuncuların mesajlarını iptal edip uyarı gönderir.
 */
export function initAntiSpam() {
    world.beforeEvents.chatSend.subscribe((event) => {
        const sender = event.sender;
        if (!sender) return;

        const now = Date.now();
        const message = event.message;

        let data = playerChatData.get(sender.id);
        if (!data) {
            data = { timestamps: [], lastMessage: null };
            playerChatData.set(sender.id, data);
        }

        // Aynı mesajın art arda tekrarı
        if (data.lastMessage !== null && message === data.lastMessage) {
            event.cancel = true;
            sender.sendMessage("§c§lSPAM ATMA");
            return;
        }

        // 3 saniyelik pencere içindeki mesaj sayısı
        data.timestamps = data.timestamps.filter((t) => now - t < WINDOW_MS);
        data.timestamps.push(now);

        if (data.timestamps.length > MAX_MESSAGES) {
            event.cancel = true;
            sender.sendMessage("§c§lSPAM ATMA");
            return;
        }

        // Mesaj izinliyse son mesaj olarak kaydet
        data.lastMessage = message;
    });

    // Oyuncu ayrıldığında verisini temizle (bellek sızıntısını önlemek için)
    world.afterEvents.playerLeave.subscribe((event) => {
        playerChatData.delete(event.playerId);
    });
}
