import { system, world, GameMode } from "@minecraft/server";

// ---------------------------------------------------------------------
// Ayarlar
// ---------------------------------------------------------------------
const CHECK_INTERVAL_TICKS = 10; // 0.5 saniyede bir kontrol
const HOVER_Y_TOLERANCE = 0.06; // bu kadar Y farkı "düşmüyor / havada asılı" sayılır
const SUPPORT_CHECK_RADIUS = 2; // ayağın altında kaç blok derine kadar "destek" aranır
const VIOLATIONS_TO_WARN_STAFF = 3;
const VIOLATIONS_TO_PUNISH = 6;
const VIOLATION_DECAY_MS = 15_000; // bu süre boyunca ihlal yapılmazsa sayaç azalır
const TELEPORT_GRACE_TICKS = 40; // oyuncu ışınlandıktan sonra bu kadar tick kontrol edilmez
const STAFF_ALERT_COOLDOWN_MS = 30_000;

// playerId -> { violations, lastY, lastCheckedTick, lastViolationMs, graceUntilTick }
const trackers = new Map();
const lastStaffAlertMap = new Map();

function isExempt(player) {
    try {
        if (player.getGameMode() !== GameMode.survival && player.getGameMode() !== GameMode.adventure) return true;
    } catch {
        return true;
    }

    if (player.hasTag("admin") || player.hasTag("flyok")) return true;
    if (player.isFlying) return true;
    if (player.isGliding) return true;
    if (player.isClimbing) return true;
    if (player.isSwimming || player.isInWater) return true;
    if (player.isSleeping) return true;

    try {
        if (player.getComponent("riding")) return true;
    } catch {}

    try {
        if (player.getEffect("levitation") || player.getEffect("slow_falling")) return true;
    } catch {}

    return false;
}

// Oyuncunun ayaklarının altında gerçekten sunucu tarafında var olan bir blok var mı?
// (Hileli client'ın sadece kendi ekranında gösterdiği "hayalet blok" burada görünmez.)
// Sıvı bloklar da "destek" sayılır: kayık/tekne ile suda durmak yanlış pozitif üretmesin.
function hasRealSupportBelow(player) {
    const { dimension, location } = player;
    const baseX = Math.floor(location.x);
    const baseZ = Math.floor(location.z);
    const baseY = Math.floor(location.y - 0.05);

    for (let dy = 0; dy < SUPPORT_CHECK_RADIUS; dy++) {
        try {
            const block = dimension.getBlock({ x: baseX, y: baseY - dy, z: baseZ });
            if (block && !block.isAir) return true;
        } catch {}
    }
    return false;
}

function resetTracker(id) {
    trackers.delete(id);
}

function markTeleportGrace(player) {
    const entry = trackers.get(player.id) ?? { violations: 0, lastY: player.location.y, lastViolationMs: 0 };
    entry.graceUntilTick = system.currentTick + TELEPORT_GRACE_TICKS;
    trackers.set(player.id, entry);
}

function alertStaff(player, violations) {
    const now = Date.now();
    const last = lastStaffAlertMap.get(player.id) ?? 0;
    if (now - last < STAFF_ALERT_COOLDOWN_MS) return;
    lastStaffAlertMap.set(player.id, now);

    const msg = `§c[AntiFly] §f${player.name} §8şüpheli şekilde havada asılı duruyor (§e${violations} §8ihlal). Muhtemel hayalet-blok hilesi.`;
    for (const staff of world.getAllPlayers()) {
        if (staff.hasTag("admin") || staff.hasTag("op") || staff.hasTag("mod")) {
            try {
                staff.sendMessage(msg);
            } catch {}
        }
    }
}

function punish(player) {
    try {
        player.sendMessage("§c[AntiFly] §fHileli uçuş tespit edildi, aşağı çekiliyorsun!");
    } catch {}

    // applyKnockback sürümler arası imza değiştirdiği için buna güvenmek yerine
    // doğrudan güvenli, öngörülebilir bir aşağı ışınlama kullanıyoruz.
    try {
        const loc = player.location;
        player.teleport({ x: loc.x, y: loc.y - 1.5, z: loc.z }, { dimension: player.dimension });
    } catch {}
}

function checkPlayer(player) {
    const id = player.id;

    if (isExempt(player)) {
        resetTracker(id);
        return;
    }

    const entry = trackers.get(id) ?? {
        violations: 0,
        lastY: player.location.y,
        lastViolationMs: 0,
        graceUntilTick: 0,
    };

    if (entry.graceUntilTick && system.currentTick < entry.graceUntilTick) {
        entry.lastY = player.location.y;
        trackers.set(id, entry);
        return;
    }

    // Sunucu tarafında gerçek bir destek varsa (gerçek blok) ya da oyuncu server'a göre
    // yerdeyse, tamamen normal - sıfırla.
    if (player.isOnGround || hasRealSupportBelow(player)) {
        entry.violations = Math.max(0, entry.violations - 1);
        entry.lastY = player.location.y;
        trackers.set(id, entry);
        return;
    }

    const deltaY = entry.lastY - player.location.y; // pozitifse düşüyor demektir
    entry.lastY = player.location.y;

    // Havada, altında gerçek blok yok, ama düşmüyor da (ya da yükseliyor) -> şüpheli.
    if (deltaY <= HOVER_Y_TOLERANCE) {
        entry.violations += 1;
        entry.lastViolationMs = Date.now();
    } else {
        // Gerçekten serbest düşüşteyse (gravity çalışıyorsa) ihlali azalt.
        entry.violations = Math.max(0, entry.violations - 1);
    }

    if (entry.violations >= VIOLATIONS_TO_WARN_STAFF) {
        alertStaff(player, entry.violations);
    }

    if (entry.violations >= VIOLATIONS_TO_PUNISH) {
        punish(player);
        entry.violations = Math.floor(VIOLATIONS_TO_PUNISH / 2);
    }

    trackers.set(id, entry);
}

export function initAntiFly() {
    system.runInterval(() => {
        for (const player of world.getAllPlayers()) {
            try {
                checkPlayer(player);
            } catch {}
        }

        // Uzun süredir ihlal etmeyen oyuncuların sayaçlarını yavaşça temizle.
        const now = Date.now();
        for (const [id, entry] of trackers) {
            if (entry.violations > 0 && now - entry.lastViolationMs > VIOLATION_DECAY_MS) {
                entry.violations = Math.max(0, entry.violations - 1);
                entry.lastViolationMs = now;
            }
        }
    }, CHECK_INTERVAL_TICKS);

    // Işınlanma sonrası (home/tpa/rtp/spawn vb.) yanlış pozitifleri önlemek için kısa bir muafiyet.
    world.afterEvents?.playerSpawn?.subscribe((event) => {
        if (event.initialSpawn) return;
        markTeleportGrace(event.player);
    });

    world.afterEvents?.entityDie?.subscribe((event) => {
        if (event.deadEntity?.typeId === "minecraft:player") {
            resetTracker(event.deadEntity.id);
        }
    });

    world.afterEvents?.playerLeave?.subscribe((event) => {
        trackers.delete(event.playerId);
        lastStaffAlertMap.delete(event.playerId);
    });
}
