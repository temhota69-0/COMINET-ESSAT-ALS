import { world, system } from "@minecraft/server";

// Piston her çalıştığında (extend/retract) etrafında r=2-3 içindeki
// End Rod, Paratoner (lightning rod) ve tüm çit kapısı (fence gate) türlerini siler.
// Sadece pistonActivate event'inde tetiklenir; tick döngüsü / sürekli tarama YOKTUR,
// bu yüzden lag yapmaz.

const RADIUS = 5; // r=2-3 aralığını kapsar (kürevi mesafe kontrolüyle)

function isRiskyBlock(typeId) {
    if (typeId === "minecraft:end_rod") return true;
    if (typeId === "minecraft:lightning_rod") return true;
    if (typeId.includes("fence_gate")) return true; // oak, cherry, bamboo, mangrove vs. tüm çit kapıları
    return false;
}

function friendlyName(typeId) {
    return typeId.replace("minecraft:", "").replace(/_/g, " ");
}

export function initPistonRiskyCleaner() {
    world.afterEvents.pistonActivate.subscribe((event) => {
        const pistonBlock = event.block;
        if (!pistonBlock) return;

        const dimension = event.dimension ?? pistonBlock.dimension;
        const center = pistonBlock.location;

        // Blok mutasyonlarını event handler'ın hemen dışında, bir sonraki tick'te
        // güvenli şekilde çalıştırmak için system.run kullanıyoruz.
        system.run(() => {
            const removed = [];

            for (let dx = -RADIUS; dx <= RADIUS; dx++) {
                for (let dy = -RADIUS; dy <= RADIUS; dy++) {
                    for (let dz = -RADIUS; dz <= RADIUS; dz++) {
                        if (dx === 0 && dy === 0 && dz === 0) continue;

                        const distSq = dx * dx + dy * dy + dz * dz;
                        if (distSq > RADIUS * RADIUS) continue; // küresel sınır (r<=3)

                        const pos = { x: center.x + dx, y: center.y + dy, z: center.z + dz };

                        let block;
                        try {
                            block = dimension.getBlock(pos);
                        } catch {
                            continue;
                        }
                        if (!block) continue;

                        const typeId = block.typeId;
                        if (!isRiskyBlock(typeId)) continue;

                        try {
                            block.setType("minecraft:air");
                            removed.push(friendlyName(typeId));
                        } catch {}
                    }
                }
            }

            if (removed.length === 0) return;

            try {
                const counts = removed.reduce((acc, name) => {
                    acc[name] = (acc[name] ?? 0) + 1;
                    return acc;
                }, {});
                const summary = Object.entries(counts)
                    .map(([name, count]) => `${name} x${count}`)
                    .join(", ");
                world.sendMessage(
                    `§c[Dupe Koruması] Piston aktif oldu, yakınındaki riskli bloklar silindi: §e${summary}`
                );
            } catch {}
        });
    });
}
