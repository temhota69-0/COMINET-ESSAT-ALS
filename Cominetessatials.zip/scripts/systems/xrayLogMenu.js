import { system, world } from "@minecraft/server";
import { ActionFormData, ModalFormData, MessageFormData } from "@minecraft/server-ui";
import { getKnownPlayerNames, findPlayerIdByName } from "../data/playerRegistry.js";
import {
    getAllOreKeys,
    getOreLabel,
    getMinedStats,
    getWarnings,
    getWarningsForPlayer,
    deleteWarning,
} from "../data/xrayData.js";
import { getKillLogForPlayer } from "../data/killLogData.js";
import { getDupeWarnings, getDupeWarningsForPlayer, deleteDupeWarning } from "../data/antiDupeData.js";

function normalize(str) {
    return str
        .replace(/İ/g, "i")
        .replace(/I/g, "ı")
        .toLowerCase();
}

function formatTime(ms) {
    const d = new Date(ms);
    const pad = (n) => String(n).padStart(2, "0");
    return `${pad(d.getDate())}.${pad(d.getMonth() + 1)}.${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

function findOnlinePlayerByName(name) {
    return world.getAllPlayers().find((p) => p.name === name) ?? null;
}

// ---------------------------------------------------------------------
// Ana menü
// ---------------------------------------------------------------------
export function openXrayLogMainMenu(admin) {
    const warningCount = getWarnings().length;
    const dupeCount = getDupeWarnings().length;

    const form = new ActionFormData()
        .title("§lXray Log")
        .body("§8Bir kategori seç:")
        .button("§aÇevrimiçi Oyuncular")
        .button("§8Çevrimdışı Oyuncular")
        .button("§eOyuncu Ara")
        .button(`§cXray Uyarıları §8(${warningCount})`)
        .button(`§6AntiDupe Uyarıları §8(${dupeCount})`);

    form.show(admin).then((res) => {
        if (res.canceled || !admin.isValid) return;
        switch (res.selection) {
            case 0:
                openPlayerListMenu(admin, "online");
                break;
            case 1:
                openPlayerListMenu(admin, "offline");
                break;
            case 2:
                openSearchMenu(admin);
                break;
            case 3:
                openWarningsListMenu(admin);
                break;
            case 4:
                openDupeWarningsListMenu(admin);
                break;
        }
    });
}

// ---------------------------------------------------------------------
// Çevrimiçi / Çevrimdışı oyuncu listesi
// ---------------------------------------------------------------------
function openPlayerListMenu(admin, mode) {
    const onlineNames = new Set(world.getAllPlayers().map((p) => p.name));
    const known = getKnownPlayerNames();

    const names = (mode === "online" ? [...onlineNames] : known.filter((n) => !onlineNames.has(n))).sort((a, b) =>
        a.localeCompare(b)
    );

    const form = new ActionFormData()
        .title(mode === "online" ? "§lÇevrimiçi Oyuncular" : "§lÇevrimdışı Oyuncular")
        .body(names.length === 0 ? "§8Kayıtlı oyuncu yok." : "§8Detay için bir oyuncu seç:");

    for (const name of names) form.button(name);
    form.button("§8<< Geri");

    form.show(admin).then((res) => {
        if (res.canceled || !admin.isValid) return;
        if (res.selection === names.length) {
            openXrayLogMainMenu(admin);
            return;
        }
        const name = names[res.selection];
        openPlayerStatsMenu(admin, name);
    });
}

// ---------------------------------------------------------------------
// Oyuncu arama
// ---------------------------------------------------------------------
function openSearchMenu(admin) {
    const form = new ModalFormData().title("§lOyuncu Ara").textField("İsim (parça yeter)", "örn: ömer");

    form.show(admin).then((res) => {
        if (res.canceled || !admin.isValid) return;
        const query = normalize((res.formValues?.[0] ?? "").trim());
        if (!query) {
            openXrayLogMainMenu(admin);
            return;
        }

        const known = getKnownPlayerNames();
        const matches = known
            .map((name) => ({ name, idx: normalize(name).indexOf(query) }))
            .filter((e) => e.idx !== -1)
            .sort((a, b) => a.idx - b.idx || a.name.localeCompare(b.name))
            .slice(0, 25);

        openSearchResultsMenu(admin, query, matches.map((m) => m.name));
    });
}

function openSearchResultsMenu(admin, query, names) {
    const form = new ActionFormData()
        .title(`§lArama: "${query}"`)
        .body(names.length === 0 ? "§8Eşleşen oyuncu bulunamadı." : "§8Sonuçlar:");

    for (const name of names) form.button(name);
    form.button("§8<< Geri");

    form.show(admin).then((res) => {
        if (res.canceled || !admin.isValid) return;
        if (res.selection === names.length) {
            openXrayLogMainMenu(admin);
            return;
        }
        openPlayerStatsMenu(admin, names[res.selection]);
    });
}

// ---------------------------------------------------------------------
// Oyuncu detay: maden istatistiği + combat log + xray uyarı durumu
// ---------------------------------------------------------------------
function openPlayerStatsMenu(admin, targetName) {
    const onlinePlayer = findOnlinePlayerByName(targetName);
    const targetId = onlinePlayer ? onlinePlayer.id : findPlayerIdByName(targetName);

    if (!targetId) {
        new MessageFormData()
            .title("§lHata")
            .body(`§c"${targetName}" için kayıtlı veri bulunamadı.`)
            .button1("Tamam")
            .button2("Geri")
            .show(admin)
            .then((res) => {
                if (!res.canceled && res.selection === 1 && admin.isValid) openXrayLogMainMenu(admin);
            });
        return;
    }

    const mined = getMinedStats(targetId);
    const minedLines = getAllOreKeys()
        .map((key) => ({ label: getOreLabel(key), count: mined[key] || 0 }))
        .filter((e) => e.count > 0)
        .map((e) => `§8${e.label}§8(§f${e.count}§8)`);

    const { kills, deaths } = getKillLogForPlayer(targetId);
    const killLines = kills.slice(0, 8).map((k) => `§a${k.name}§8: §f${k.count}`);
    const deathLines = deaths.slice(0, 8).map((d) => `§c${d.name}§8: §f${d.count}`);

    const warnings = getWarningsForPlayer(targetId);

    const lines = [];
    lines.push(`§l${targetName} §r§8(${onlinePlayer ? "§açevrimiçi" : "§8çevrimdışı"}§8)`);
    lines.push("");
    lines.push("§e-- Kırılan Madenler --");
    lines.push(...(minedLines.length ? minedLines : ["§8Kayıt yok."]));
    lines.push("");
    lines.push("§e-- Öldürdükleri --");
    lines.push(...(killLines.length ? killLines : ["§8Kayıt yok."]));
    lines.push("");
    lines.push("§e-- Onu Öldürenler --");
    lines.push(...(deathLines.length ? deathLines : ["§8Kayıt yok."]));
    lines.push("");
    lines.push(
        warnings.length > 0
            ? `§cXray Uyarısı Var: §f${warnings.length} adet`
            : "§aXray Uyarısı Yok"
    );

    const form = new ActionFormData().title("§lOyuncu Detayı").body(lines.join("\n"));
    if (warnings.length > 0) form.button("§cUyarılarını Gör");
    form.button("§8<< Geri");

    form.show(admin).then((res) => {
        if (res.canceled || !admin.isValid) return;
        const hasWarnBtn = warnings.length > 0;
        if (hasWarnBtn && res.selection === 0) {
            openWarningsListMenu(admin, targetId);
            return;
        }
        openXrayLogMainMenu(admin);
    });
}

// ---------------------------------------------------------------------
// Xray uyarıları listesi (opsiyonel: tek oyuncuya filtrelenmiş)
// ---------------------------------------------------------------------
function openWarningsListMenu(admin, filterPlayerId) {
    const all = getWarnings().sort((a, b) => b.time - a.time);
    const list = filterPlayerId ? all.filter((w) => w.playerId === filterPlayerId) : all;

    const form = new ActionFormData()
        .title("§lXray Uyarıları")
        .body(list.length === 0 ? "§8Uyarı yok." : "§8Detay için bir uyarı seç:");

    for (const w of list) {
        form.button(`§c${w.playerName} §8- ${formatTime(w.time)} §8(§e${w.points} puan§8)`);
    }
    form.button("§8<< Geri");

    form.show(admin).then((res) => {
        if (res.canceled || !admin.isValid) return;
        if (res.selection === list.length) {
            openXrayLogMainMenu(admin);
            return;
        }
        openWarningDetailMenu(admin, list[res.selection], filterPlayerId);
    });
}

function openWarningDetailMenu(admin, warning, filterPlayerId) {
    const body = [
        `§lOyuncu: §r§f${warning.playerName}`,
        `§8Tarih: §f${formatTime(warning.time)}`,
        `§8Şüphe Puanı: §e${warning.points}`,
    ].join("\n");

    // MessageFormData: button1 üstte, button2 altta -> "kapat" üstte, "sil" altta
    new MessageFormData()
        .title("§lXray Uyarısı")
        .body(body)
        .button1("Kapat")
        .button2("Sil")
        .show(admin)
        .then((res) => {
            if (res.canceled || !admin.isValid) return;
            if (res.selection === 1) {
                deleteWarning(warning.id);
                admin.sendMessage("§aUyarı silindi.");
                openWarningsListMenu(admin, filterPlayerId);
            }
            // selection === 0 ("Kapat") -> hiçbir şey yapma, menü kapanır.
        });
}

// ---------------------------------------------------------------------
// AntiDupe uyarıları (bundle temizlikleri + piston/riskli blok yan yana denemeleri)
// ---------------------------------------------------------------------
function openDupeWarningsListMenu(admin, filterPlayerId) {
    const all = getDupeWarnings().sort((a, b) => b.time - a.time);
    const list = filterPlayerId ? all.filter((w) => w.playerId === filterPlayerId) : all;

    const form = new ActionFormData()
        .title("§lAntiDupe Uyarıları")
        .body(list.length === 0 ? "§8Uyarı yok." : "§8Detay için bir uyarı seç:");

    for (const w of list) {
        form.button(`§6${w.playerName} §8- ${formatTime(w.time)}`);
    }
    form.button("§8<< Geri");

    form.show(admin).then((res) => {
        if (res.canceled || !admin.isValid) return;
        if (res.selection === list.length) {
            openXrayLogMainMenu(admin);
            return;
        }
        openDupeWarningDetailMenu(admin, list[res.selection], filterPlayerId);
    });
}

function openDupeWarningDetailMenu(admin, warning, filterPlayerId) {
    const lines = [
        `§lOyuncu: §r§f${warning.playerName}`,
        `§8Tarih: §f${formatTime(warning.time)}`,
        `§8Sebep: §f${warning.reason}`,
    ];
    if (warning.withWhat) lines.push(`§8Neyle: §f${warning.withWhat}`);
    if (warning.location) {
        const loc = warning.location;
        const dim = String(loc.dimensionId ?? "").replace("minecraft:", "");
        lines.push(`§8Konum: §f${Math.floor(loc.x)}, ${Math.floor(loc.y)}, ${Math.floor(loc.z)} §8(${dim})`);
    }

    // MessageFormData: button1 üstte, button2 altta -> "kapat" üstte, "sil" altta
    new MessageFormData()
        .title("§lAntiDupe Uyarısı")
        .body(lines.join("\n"))
        .button1("Kapat")
        .button2("Sil")
        .show(admin)
        .then((res) => {
            if (res.canceled || !admin.isValid) return;
            if (res.selection === 1) {
                deleteDupeWarning(warning.id);
                admin.sendMessage("§aAntiDupe uyarısı silindi.");
                openDupeWarningsListMenu(admin, filterPlayerId);
            }
            // selection === 0 ("Kapat") -> hiçbir şey yapma, menü kapanır.
        });
}
