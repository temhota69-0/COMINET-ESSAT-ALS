import { system, world } from "@minecraft/server";
import { recordPosition, cleanupOldLogs, clearZoneState } from "../data/positionLogData.js";

// 20 tick = 1 saniye -> 5 dakika = 6000 tick
const INTERVAL_TICKS = 5 * 60 * 20;
const DAY_MS = 24 * 60 * 60 * 1000;

let lastCleanupDay = -1;

/**
 * Her 5 dakikada bir tüm çevrimiçi oyuncuların konumunu loglar.
 * Loglar 7 gün saklanır, daha eskisi otomatik silinir.
 * Eski log temizliği (dynamic property tarama) lag yaratmaması için
 * her 5 dakikada değil, günde sadece bir kez çalıştırılır.
 * main.js içinde bir kere çağrılmalı.
 */
export function initPositionLog() {
    world.beforeEvents.playerLeave.subscribe((event) => {
        clearZoneState(event.player.id);
    });

    system.runInterval(() => {
        for (const player of world.getAllPlayers()) {
            try {
                if (player.isValid) recordPosition(player);
            } catch {
                // oyuncu geçersizse yoksay
            }
        }

        const today = Math.floor(Date.now() / DAY_MS);
        if (today !== lastCleanupDay) {
            lastCleanupDay = today;
            cleanupOldLogs();
        }
    }, INTERVAL_TICKS);
}
