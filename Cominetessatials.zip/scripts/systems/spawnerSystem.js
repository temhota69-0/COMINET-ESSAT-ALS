import { world, system, ItemStack } from "@minecraft/server";
import { ChestFormData } from "../extensions/forms.js";
import {
    SPAWNER_TYPES,
    registerSpawner,
    unregisterSpawner,
    getSpawner,
    getAllSpawners,
    addLootToSpawner,
    clearSpawnerStorage,
    rollLoot,
    getSellPrice,
    getFillPercent,
    MAX_STORAGE_PER_ITEM,
} from "../data/spawnerData.js";

const SELL_SCOREBOARD_NAME = "Para";

const SPAWNER_BLOCK_ID = "minecraft:mob_spawner";
const LORE_PREFIX = "§r§8SPAWNER:"; // itemStack lore'una gizlenen tip bilgisi
const SPAWN_INTERVAL_TICKS = 200; // 10 saniye
const ACTIVATION_RANGE = 24; // spawner'ın çalışması için bu mesafede bir oyuncu olmalı

// Yerleştirme anını yakalamak için: item kullanılınca (itemUseOn), hangi oyuncunun
// hangi spawner tipini yerleştirmeye çalıştığını kısa süreliğine burada tutuyoruz.
// playerPlaceBlock afterEvent'inde itemStack bilgisine güvenli erişim olmadığı için
// bu iki adımlı yaklaşım kullanılıyor.
const pendingPlacement = new Map(); // playerId -> { type, tick }
const PENDING_TTL_TICKS = 20;

/** Bir itemStack'in lore'undan spawner tipini çıkarır (yoksa null). */
function getSpawnerTypeFromItem(itemStack) {
    if (!itemStack || itemStack.typeId !== SPAWNER_BLOCK_ID) return null;
    const lore = itemStack.getLore();
    for (const line of lore) {
        if (line.startsWith(LORE_PREFIX)) {
            const type = line.slice(LORE_PREFIX.length);
            if (SPAWNER_TYPES[type]) return type;
        }
    }
    return null;
}

/** Shop'un vereceği, tipi lore'unda gömülü spawner item'ını oluşturur. */
export function createSpawnerItemStack(type) {
    const config = SPAWNER_TYPES[type];
    if (!config) return null;

    const item = new ItemStack(SPAWNER_BLOCK_ID, 1);
    item.nameTag = `§r§b${config.name}`;
    item.setLore([
        `${LORE_PREFIX}${type}`,
        "§r§7Yerleştir, sağ tıkla, biriken itemleri al/dök/sat.",
        "§r§7Silk Touch ile kırarsan geri envantere gelir.",
    ]);
    return item;
}

function giveItemToPlayer(player, typeId, amount) {
    const container = player.getComponent("inventory")?.container;
    if (!container) return amount;

    let remaining = amount;
    let maxStack = 64;
    try {
        maxStack = new ItemStack(typeId, 1).maxAmount;
    } catch {
        /* varsayılan 64 kalır */
    }

    while (remaining > 0) {
        const stackAmount = Math.min(remaining, maxStack);
        const leftover = container.addItem(new ItemStack(typeId, stackAmount));
        if (leftover) {
            remaining = remaining - stackAmount + leftover.amount;
            break;
        }
        remaining -= stackAmount;
    }
    return remaining;
}

// Chest UI'da alt kontrol satırındaki sabit slotlar (0-44 loot, 45-53 kontrol).
const SLOT_TAKE_ALL = 45;
const SLOT_DROP_LOOT = 46;
const SLOT_SELL_ALL = 47;
const SLOT_INFO = 53;

function claimAllLoot(player, dimensionId, location) {
    const storage = clearSpawnerStorage(dimensionId, location);
    let anyOverflow = false;
    for (const [itemId, amount] of Object.entries(storage)) {
        if (amount <= 0) continue;
        const leftover = giveItemToPlayer(player, itemId, amount);
        if (leftover > 0) {
            addLootToSpawner(dimensionId, location, itemId, leftover);
            anyOverflow = true;
        }
    }
    player.sendMessage(anyOverflow ? "§eEnvanterin doluydu, bir kısmı spawner'da kaldı." : "§aTüm itemler alındı.");
}

function dropAllLoot(player, dimensionId, location) {
    const dimension = world.getDimension(dimensionId);
    const storage = clearSpawnerStorage(dimensionId, location);
    let maxStack = 64;

    for (const [itemId, amount] of Object.entries(storage)) {
        if (amount <= 0) continue;
        try {
            maxStack = new ItemStack(itemId, 1).maxAmount;
        } catch {
            maxStack = 64;
        }
        let remaining = amount;
        while (remaining > 0) {
            const stackAmount = Math.min(remaining, maxStack);
            dimension.spawnItem(new ItemStack(itemId, stackAmount), location);
            remaining -= stackAmount;
        }
    }
    player.sendMessage("§eBiriken tüm itemler yere döküldü.");
}

function sellAllLoot(player, dimensionId, location) {
    const objective = world.scoreboard.getObjective(SELL_SCOREBOARD_NAME);
    if (!objective) {
        player.sendMessage(`§c"${SELL_SCOREBOARD_NAME}" adlı scoreboard bulunamadı.`);
        return;
    }

    const storage = clearSpawnerStorage(dimensionId, location);
    let total = 0;
    let hadUnsellable = false;

    for (const [itemId, amount] of Object.entries(storage)) {
        if (amount <= 0) continue;
        const price = getSellPrice(itemId);
        if (price === null) {
            // Satılamayan itemler kaybolmasın diye geri spawner'a konur.
            addLootToSpawner(dimensionId, location, itemId, amount);
            hadUnsellable = true;
            continue;
        }
        total += price * amount;
    }

    if (total > 0) {
        objective.setScore(player, (objective.getScore(player) ?? 0) + total);
    }
    player.sendMessage(
        total > 0
            ? `§aBiriken itemler satıldı! §e+${total} Para${hadUnsellable ? " §7(satılamayan itemler spawner'da kaldı)" : ""}`
            : "§cSatılabilecek bir item yok."
    );
}

async function openSpawnerMenu(player, dimensionId, location, entry) {
    const config = SPAWNER_TYPES[entry.type];
    const storageEntries = Object.entries(entry.storage).filter(([, amount]) => amount > 0);
    const fillPercent = getFillPercent(entry);
    const label = entry.type.toUpperCase().replace(/_/g, " ");

    const form = new ChestFormData("large").title(`1 ${label} SPAWNER`);

    storageEntries.forEach(([itemId, amount], i) => {
        if (i >= 45) return; // 0-44 loot slotları, gerisi kontrol satırı
        const displayAmount = Math.min(amount, 99);
        form.button(i, `§f${itemId.replace("minecraft:", "")}`, [`§7Miktar: §e${amount}`], itemId, displayAmount);
    });

    form.button(SLOT_TAKE_ALL, "§aEnvantere Al", ["§7Click to claim all loot"], "minecraft:hopper");
    form.button(SLOT_DROP_LOOT, "§cHepsini Dök", ["§7Click to drop all loot"], "minecraft:dropper");
    form.button(SLOT_SELL_ALL, "§6Hepsini Sat", ["§7Click to sell all loot"], "minecraft:emerald");
    form.button(SLOT_INFO, `§b${config?.name ?? "Spawner"}`, [`§7(${fillPercent}% filled)`], "minecraft:mob_spawner");

    const response = await form.show(player);
    if (response.canceled || response.selection === undefined) return;

    if (storageEntries.length === 0 && response.selection !== SLOT_INFO) {
        player.sendMessage("§7Henüz biriken bir şey yok. Biraz bekle.");
        return;
    }

    switch (response.selection) {
        case SLOT_TAKE_ALL:
            return claimAllLoot(player, dimensionId, location);
        case SLOT_DROP_LOOT:
            return dropAllLoot(player, dimensionId, location);
        case SLOT_SELL_ALL:
            return sellAllLoot(player, dimensionId, location);
        default:
            return; // loot slotuna veya info ikonuna tıklamak bir şey yapmaz
    }
}

export function initSpawnerSystem() {
    // 1. Adım: item kullanımı (yerleştirme öncesi) -> bekleyen yerleştirme olarak kaydet
    // NOT: bazı script API sürümlerinde world.beforeEvents.itemUseOn mevcut değil
    // (undefined), bu yüzden önce afterEvents denenir, güvenli erişim kullanılır.
    const itemUseOnEvent = world.afterEvents?.itemUseOn ?? world.beforeEvents?.itemUseOn;
    if (itemUseOnEvent) {
        itemUseOnEvent.subscribe((event) => {
            const type = getSpawnerTypeFromItem(event.itemStack);
            if (!type) return;
            pendingPlacement.set(event.source.id, { type, tick: system.currentTick });
        });
    } else {
        console.warn("[spawnerSystem] itemUseOn event bulunamadı, spawner yerleştirme algılanamayabilir.");
    }

    // 2. Adım: blok gerçekten yerleştirildiğinde bekleyeni kayda dönüştür
    world.afterEvents?.playerPlaceBlock?.subscribe((event) => {
        if (event.block.typeId !== SPAWNER_BLOCK_ID) return;

        const pending = pendingPlacement.get(event.player.id);
        pendingPlacement.delete(event.player.id);
        if (!pending || system.currentTick - pending.tick > PENDING_TTL_TICKS) return;

        registerSpawner(event.dimension.id, event.block.location, pending.type);
    });

    // Sağ tık: menüyü aç
    world.afterEvents?.playerInteractWithBlock?.subscribe((event) => {
        if (event.block.typeId !== SPAWNER_BLOCK_ID) return;

        const entry = getSpawner(event.player.dimension.id, event.block.location);
        if (!entry) return; // shop dışından gelen / kayıtsız spawner, dokunma

        system.run(() => openSpawnerMenu(event.player, event.player.dimension.id, event.block.location, entry));
    });

    // Kırılma: kaydı sil. Silk Touch'lı aletle kırılırsa spawner item olarak
    // (tipi korunarak) envantere geri verilir, değilse hiçbir şey düşmez.
    world.afterEvents?.playerBreakBlock?.subscribe((event) => {
        if (event.brokenBlockPermutation.type.id !== SPAWNER_BLOCK_ID) return;

        const dimensionId = event.dimension.id;
        const location = event.block.location;
        const entry = getSpawner(dimensionId, location);
        unregisterSpawner(dimensionId, location);
        if (!entry) return; // kayıtsız/vanilla spawner, dokunma

        const tool = event.player.getComponent("equippable")?.getEquipment("Mainhand");
        const silkTouchLevel = tool?.getComponent("enchantable")?.getEnchantment("silk_touch")?.level ?? 0;
        if (silkTouchLevel <= 0) return;

        const spawnerItem = createSpawnerItemStack(entry.type);
        if (!spawnerItem) return;

        const container = event.player.getComponent("inventory")?.container;
        const leftover = container?.addItem(spawnerItem);
        if (leftover) {
            event.dimension.spawnItem(leftover, location);
        }
    });

    // Periyodik loot üretimi
    system.runInterval(() => {
        for (const [key, entry] of getAllSpawners()) {
            const [dimensionId, xStr, yStr, zStr] = key.split(";");
            const location = { x: Number(xStr), y: Number(yStr), z: Number(zStr) };

            const dimension = world.getDimension(dimensionId);
            const block = dimension.getBlock(location);
            if (!block || block.typeId !== SPAWNER_BLOCK_ID) {
                // blok bir şekilde yok olmuş (ör. patlama), kaydı temizle
                unregisterSpawner(dimensionId, location);
                continue;
            }

            const nearbyPlayer = dimension
                .getPlayers({ location, maxDistance: ACTIVATION_RANGE })
                .find(() => true);
            if (!nearbyPlayer) continue;

            const drop = rollLoot(entry.type);
            if (!drop) continue;

            const currentAmount = entry.storage[drop.item] ?? 0;
            if (currentAmount >= MAX_STORAGE_PER_ITEM) continue;

            addLootToSpawner(dimensionId, location, drop.item, drop.amount);
        }
    }, SPAWN_INTERVAL_TICKS);

    // Eski pending kayıtlarını arada bir temizle (bellek sızıntısını önlemek için)
    system.runInterval(() => {
        for (const [playerId, pending] of pendingPlacement) {
            if (system.currentTick - pending.tick > PENDING_TTL_TICKS) {
                pendingPlacement.delete(playerId);
            }
        }
    }, 200);
}
