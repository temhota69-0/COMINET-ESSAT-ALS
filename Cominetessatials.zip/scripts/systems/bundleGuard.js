import { world, system } from "@minecraft/server";
import { addDupeWarning } from "../data/antiDupeData.js";

function logBundleCatch(player, reason) {
    try {
        addDupeWarning({
            id: `${player.id}_${Date.now()}`,
            playerId: player.id,
            playerName: player.name,
            time: Date.now(),
            reason,
        });
    } catch {}
}

export function initBundleGuard() {
    // 1. Oyuncu Envanter Temizliği (Zıfır lag, sadece oyuncu slotları)
    system.runInterval(() => {
        for (const player of world.getAllPlayers()) {
            const inventory = player.getComponent("inventory")?.container;
            if (!inventory) continue;

            for (let i = 0; i < inventory.size; i++) {
                const item = inventory.getItem(i);
                if (item && item.typeId.includes("bundle")) {
                    inventory.setItem(i, undefined);
                    player.sendMessage("§cSunucuda Bundle kullanımı dupe riski nedeniyle yasaktır!");
                    logBundleCatch(player, "Envanterinde Bundle bulunduruyordu (dupe riski)");
                }
            }
        }
    }, 20);

    // 2. Depo / Huni Etkileşim Koruması
    world.beforeEvents?.playerInteractWithBlock?.subscribe((event) => {
        const { player, block, itemStack } = event;

        // beforeEvents read-only modda çalışır: container.setItem / sendMessage gibi
        // dünyayı değiştiren işlemler burada DOĞRUDAN çağrılamaz, hata fırlatır.
        // Bu yüzden mutasyonları system.run() ile bir sonraki tick'e erteliyoruz.

        if (itemStack && itemStack.typeId.includes("bundle")) {
            const container = block.getComponent("inventory")?.container;
            if (container) {
                event.cancel = true;
                system.run(() => {
                    try {
                        if (player.isValid) player.sendMessage("§cHuni veya depolara Bundle ile tıklayamazsın!");
                    } catch {}
                    logBundleCatch(player, "Depo/Huniye Bundle ile tıklamaya çalıştı");
                });
                return;
            }
        }

        const hasContainer = Boolean(block.getComponent("inventory")?.container);
        if (!hasContainer) return;

        const blockLocation = { x: block.x, y: block.y, z: block.z };
        const dimension = block.dimension;

        system.run(() => {
            try {
                const currentBlock = dimension.getBlock(blockLocation);
                const container = currentBlock?.getComponent("inventory")?.container;
                if (!container) return;

                let cleaned = false;
                for (let slot = 0; slot < container.size; slot++) {
                    const item = container.getItem(slot);
                    if (item && item.typeId.includes("bundle")) {
                        container.setItem(slot, undefined);
                        cleaned = true;
                    }
                }

                if (cleaned && player.isValid) {
                    player.sendMessage("§cKonteyner içindeki Bundle temizlendi!");
                    logBundleCatch(player, "Konteynerine Bundle koymuştu, temizlendi (dupe riski)");
                }
            } catch {}
        });
    });

    // 3. Yere Düşen / Huniye Emen Eşyaları Anında Silme
    world.afterEvents?.entitySpawn?.subscribe((event) => {
        const entity = event.entity;
        if (entity?.typeId === "minecraft:item") {
            const itemComponent = entity.getComponent("item");
            if (itemComponent && itemComponent.itemStack.typeId.includes("bundle")) {
                entity.remove();
            }
        }
    });
}
