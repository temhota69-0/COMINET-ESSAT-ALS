import { world } from "@minecraft/server";

// Ayarlar
const RADIUS = 16;      // Blok cinsinden kontrol yarıçapı
const MOB_LIMIT = 40;   // Bu yarıçap içinde izin verilen maksimum mob sayısı

// Sayıma dahil edilmeyecek tipler (item, oyuncu, xp orb vs.)
const EXCLUDED_TYPES = new Set([
    "minecraft:item",
    "minecraft:xp_orb",
    "minecraft:player",
    "minecraft:arrow",
    "minecraft:fishing_hook",
    "minecraft:fireball",
    "minecraft:thrown_trident",
]);

export function initMobSpamGuard() {
    world.afterEvents.entitySpawn.subscribe((event) => {
        const entity = event.entity;
        if (!entity || !entity.isValid) return;
        if (EXCLUDED_TYPES.has(entity.typeId)) return;

        const dimension = entity.dimension;
        const location = entity.location;

        // Yakındaki tüm entityleri al
        const nearby = dimension.getEntities({
            location,
            maxDistance: RADIUS,
        });

        // Item, oyuncu ve diğer hariç tutulanları sayma, sadece mobları say
        const mobCount = nearby.filter((e) => !EXCLUDED_TYPES.has(e.typeId)).length;

        if (mobCount > MOB_LIMIT) {
            try {
                entity.remove();
            } catch (e) {
                // Entity zaten geçersizse görmezden gel
            }
        }
    });
}
