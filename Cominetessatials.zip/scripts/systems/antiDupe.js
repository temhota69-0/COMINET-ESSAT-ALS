import { world, system } from "@minecraft/server";
import { addDupeWarning } from "../data/antiDupeData.js";

// Bilinen piston-dupe glitch'inde kullanılan bloklar: piston + bu bloklardan biri
// birbirine YAN YANA (komşu) gelemez. Sadece yerleştirme anında kontrol ediyoruz
// (tick döngüsü / tarama yok), bu yüzden tamamen event tabanlı ve lagsiz.
const PISTON_IDS = new Set(["minecraft:piston", "minecraft:sticky_piston"]);

function isRiskyBlock(typeId) {
    if (typeId === "minecraft:end_rod") return true;
    if (typeId === "minecraft:lightning_rod") return true;
    if (typeId.includes("fence_gate")) return true; // tüm çit kapısı türleri (oak, cherry, bamboo, vs.)
    return false;
}

const NEIGHBOR_OFFSETS = [
    { x: 1, y: 0, z: 0 },
    { x: -1, y: 0, z: 0 },
    { x: 0, y: 1, z: 0 },
    { x: 0, y: -1, z: 0 },
    { x: 0, y: 0, z: 1 },
    { x: 0, y: 0, z: -1 },
];

function friendlyName(typeId) {
    return typeId.replace("minecraft:", "").replace(/_/g, " ");
}

function logDupeAttempt(player, reason, withWhat, location, dimensionId) {
    system.run(() => {
        try {
            addDupeWarning({
                id: `${player.id}_${Date.now()}`,
                playerId: player.id,
                playerName: player.name,
                time: Date.now(),
                reason,
                withWhat,
                location: { x: location.x, y: location.y, z: location.z, dimensionId },
            });
        } catch {}
    });
}

export function initAntiDupe() {
    world.beforeEvents?.playerPlaceBlock?.subscribe((event) => {
        const { player, block } = event;
        // Bedrock sürümleri arası isim değişikliğine (permutationBeingPlaced -> permutationToPlace)
        // karşı ikisini de destekle.
        const permutation = event.permutationToPlace ?? event.permutationBeingPlaced;
        if (!permutation) return;

        const typeId = permutation.type.id;
        const placingPiston = PISTON_IDS.has(typeId);
        const placingRisky = isRiskyBlock(typeId);
        if (!placingPiston && !placingRisky) return;

        const dimension = block.dimension;
        const dimensionId = dimension.id;

        for (const offset of NEIGHBOR_OFFSETS) {
            let neighbor;
            try {
                neighbor = dimension.getBlock({
                    x: block.x + offset.x,
                    y: block.y + offset.y,
                    z: block.z + offset.z,
                });
            } catch {
                continue;
            }
            if (!neighbor) continue;

            const neighborTypeId = neighbor.typeId;
            const conflict = placingPiston ? isRiskyBlock(neighborTypeId) : PISTON_IDS.has(neighborTypeId);
            if (!conflict) continue;

            event.cancel = true;

            const withWhat = placingPiston ? friendlyName(neighborTypeId) : friendlyName(typeId);
            const location = { x: block.x, y: block.y, z: block.z };

            system.run(() => {
                try {
                    if (player.isValid) {
                        player.sendMessage(
                            "§cPiston; End Rod, Çit Kapısı veya Paratoner ile yan yana olamaz. (Dupe koruması)"
                        );
                    }
                } catch {}
            });

            logDupeAttempt(
                player,
                "Piston + riskli blok yan yana yerleştirme denemesi (dupe glitch)",
                withWhat,
                location,
                dimensionId
            );
            return;
        }
    });
}
