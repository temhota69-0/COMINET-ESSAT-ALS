import { system, world } from "@minecraft/server";
import { resolveKillCredit, clearDamageLog } from "../data/combatData.js";
import { recordKill } from "../data/killLogData.js";

const KILLS_OBJ = "Kills";
const DEATHS_OBJ = "Deaths";
const ASSISTS_OBJ = "Assists";

const objectiveCache = {};

function getOrCreateObjective(id, displayName) {
    try {
        let obj = world.scoreboard.getObjective(id);
        if (!obj) obj = world.scoreboard.addObjective(id, displayName);
        return obj;
    } catch (e) {
        return null;
    }
}

function getObjective(cacheKey, id) {
    if (objectiveCache[cacheKey]) return objectiveCache[cacheKey];
    return getOrCreateObjective(id, id);
}

function addScore(objective, participant, amount = 1) {
    if (!objective || !participant) return;
    try {
        const current = objective.getScore(participant) ?? 0;
        objective.setScore(participant, current + amount);
    } catch (e) {
    }
}

export function initKillDeathTracking() {
    system.run(() => {
        objectiveCache.kills = getOrCreateObjective(KILLS_OBJ, "Kills");
        objectiveCache.deaths = getOrCreateObjective(DEATHS_OBJ, "Deaths");
        objectiveCache.assists = getOrCreateObjective(ASSISTS_OBJ, "Assists");
    });

    world.afterEvents.entityDie.subscribe((event) => {
        try {
            const deadEntity = event.deadEntity;
            if (!deadEntity) return;

            if (deadEntity.typeId !== "minecraft:player") {
                clearDamageLog(deadEntity.id);
                return;
            }

            addScore(getObjective("deaths", DEATHS_OBJ), deadEntity, 1);

            const { killer, assists } = resolveKillCredit(deadEntity.id);
            if (!killer || killer.id === deadEntity.id || !killer.isValid) return;

            addScore(getObjective("kills", KILLS_OBJ), killer, 1);
            recordKill(killer, deadEntity);

            const assistsObj = getObjective("assists", ASSISTS_OBJ);
            for (const assist of assists) {
                if (assist.id === deadEntity.id || !assist.isValid) continue;
                addScore(assistsObj, assist, 1);
            }
        } catch (err) {
            console.warn("kd.js entityDie hatasi: " + err);
        }
    });
}
