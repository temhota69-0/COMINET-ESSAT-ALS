import { system, world } from "@minecraft/server";
import { getCombatInfo } from "../data/combatData.js";
import { getHudSettings } from "../data/hudSettingsData.js";

const PARA_OBJ = "Para";
const DARKCOIN_OBJ = "DarkCoin";
const KILLS_OBJ = "Kills";
const DEATHS_OBJ = "Deaths";
const MAX_ONLINE = 11;

// Optimizasyon: objective referanslarını her tick tekrar aramak yerine
// (world.scoreboard.getObjective her seferinde bir lookup yapıyor) bir kere
// bulunduktan sonra cache'liyoruz. Objective bulunamazsa (henüz
// oluşturulmadıysa) cache'lenmez, bir sonraki tick'te tekrar denenir.
const objectiveCache = new Map();

function getScore(objectiveName, player) {
    try {
        let obj = objectiveCache.get(objectiveName);
        if (!obj) {
            obj = world.scoreboard.getObjective(objectiveName);
            if (obj) objectiveCache.set(objectiveName, obj);
        }
        return obj ? (obj.getScore(player) ?? 0) : 0;
    } catch (e) {
        // Objective silinmiş/geçersiz olabilir, cache'ten temizleyip 0 dön.
        objectiveCache.delete(objectiveName);
        return 0;
    }
}

function formatTime() {
    const d = new Date();
    const hh = d.getHours().toString().padStart(2, "0");
    const mm = d.getMinutes().toString().padStart(2, "0");
    return `${hh}:${mm}`;
}

function buildTitleHud(player, onlineCount) {
    const name = player.name;
    const para = getScore(PARA_OBJ, player);
    const darkcoin = getScore(DARKCOIN_OBJ, player);
    const kill = getScore(KILLS_OBJ, player);
    const death = getScore(DEATHS_OBJ, player);
    const time = formatTime();

    return (
        `§s§c§o§r§e§b§o§a§r§d§w§b§p§a§o§c§lDARK§e§lSMP\n` +
        `§r§g® §7${name}\n` +
        `§r§8Statistic\n` +
        `§r§aP §7Para: §a${para}\n` +
        `§r§2D §7DarkCoin: §2${darkcoin}\n` +
        `§r§cK §7Kills: §c${kill}\n` +
        `§r§4D §7Deaths: §4${death}\n` +
        `§r§3O §7Online: §b${onlineCount} §7/ §b${MAX_ONLINE}\n` +
        `§r§eZ §7Zaman: §e${time}\n\n` +
        `§r§3Europe (§b21§3)`
    );
}

/**
 * Action bar metnini oyuncunun HUD ayarlarına göre oluşturur.
 * - Cps ve Combo, ayara göre normal şekilde aç/kapa edilir (cps ile aynı davranış).
 * - Combat satırının ayarı yoktur; oyuncu combat'taysa her zaman gösterilir,
 *   hiçbir HUD ayarıyla kapatılamaz.
 * - Konum (Cord) açıksa her zaman ayrı bir satırda (\n ile) gösterilir,
 *   diğer bilgilerle aynı satıra karıştırılmaz.
 */
function buildActionBar(player) {
    const { inCombat, combo, cps, combatSecondsLeft } = getCombatInfo(player.id);
    const settings = getHudSettings(player);

    const parts = [];
    if (settings.cps) parts.push(`§bcps §7: §b${cps}`);
    if (settings.combo) parts.push(`§dcombo §7: §d${combo}`);

    let line = parts.join(" §7| ");
    if (inCombat) {
        line += (line ? " §7| " : "") + `§ccombat §7${combatSecondsLeft}s`;
    }

    if (settings.location) {
        const { x, y, z } = player.location;
        const cordLine = `§aCord §7: §f${Math.floor(x)} ${Math.floor(y)} ${Math.floor(z)}`;
        line = line ? `${line}\n${cordLine}` : cordLine;
    }

    return line;
}

// Title/scoreboard normalde 20 tick'te bir (saniyede bir) güncellenir.
const TITLE_INTERVAL_TICKS = 20;
// Ana döngü 2 tick'te bir çalışır: Cord (konum) ayarı açık olan
// oyuncular için actionbar her 2 tick'te bir (çok daha akıcı) güncellenir,
// kapalı olanlar için ise yine 20 tick'te bir (eski davranış) güncellenir.
const BASE_INTERVAL_TICKS = 2;
const ACTIONBAR_SLOW_INTERVAL_TICKS = 20;

let tickCounter = 0;

export function initScoreboardHud() {
    system.runInterval(() => {
        tickCounter += BASE_INTERVAL_TICKS;

        const players = world.getPlayers();
        const onlineCount = players.length;
        const updateTitleThisPass = tickCounter % TITLE_INTERVAL_TICKS === 0;

        for (const player of players) {
            if (!player || !player.isValid) continue;
            try {
                const settings = getHudSettings(player);

                // Scoreboard (title) sadece açıksa ve saniyelik aralık geldiyse güncellenir.
                if (settings.scoreboard && updateTitleThisPass) {
                    player.onScreenDisplay.setTitle(buildTitleHud(player, onlineCount));
                } else if (!settings.scoreboard && updateTitleThisPass) {
                    // Scoreboard kapalıysa ekrandaki title'ı temizle.
                    player.onScreenDisplay.setTitle("");
                }

                // Cord (konum) açıksa actionbar her 2 tick'te bir, kapalıysa 20 tick'te bir güncellenir.
                const actionBarInterval = settings.location ? BASE_INTERVAL_TICKS : ACTIONBAR_SLOW_INTERVAL_TICKS;
                if (tickCounter % actionBarInterval === 0) {
                    player.onScreenDisplay.setActionBar(buildActionBar(player));
                }
            } catch (e) {
            }
        }
    }, BASE_INTERVAL_TICKS);
}
