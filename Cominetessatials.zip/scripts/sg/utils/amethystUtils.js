import { world, ItemStack } from "@minecraft/server";
import { NatureBlocks, CropBlocks, WoodenBlocks, ColoredBlocks, MiscBlocks, UnbreakableBlocks, MineralBlocks, SilkTouchBlocks } from "../blocks/BlockList";
import { TIER_LIST } from "../items/amethyst";

// Increases the number of items dropped depending on the fortune level provided.
export function fortuneDropAmount(level) {
    let amountToDrop = 1;
    for (let i = 0; i < level; i++) {
        if (Math.random() < 0.33) {
            amountToDrop++
        }
    }
    return amountToDrop;
};

// Spawns a certain amount of the given item at the source's location.
export function dropItem(source, item, amount) {
    const dimension = source.dimension;
    const location = source.location;

    if (amount > 0) {
        const itemToDrop = new ItemStack(item, amount);
        dimension.spawnItem(itemToDrop, location);
    }
};

// Get the list of ignored blocks depending on the item's tier.
export function getIgnoredBlocks(itemStack) {
    const VANILLA_BLOCKS = [
      ...NatureBlocks,
      ...CropBlocks,
      ...WoodenBlocks,
      ...ColoredBlocks,
      ...MiscBlocks,
      ...UnbreakableBlocks
    ];
    for (const tier_name in TIER_LIST) {
        if (itemStack.hasTag(tier_name)) {
            return [...VANILLA_BLOCKS, ...TIER_LIST[tier_name]];
        }
    }
    return VANILLA_BLOCKS;
};

// Decreases the durability of the given item. If the item has Unbreaking enchantment, it calculates whether durability is lost.
export function decreaseDurability(player, item, amount) {
    if (amount <= 0) return;
    const durability = item?.getComponent("durability");
    const unbreakingLevel = item.getComponent('enchantable')?.getEnchantment('unbreaking')?.level;

    if (player?.getGameMode() !== "Creative") {
        if ((durability.maxDurability - durability.damage) > amount) {
            if (!unbreakingLevel) {
                durability.damage += amount;
                player.getComponent("equippable")?.setEquipment("Mainhand", item);
            } else {
                if (Math.floor(Math.random() * (unbreakingLevel + 1)) == 0) {
                    durability.damage += amount;
                    player.getComponent("equippable")?.setEquipment("Mainhand", item);
                }
            }
        } else {
            player.playSound('random.break');
            player.getComponent("equippable")?.setEquipment("Mainhand", undefined);
        }
    }
};

// Get the player's cardinal direction depending on the direction they are looking.
function getCardinalDirection(player) {
    const { x, y, z } = player.getViewDirection();

    if (y > 0.5) {
        return "Up"
    } else if (y < -0.5) {
        return "Down"
    } else if (Math.abs(x) > Math.abs(z)) {
        return x > 0 ? "East" : "West";
    } else {
        return z > 0 ? "South" : "North";
    }
};

// Get the area of blocks that will be destroyed by the hammer in each cardinal direction.
function getAreaOfEffect(direction, blockPos, radius, depth) {
    const size = Math.floor(radius / 2);
    const offset = size - 1;

    const min = { x: blockPos.x, y: blockPos.y, z: blockPos.z };
    const max = { x: blockPos.x, y: blockPos.y, z: blockPos.z };

    switch (direction) {
        case "Up":
            min.y = blockPos.y;
            max.y = blockPos.y + depth - 1;
            min.x = blockPos.x - size;
            max.x = blockPos.x + size;
            min.z = blockPos.z - size;
            max.z = blockPos.z + size;
            break;
        case "Down":
            min.y = blockPos.y - depth + 1;
            max.y = blockPos.y;
            min.x = blockPos.x - size;
            max.x = blockPos.x + size;
            min.z = blockPos.z - size;
            max.z = blockPos.z + size;
            break;
        case "North":
            min.z = blockPos.z - depth + 1;
            max.z = blockPos.z;
            min.x = blockPos.x - size;
            max.x = blockPos.x + size;
            min.y = blockPos.y - size + offset;
            max.y = blockPos.y + size + offset;
            break;
        case "South":
            min.z = blockPos.z;
            max.z = blockPos.z + depth - 1;
            min.x = blockPos.x - size;
            max.x = blockPos.x + size;
            min.y = blockPos.y - size + offset;
            max.y = blockPos.y + size + offset;
            break;
        case "East":
            min.x = blockPos.x;
            max.x = blockPos.x + depth - 1;
            min.z = blockPos.z - size;
            max.z = blockPos.z + size;
            min.y = blockPos.y - size + offset;
            max.y = blockPos.y + size + offset;
            break;
        case "West":
            min.x = blockPos.x - depth + 1;
            max.x = blockPos.x;
            min.z = blockPos.z - size;
            max.z = blockPos.z + size;
            min.y = blockPos.y - size + offset;
            max.y = blockPos.y + size + offset;
            break;
        default:
            return undefined;
    }
    return { min, max };
};

// Break all selected blocks in a cardinal direction.
export function breakNearBlocks(player, blockBroken, itemUsed, radius, depth) {
    const ignoredBlocks = getIgnoredBlocks(itemUsed);
    const direction = getCardinalDirection(player);
    const area = getAreaOfEffect(direction, blockBroken.location, radius, depth);

    // Iterate to find all blocks that will be destroyed.
    for (let x = area.min.x; x <= area.max.x; x++) {
        for (let y = area.min.y; y <= area.max.y; y++) {
            for (let z = area.min.z; z <= area.max.z; z++) {
                const blockFound = player.dimension.getBlock({x, y, z});
                const blockLocation = blockFound.location;

                if (!ignoredBlocks.includes(blockFound?.typeId)) {
                    if (world.gameRules.doTileDrops && player?.getGameMode() !== "Creative") {
                        const fortuneLevel = itemUsed.getComponent('enchantable')?.getEnchantment('fortune')?.level;
                        const silkTouchLevel = itemUsed.getComponent('enchantable')?.getEnchantment('silk_touch')?.level;

                        if (MineralBlocks[blockFound?.typeId] && !silkTouchLevel) {
                            if (fortuneLevel) {
                                const mineralDrop = MineralBlocks[blockFound?.typeId].drop;
                                const extraAmount = fortuneDropAmount(fortuneLevel);
                                dropItem(blockFound, mineralDrop, extraAmount);
                            }
                            player.runCommand(`setblock ${blockLocation.x} ${blockLocation.y} ${blockLocation.z} air destroy`);
                        } else if (SilkTouchBlocks.includes(blockFound?.typeId) && silkTouchLevel) {
                            dropItem(blockFound, blockFound?.typeId, 1);
                            blockFound.setType("minecraft:air");
                        } else {
                            player.runCommand(`setblock ${blockLocation.x} ${blockLocation.y} ${blockLocation.z} air destroy`);
                        }
                    } else {
                        blockFound.setType("minecraft:air")
                    }
                }
            }
        }
    }
};