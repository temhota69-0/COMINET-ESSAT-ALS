import { world, system } from "@minecraft/server";
import { decreaseDurability, breakNearBlocks } from "../utils/amethystUtils";

export const TIER_LIST = {
  "minecraft:netherite_tier": [
    "minecraft:budding_amethyst"
  ]
};

system.beforeEvents.startup.subscribe(({ itemComponentRegistry }) => {
    itemComponentRegistry.registerCustomComponent("amethystpickaxe:break_blocks", {
        parameters: {
            durability_cost: { type: "integer" },
            destruction_radius: { type: "integer" },
            destruction_depth: { type: "integer" },
        },
        onMineBlock: (event, { params }) => {
            const player = event.source;
            const itemStack = event.itemStack;
            const blockBroken = event.block;
            const { durability_cost, destruction_radius, destruction_depth } = params;

            if (durability_cost >= 0 && destruction_radius >= 3 && destruction_depth >= 1) {
                decreaseDurability(player, itemStack, durability_cost);
                system.run(() => {
                    breakNearBlocks(player, blockBroken, itemStack, destruction_radius, destruction_depth);
                });
            }
        }
    });

    itemComponentRegistry.registerCustomComponent("amethystpickaxe:custom_tooltip", {
        parameters: {
            value: { type: "string" }
        }
    });
});

system.runInterval(() => {
    for (const player of world.getPlayers()) {
        const inventory = player.getComponent("inventory").container;
        for (let slot = 0; slot < inventory.size;slot++) {
            const itemStack = inventory.getItem(slot);
            const itemComponent = itemStack?.getComponent("amethystpickaxe:custom_tooltip")?.customComponentParameters;

            if (itemComponent && itemStack?.getLore().length == 0) {
                const itemTooltip = itemComponent.params.value;

                itemStack.setLore([`§r§7${itemTooltip}§r`]);
                inventory.setItem(slot, itemStack);
            }
        }
    }
}, 10);